#include <stdio.h>
#include <stdlib.h>
#include "TestPackagesFactory.h"


using namespace protocol;

Package* TestPackagesFactory::createPackage(int nr){
	switch(nr){
		default: return NULL;
	}
}
