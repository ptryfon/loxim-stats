#ifndef AUTH_H_
#define AUTH_H_
	
	#define AUTH_TRUST   	 1
	#define AUTH_PASS_MYSQL 2

#endif /*AUTH_H_*/
