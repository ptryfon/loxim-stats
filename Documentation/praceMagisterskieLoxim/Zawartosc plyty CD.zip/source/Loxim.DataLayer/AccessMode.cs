using System;

namespace Loxim
{
	internal enum AccessMode
	{
		Read,
		Write,
	}
}
