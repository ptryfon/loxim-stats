using System;
using System.Configuration;
using Loxim.Transactions;

namespace Loxim.Configuration
{
	public class TransactionSection : ConfigurationSection
	{
		public TransactionSection()
		{
		}

		[ConfigurationProperty("isolationLevel", IsRequired = false, DefaultValue = IsolationLevel.ReadCommited)]
		public IsolationLevel IsolationLevel
		{
			get { return (IsolationLevel) base["isolationLevel"]; }
			set { base["isolationLevel"] = value.ToString(); }
		}
	}
}
