using System;
using System.Configuration;
using Loxim.Store;

namespace Loxim.Configuration
{
	public class PageSizeValidator : ConfigurationValidatorBase
	{
		public override bool CanValidate(Type type)
		{
			return type == typeof(int);
		}

		public override void Validate(object value)
		{
			int v = (int) value;

			for (int i = 256; i <= 1048576; i *= 2)
				if (v == i)
					return;

			throw new ConfigurationErrorsException();
		}
	}

	public class StoreStorageElement : ConfigurationElement
	{
		public StoreStorageElement()
		{
		}

		[ConfigurationProperty("fileName", IsRequired = true)]
		public string FileName
		{
			get { return (string) base["fileName"]; }
			set { base["fileName"] = value; }
		}

		[ConfigurationProperty("fileGrowth", IsRequired = false, DefaultValue = 0.2)]
		public double FileGrowth
		{
			get { return (double) base["fileGrowth"]; }
			set { base["fileGrowth"] = value; }
		}

		[ConfigurationProperty("pageSize", IsRequired = true, DefaultValue = 256)]
		[ConfigurationValidatorAttribute(typeof(PageSizeValidator))]
		public int PageSize
		{
			get { return (int) base["pageSize"]; }
			set { base["pageSize"] = value; }
		}

		[ConfigurationProperty("allocation", IsRequired = false, DefaultValue = AllocationType.Sequential)]
		public AllocationType Allocation
		{
			get { return (AllocationType) base["allocation"]; }
			set { base["allocation"] = value; }
		}

		[ConfigurationProperty("fillFactor", IsRequired = false, DefaultValue = 0.8)]
		public double FillFactor
		{
			get { return (double) base["fillFactor"]; }
			set { base["fillFactor"] = value; }
		}

		[ConfigurationProperty("encoding", IsRequired = false, DefaultValue = "utf-8")]
		public string Encoding
		{
			get { return (string) base["encoding"]; }
			set { base["encoding"] = value; }
		}
	}
}
