using System;
using System.Configuration;

namespace Loxim.Configuration
{
	public class LogSection : ConfigurationSection
	{
		public LogSection()
		{
		}

		[ConfigurationProperty("fileName", IsRequired = true)]
		public string FileName
		{
			get { return (string) base["fileName"]; }
			set { base["fileName"] = value; }
		}

		[ConfigurationProperty("differentiator", IsRequired = true)]
		public string Differentiator
		{
			get { return (string) base["differentiator"]; }
			set { base["differentiator"] = value; }
		}

		[ConfigurationProperty("compress", IsRequired = false, DefaultValue = false)]
		public bool Compress
		{
			get { return (bool) base["compress"]; }
			set { base["compress"] = value; }
		}
	}
}
