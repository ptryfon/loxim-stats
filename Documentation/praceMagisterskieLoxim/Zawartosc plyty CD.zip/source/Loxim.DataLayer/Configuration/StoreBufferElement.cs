using System;
using System.Configuration;

namespace Loxim.Configuration
{
	public class StoreBufferElement : ConfigurationElement
	{
		public StoreBufferElement()
		{
		}

		[ConfigurationProperty("lingerTime", IsRequired = true)]
		public TimeSpan LingerTime
		{
			get { return (TimeSpan) base["lingerTime"]; }
			set { base["lingerTime"] = value; }
		}

		[ConfigurationProperty("flushInterval", IsRequired = true)]
		public TimeSpan FlushInterval
		{
			get { return (TimeSpan) base["flushInterval"]; }
			set { base["flushInterval"] = value; }
		}
	}
}
