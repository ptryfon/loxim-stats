using System;
using System.Configuration;

namespace Loxim.Configuration
{
	public class StoreSection : ConfigurationSection
	{
		public StoreSection()
		{
		}

		[ConfigurationProperty("buffer", IsRequired = true)]
		public StoreBufferElement Buffer
		{
			get { return (StoreBufferElement) base["buffer"]; }
			set { base["buffer"] = value; }
		}

		[ConfigurationProperty("storage", IsRequired = true)]
		public StoreStorageElement Storage
		{
			get { return (StoreStorageElement) base["storage"]; }
			set { base["storage"] = value; }
		}
	}
}
