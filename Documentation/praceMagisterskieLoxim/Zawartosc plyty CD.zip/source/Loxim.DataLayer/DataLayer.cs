using System;
using Loxim.Diagnostics;
using Loxim.Log;
using Loxim.Transactions;
using Loxim.Store;

namespace Loxim
{
	public sealed class DataLayer
	{
		private ErrorConsole console;
		private LogManager log;
		private FileManager file;
		private BufferManager buffer;
		private TransactionManager transaction;
		private Storage storage;

		public DataLayer()
		{
			console = new ErrorConsole("DataLayer");

			log = new LogManager();
			file = new FileManager();
			buffer = new BufferManager();
			transaction = new TransactionManager();

			storage = new Storage(buffer);
		}

		///////////////////////////////////////////////////////////////////////

		public void Start()
		{
			console.WriteLine(LogLevel.Verbose, "Starting");

			file.Start();
			buffer.Start();
			log.Start();
			transaction.Start();

			console.WriteLine(LogLevel.Verbose, "Started");
		}

		public void Stop()
		{
			console.WriteLine(LogLevel.Verbose, "Stopping");

			transaction.Stop();
			buffer.Stop();
			file.Stop();
			log.Stop();

			console.WriteLine(LogLevel.Verbose, "Stopped");
		}

		///////////////////////////////////////////////////////////////////////

		public Transaction BeginTransaction()
		{
			return transaction.Begin();
		}

		public Transaction BeginTransaction(IsolationLevel isolationLevel)
		{
			return transaction.Begin(isolationLevel);
		}

		///////////////////////////////////////////////////////////////////////
	}
}
