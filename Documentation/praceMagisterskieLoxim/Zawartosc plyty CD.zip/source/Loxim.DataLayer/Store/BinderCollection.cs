using System;
using System.Collections.Generic;
using System.Collections;
using Loxim.Transactions;

namespace Loxim.Store
{
	public sealed class BinderCollection : IEnumerable<Binder>
	{
		private Transaction transaction;
		private Binder binder;
		private ComplexAxis axis;

		internal BinderCollection(Transaction transaction, Binder binder, ComplexAxis axis)
		{
			this.transaction = transaction;
			this.binder = binder;
			this.axis = axis;
		}

		public void Fill(ICollection<Binder> collection)
		{
			if (binder == Binder.Empty)
			{
			}
			if (binder == Binder.Root)
			{
				LinkedList<Binder> roots = new LinkedList<Binder>();

				transaction.Lock(binder.Address.Physical, AccessMode.Read);
				Storage.Current.ComplexFill(transaction, binder, axis, roots);

				foreach (Binder b in roots)
				{
					transaction.Lock(b.Address.Physical, AccessMode.Read);
					Storage.Current.ComplexFill(transaction, b, axis, collection);
				}
			}
			else
			{
				transaction.Lock(binder.Address.Physical, AccessMode.Read);
				Storage.Current.ComplexFill(transaction, binder, axis, collection);
			}
		}

		public IEnumerator GetEnumerator()
		{
			return ((IEnumerable<Binder>) this).GetEnumerator();
		}

		IEnumerator<Binder> IEnumerable<Binder>.GetEnumerator()
		{
			LinkedList<Binder> children = new LinkedList<Binder>();

			Fill(children);

			return children.GetEnumerator();
		}
	}
}
