using System;
using System.IO;
using Loxim.Diagnostics;

namespace Loxim.Store
{
	internal abstract class FileHandler
	{
		private readonly ErrorConsole console;
		private readonly FileType fileType;
		private readonly string fileName;
		private readonly double fileGrowth;
		private readonly int pageSize;
		private readonly int initialCount;

		private FileStream stream;
		private int pageCount;

		public FileHandler(FileType fileType, string fileName, double fileGrowth, int pageSize, int initialCount)
		{
			this.console = new ErrorConsole("File");
			this.fileType = fileType;
			this.fileName = fileName;
			this.fileGrowth = fileGrowth;
			this.pageSize = pageSize;
			this.initialCount = initialCount;
		}

		~FileHandler()
		{
		}

		public void Start()
		{
			lock (this)
			{
				bool created = false;

				if (!File.Exists(fileName))
				{
					stream = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
					console.WriteLine(LogLevel.Warning, "Create (fileName={0})", fileName);
					created = true;
				}
				else
				{
					stream = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
					console.WriteLine(LogLevel.Information, "Open (fileName={0})", fileName);
				}

				if (created)
				{
					pageCount = initialCount;

					stream.SetLength(pageCount * pageSize);

					InitializePages(0);
				}
				else
					pageCount = (int) (stream.Length / pageSize);
			}
		}

		public void Stop()
		{
			lock (this)
			{
				stream.Flush();
				stream = null;
			}
		}

		///////////////////////////////////////////////////////////////////////

		public FileType FileType { get { return fileType; } }
		public int PageCount { get { return pageCount; } }
		public int PageSize { get { return pageSize; } }

		private void InitializePages(int startOffset)
		{
			byte[] pageBuffer = new byte[pageSize];

			for (int pageOffset = startOffset; pageOffset < pageCount; pageOffset++)
			{
				for (int i = 0; i < pageBuffer.Length; i++)
					pageBuffer[i] = 0;

				InitializePage(pageOffset, pageBuffer);

				stream.Seek(pageOffset * pageSize, SeekOrigin.Begin);
				stream.Write(pageBuffer, 0, pageSize);
			}
		}

		protected unsafe virtual void InitializePage(int pageOffset, byte[] pageBuffer)
		{
			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				page->File = fileType;
				page->Offset = pageOffset;
				page->Category = PageCategory.Unspecified;
				page->Flags = PageFlags.None;
				page->IndexLength = 0;
				page->Free = pageBuffer.Length - sizeof(PageHeader);
				page->Time = 0;
			}
		}

		private void GrowIfNeeded(int pageOffset)
		{
			if (pageOffset < pageCount - 1)
				return;

			int oldCount = pageCount;
			pageCount = (int) Math.Ceiling(oldCount * (1.0 + fileGrowth));

			if (oldCount == pageCount)
				return;

			stream.SetLength(pageCount * pageSize);

			InitializePages(oldCount);
		}

		public void Read(int pageOffset, byte[] pageBuffer)
		{
			lock (this)
			{
				if (pageOffset < 0)
					throw new IndexOutOfRangeException();

				GrowIfNeeded(pageOffset);

				if (pageOffset >= pageCount)
					throw new IndexOutOfRangeException();

				if (pageBuffer.Length != pageSize)
					throw new ArgumentException();

				stream.Seek(pageOffset * pageSize, SeekOrigin.Begin);
				stream.Read(pageBuffer, 0, pageSize);
			}
		}

		public void Write(int pageOffset, byte[] pageBuffer)
		{
			lock (this)
			{
				if (pageOffset < 0)
					throw new IndexOutOfRangeException();

				GrowIfNeeded(pageOffset);

				if (pageOffset >= pageCount)
					throw new IndexOutOfRangeException();

				if (pageBuffer.Length != pageSize)
					throw new ArgumentException();

				stream.Seek(pageOffset * pageSize, SeekOrigin.Begin);
				stream.Write(pageBuffer, 0, pageSize);
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
