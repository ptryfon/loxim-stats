using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Loxim.Store
{
	public enum ObjectType : byte
	{
		Unspecified = 0,
		Boolean,
		Long,
		DateTime,
		Decimal,
		Double,
		Pointer,
		Binary,
		String,
		Complex,
	}

	[Flags]
	internal enum ObjectFlags : byte
	{
		None = 0,
		Complex = 1,
		Varying = 2,
		Meta = 4,
		TopLevel = 8,
	}

	[Flags]
	internal enum ComplexAxis : byte
	{
		Unassigned = 0,
		Children = 1,
		Roles = 2,
	}

	internal sealed partial class Storage
	{
		private sealed class StorageHandler : FileHandler
		{
			public StorageHandler(string fileName, double fileGrowth, int pageSize)
				: base(FileType.Storage, fileName, fileGrowth, pageSize, 16)
			{
			}

			protected override unsafe void InitializePage(int pageOffset, byte[] pageBuffer)
			{
				base.InitializePage(pageOffset, pageBuffer);

				if (pageOffset == 0)
				{
					fixed (byte* p = &pageBuffer[0])
					{
						PageHeader* page = (PageHeader*) p;
						ObjectEntry* entry = (ObjectEntry*) (p + sizeof(PageHeader));
						ComplexEntry* complex = (ComplexEntry*) (p + sizeof(PageHeader) + sizeof(ObjectEntry));
						VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader) + sizeof(ObjectEntry) + sizeof(ComplexEntry));

						entry->Length = sizeof(ObjectEntry) + sizeof(VaryingEntry);
						entry->Binder = Binder.Root;
						entry->Parent = Binder.Empty;
						entry->Flags = ObjectFlags.Complex | ObjectFlags.Varying | ObjectFlags.Meta;
						entry->Type = ObjectType.Complex;

						complex->RoleOf = Binder.Empty;

						varying->NotFinal = false;
						varying->Offset = 0;
						varying->Length = 0;

						IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - 1 * sizeof(IndexEntry));
						index->Offset = sizeof(PageHeader);

						page->Category = PageCategory.Regular;
						page->Flags |= PageFlags.Closed;
						page->Free -= sizeof(ObjectEntry) + sizeof(ComplexEntry) + sizeof(VaryingEntry);
						page->IndexLength = 1;
					}
				}
				else if (pageOffset == 1)
				{
					fixed (byte* p = &pageBuffer[0])
					{
						PageHeader* page = (PageHeader*) p;
						ObjectEntry* entry = (ObjectEntry*) (p + sizeof(PageHeader));
						ComplexEntry* complex = (ComplexEntry*) (p + sizeof(PageHeader) + sizeof(ObjectEntry));
						VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader) + sizeof(ObjectEntry) + sizeof(ComplexEntry));

						entry->Length = sizeof(ObjectEntry) + sizeof(VaryingEntry);
						entry->Binder = Binder.Names;
						entry->Parent = Binder.Empty;
						entry->Flags = ObjectFlags.Complex | ObjectFlags.Varying | ObjectFlags.Meta;
						entry->Type = ObjectType.Complex;

						complex->RoleOf = Binder.Empty;

						varying->NotFinal = false;
						varying->Offset = 0;
						varying->Length = 0;

						IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - 1 * sizeof(IndexEntry));
						index->Offset = sizeof(PageHeader);

						page->Category = PageCategory.Names;
						page->Flags |= PageFlags.Closed;
						page->Free -= sizeof(ObjectEntry) + sizeof(ComplexEntry) + sizeof(VaryingEntry);
						page->IndexLength = 1;
					}
				}
			}
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct IndexEntry
		{
			public byte Revision;
			public int Offset;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct ObjectEntry
		{
			public int Length;
			public Binder Binder;
			public Binder Parent;
			public ObjectFlags Flags;
			public ObjectType Type;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct ComplexEntry
		{
			public Binder RoleOf;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct VaryingEntry
		{
			public bool NotFinal;
			public int Offset;
			public int Length;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		private struct AxisEntry
		{
			public static AxisEntry Empty { get { return new AxisEntry(ComplexAxis.Unassigned, Binder.Empty); } }

			public ComplexAxis Axis;
			public Binder Binder;

			public AxisEntry(ComplexAxis axis, Binder binder)
			{
				this.Axis = axis;
				this.Binder = binder;
			}
		}
	}
}
