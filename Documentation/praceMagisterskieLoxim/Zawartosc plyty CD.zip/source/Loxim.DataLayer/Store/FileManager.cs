using System;
using System.Collections.Generic;

namespace Loxim.Store
{
	internal sealed class FileManager
	{
		private static FileManager current = null;

		public static FileManager Current
		{
			get { return current; }
		}

		///////////////////////////////////////////////////////////////////////

		private readonly Dictionary<FileType, FileHandler> handlers;

		public FileManager()
		{
			lock (typeof(FileManager))
			{
				if (current != null)
					throw new InvalidOperationException();

				current = this;
			}

			handlers = new Dictionary<FileType, FileHandler>();
		}

		~FileManager()
		{
			lock (typeof(FileManager))
			{
				if (current == this)
					current = null;
			}
		}

		public void Start()
		{
			lock (this)
			{
				foreach (KeyValuePair<FileType, FileHandler> handler in handlers)
					handler.Value.Start();
			}
		}

		public void Stop()
		{
			lock (this)
			{
				foreach (KeyValuePair<FileType, FileHandler> handler in handlers)
					handler.Value.Stop();
			}
		}

		///////////////////////////////////////////////////////////////////////

		public void RegisterHandler(FileHandler handler)
		{
			handlers.Add(handler.FileType, handler);
		}

		public FileHandler this[FileType fileType]
		{
			get
			{
				return handlers[fileType];
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
