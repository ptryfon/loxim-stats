using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;
using Loxim.Configuration;
using Loxim.Log;
using Loxim.Transactions;
using Loxim.Diagnostics;

namespace Loxim.Store
{
	internal sealed class PageBuffer
	{
		public long LastAccess;
		public bool Dirty;
		public byte[] Original;
		public byte[] Modified;
		public long TransactionID;

		public PageBuffer()
		{
			LastAccess = DateTime.Now.Ticks;
			Dirty = false;
			Original = null;
			Modified = null;
			TransactionID = 0;
		}

		public bool IsChanged()
		{
			if (Modified == null)
				return false;

			return !Memory.Equals(Original, 0, Modified, 0, Original.Length);
		}

		public void CommitChanges()
		{
			Dirty = true;
			Original = Modified;
			Modified = null;
			TransactionID = 0;
		}

		public void AbortChanges()
		{
			Modified = null;
			TransactionID = 0;
		}

		public void Release()
		{
			LastAccess = DateTime.Now.Ticks;

			Monitor.Exit(this);
		}
	}

	internal sealed class BufferManager
	{
		private static BufferManager current = null;

		public static BufferManager Current
		{
			get { return current; }
		}

		///////////////////////////////////////////////////////////////////////

		private readonly ErrorConsole console;
		private readonly StoreBufferElement config;
		private readonly Dictionary<Address, PageBuffer> buffers;
		private readonly ReaderWriterLock buffersLock;
		private readonly object flushMutex;
		private readonly object flushMonitor;
		private Thread flushThread;

		public BufferManager()
		{
			lock (typeof(BufferManager))
			{
				if (current != null)
					throw new InvalidOperationException();

				current = this;
			}

			console = new ErrorConsole("BufferManager");
			config = ((StoreSection) ConfigurationManager.GetSection("store")).Buffer;
			buffers = new Dictionary<Address, PageBuffer>();
			buffersLock = new ReaderWriterLock();
			flushMutex = new object();
			flushMonitor = new object();
		}

		~BufferManager()
		{
			lock (typeof(BufferManager))
			{
				if (current == this)
					current = null;
			}
		}

		public void Start()
		{
			lock (this)
			{
				flushThread = new Thread(new ThreadStart(DataWriter));
				flushThread.Name = "DataWriter";
				flushThread.IsBackground = true;

				flushThread.Start();
			}
		}

		public void Stop()
		{
			lock (this)
			{
				lock (flushMutex)
				{
					flushThread.Abort();
				}

				Flush(false, false);

				flushThread = null;
			}
		}

		///////////////////////////////////////////////////////////////////////

		private void DataWriter()
		{
			try
			{
				while (true)
				{
					bool dirtyRequest = false;

					try
					{
						Thread.Sleep(config.FlushInterval);
					}
					catch (ThreadInterruptedException)
					{
						dirtyRequest = true;
					}

					Flush(true, dirtyRequest);
				}
			}
			catch (ThreadAbortException)
			{
			}
		}

		internal void Flush()
		{
			Flush(false, false);
		}

		private void Flush(bool linger, bool forced)
		{
			lock (flushMutex)
			{
				while (true)
				{
					bool interrupted = false;

					try
					{
						Thread.Sleep(0);
					}
					catch
					{
						interrupted = true;
					}

					if (!interrupted)
						break;
				}

				buffersLock.AcquireReaderLock(-1);

				try
				{
					if (buffers.Count == 0)
						return;

					long maxTime = 0;
					long lingerTime = DateTime.Now.Subtract(config.LingerTime).Ticks;

					int flushed = 0;
					int discarded = 0;

					LogManager.Current.Lock();

					try
					{
						LinkedList<Address> removal = new LinkedList<Address>();

						foreach (KeyValuePair<Address, PageBuffer> entry in buffers)
						{
							Address address = entry.Key;
							PageBuffer page = entry.Value;

							lock (page)
							{
								if (page.Dirty)
								{
									FileManager.Current[address.File].Write(address.Offset, page.Original);
									page.Dirty = false;
									flushed++;

									long pageTime = PageHeader.GetTime(page.Original);
									if (pageTime > maxTime)
										maxTime = pageTime;
								}

								if (!page.Dirty && page.Modified == null && (!linger || page.LastAccess < lingerTime))
									removal.AddFirst(address);
							}
						}

						LockCookie cookie = buffersLock.UpgradeToWriterLock(-1);

						try
						{
							foreach (Address address in removal)
							{
								PageBuffer page;

								if (buffers.TryGetValue(address, out page))
								{
									lock (page)
									{
										if (!page.Dirty && page.Modified == null && (!linger || page.LastAccess < lingerTime))
										{
											buffers.Remove(address);
											discarded++;
										}
									}
								}
							}
						}
						finally
						{
							buffersLock.DowngradeFromWriterLock(ref cookie);
						}

						if (flushed > 0 || discarded > 0)
							console.WriteLine(LogLevel.Verbose, "Flush (time={0}, forced={1}, flushed={2}, discarded={3}, remaining={4})", maxTime, forced, flushed, discarded, buffers.Count);

						if (flushed > 0)
							LogManager.Current.WriteFlush(maxTime);
					}
					finally
					{
						LogManager.Current.Unlock();
					}
				}
				finally
				{
					buffersLock.ReleaseReaderLock();
				}

				lock (flushMonitor)
				{
					Monitor.PulseAll(flushMonitor);
				}
			}
		}

		///////////////////////////////////////////////////////////////////////

		public byte[] Acquire(Address address, Transaction transaction, AccessMode mode)
		{
			PageBuffer page = null;

			try
			{
				page = Acquire(address);

				if (page.Dirty && mode == AccessMode.Write)
				{
					page.Release();
					page = null;

					Monitor.Enter(flushMutex);

					page = Acquire(address);

					if (page.Dirty)
					{
						page.Release();
						page = null;

						Monitor.Enter(flushMonitor);
						flushThread.Interrupt();
						Monitor.Exit(flushMutex);

						Monitor.Wait(flushMonitor);
						Monitor.Exit(flushMonitor);

						page = Acquire(address);
					}
					else
						Monitor.Exit(flushMutex);
				}

				if (mode == AccessMode.Read)
				{
					if (page.Modified != null)
						if (page.TransactionID == transaction.TransactionID)
							return page.Modified;

					return page.Original;
				}

				// mode == AccessMode.Write
				if (page.Modified != null)
				{
					if (page.TransactionID != transaction.TransactionID)
						throw new InvalidOperationException();

					return page.Modified;
				}
				else
				{
					page.Modified = new byte[page.Original.Length];
					Memory.Copy(page.Original, 0, page.Modified, 0, page.Original.Length);
					page.TransactionID = transaction.TransactionID;

					return page.Modified;
				}
			}
			catch
			{
				try { Monitor.Exit(page); } catch { }
				try { Monitor.Exit(flushMutex); } catch { }
				try { Monitor.Exit(flushMonitor); } catch { }

				throw;
			}
		}

		internal PageBuffer Acquire(Address address)
		{
			PageBuffer page = null;

			try
			{
				buffersLock.AcquireReaderLock(-1);

				try
				{
					if (!buffers.TryGetValue(address.Physical, out page))
					{
						LockCookie cookie = buffersLock.UpgradeToWriterLock(-1);

						try
						{
							if (!buffers.TryGetValue(address.Physical, out page))
							{
								page = new PageBuffer();
								buffers.Add(address.Physical, page);
							}
						}
						finally
						{
							buffersLock.DowngradeFromWriterLock(ref cookie);
						}
					}

					Monitor.Enter(page);
				}
				finally
				{
					buffersLock.ReleaseReaderLock();
				}

				if (page.Original == null)
				{
					byte[] b = new byte[FileManager.Current[address.File].PageSize];
					FileManager.Current[address.File].Read(address.Offset, b);
					page.Original = b;
				}
			}
			catch
			{
				try { Monitor.Exit(page); } catch { }

				throw;
			}

			return page;
		}

		public void Release(Address address)
		{
			PageBuffer page = buffers[address.Physical];

			page.Release();
		}

		///////////////////////////////////////////////////////////////////////
	}
}
