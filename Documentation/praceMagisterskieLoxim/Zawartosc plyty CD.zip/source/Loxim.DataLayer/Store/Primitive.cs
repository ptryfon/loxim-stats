using System;
using System.Runtime.InteropServices;

namespace Loxim.Store
{
	//
	// Binder
	///////////////////////////////////////////////////////////////////////////

	[Serializable]
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct Binder
	{
		public static Binder Empty { get { return new Binder(Address.Empty, 0); } }
		internal static Binder Root { get { return new Binder(Address.Root, -1); } }
		internal static Binder Names { get { return new Binder(Address.Names, -1); } }

		///////////////////////////////////////////////////////////////////////

		private Address address;
		private int nameID;

		internal Binder(Address address, int nameID)
		{
			this.address = address;
			this.nameID = nameID;
		}

		///////////////////////////////////////////////////////////////////////

		public Address Address
		{
			get { return address; }
			internal set { address = value; }
		}

		public int NameID
		{
			get { return nameID; }
			internal set { nameID = value; }
		}

		///////////////////////////////////////////////////////////////////////

		public override string ToString()
		{
			return string.Format("<{0}, {1}>", address, nameID);
		}

		public override int GetHashCode()
		{
			return address.GetHashCode() ^ nameID.GetHashCode();
		}

		public override bool Equals(object o)
		{
			if (o == null || GetType() != o.GetType())
				return false;

			return address.Equals(((Binder) o).address) && nameID.Equals(((Binder) o).nameID);
		}

		public static bool operator ==(Binder x, Binder y)
		{
			return x.address == y.address && x.nameID == y.nameID;
		}

		public static bool operator !=(Binder x, Binder y)
		{
			return !(x == y);
		}
	}

	//
	// Address
	///////////////////////////////////////////////////////////////////////////

	[Serializable]
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct Address
	{
		public static Address Empty { get { return new Address(0L); } }
		internal static Address Root { get { return new Address(FileType.Storage, 0, 1, 0); } }
		internal static Address Names { get { return new Address(FileType.Storage, 1, 1, 0); } }

		///////////////////////////////////////////////////////////////////////

		private long address;

		private Address(long address)
		{
			this.address = address;
		}

		internal unsafe Address(FileType file, int offset, short index, byte revision)
		{
			fixed (long* p = &address)
			{
				*((FileType*) ((byte*) p + 0)) = file;
				*((int*) ((byte*) p + 1)) = offset;
				*((short*) ((byte*) p + 5)) = index;
				*((byte*) ((byte*) p + 7)) = revision;
			}
		}

		internal Address(FileType file, int offset, short index)
			: this(file, offset, index, 0)
		{
		}

		internal Address(FileType file, int offset)
			: this(file, offset, 0, 0)
		{
		}

		internal Address(FileType file)
			: this(file, 0, 0, 0)
		{
		}

		///////////////////////////////////////////////////////////////////////

		internal Address Physical
		{
			get { return new Address(File, Offset); }
		}

		public unsafe FileType File
		{
			get { fixed (long* p = &address) { return *((FileType*) ((byte*) p + 0)); } }
			internal set { fixed (long* p = &address) { *((FileType*) ((byte*) p + 0)) = value; } }
		}

		public unsafe int Offset
		{
			get { fixed (long* p = &address) { return *((int*) ((byte*) p + 1)); } }
			internal set { fixed (long* p = &address) { *((int*) ((byte*) p + 1)) = value; } }
		}

		public unsafe short Index
		{
			get { fixed (long* p = &address) { return *((short*) ((byte*) p + 5)); } }
			internal set { fixed (long* p = &address) { *((short*) ((byte*) p + 5)) = value; } }
		}

		public unsafe byte Revision
		{
			get { fixed (long* p = &address) { return *((byte*) ((byte*) p + 7)); } }
			internal set { fixed (long* p = &address) { *((byte*) ((byte*) p + 7)) = value; } }
		}

		///////////////////////////////////////////////////////////////////////

		internal long ToBinary()
		{
			return address;
		}

		internal static Address FromBinary(long address)
		{
			return new Address(address);
		}

		///////////////////////////////////////////////////////////////////////

		public unsafe override string ToString()
		{
			fixed (long* p = &address)
			{
				return string.Format("<{0}, {1}, {2}, {3}>",
					*((FileType*) ((byte*) p + 0)),
					*((int*) ((byte*) p + 1)),
					*((short*) ((byte*) p + 5)),
					*((byte*) ((byte*) p + 7))
				);
			}
		}

		public override int GetHashCode()
		{
			return address.GetHashCode();
		}

		public override bool Equals(object o)
		{
			if (o == null || GetType() != o.GetType())
				return false;

			return address.Equals(((Address) o).address);
		}

		public static bool operator ==(Address x, Address y)
		{
			return x.address == y.address;
		}

		public static bool operator !=(Address x, Address y)
		{
			return !(x == y);
		}
	}

	//
	// PageHeader
	///////////////////////////////////////////////////////////////////////////

	public enum FileType : byte
	{
		Storage = 1,
	}

	[Flags]
	internal enum PageFlags : byte
	{
		None = 0,
		Closed = 1,
		Chain = 1 | 2,
	}

	internal enum PageCategory : byte
	{
		Unspecified = 0,
		Regular,
		Roots,
		Names,
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	internal struct PageHeader
	{
		public FileType File;
		public int Offset;
		public PageCategory Category;
		public PageFlags Flags;
		public short IndexLength;
		public int Free;
		public long Time;

		public static unsafe long GetTime(byte[] pageBuffer)
		{
			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				return page->Time;
			}
		}

		public static unsafe void SetTime(byte[] pageBuffer, long time)
		{
			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				page->Time = time;
			}
		}
	}

	///////////////////////////////////////////////////////////////////////////
}
