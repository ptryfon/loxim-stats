using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Loxim.Configuration;
using Loxim.Transactions;
using Loxim.Diagnostics;

namespace Loxim.Store
{
	public class ObjectNotFoundException : Exception
	{
	}

	internal sealed partial class Storage
	{
		//
		// Object operations
		///////////////////////////////////////////////////////////////////////

		#region public unsafe Binder Create(Transaction transaction, Binder parent, int nameID, ObjectFlags flags, ObjectType type, object value, PageCategory category, bool closePage)
		public unsafe Binder Create(Transaction transaction, Binder parent, int nameID, ObjectFlags flags, ObjectType type, object value, PageCategory category, bool closePage)
		{
			bool varying;
			int length = GetEntryByteCount(type, out varying);
			int capacity = length;

			capacity += sizeof(IndexEntry);

			if (type == ObjectType.Complex)
				flags |= ObjectFlags.Complex;

			if (varying)
			{
				flags |= ObjectFlags.Varying;

				if (closePage)
					capacity = -1;
				else
				{
					int varyingLength = GetVaryingValueLength(type, value);

					if (capacity + varyingLength <= allocator.MaxFree)
						capacity += varyingLength;
				}
			}

			Address address = allocator.GetPage(transaction, category, capacity);
			Binder binder;

			byte[] entryBuffer = new byte[length];
			fixed (byte* p = &entryBuffer[0])
			{
				ObjectEntry* entry = (ObjectEntry*) p;
				entry->Length = entryBuffer.Length;
				entry->Binder = new Binder(Address.Empty, nameID);
				entry->Parent = parent;
				entry->Flags = flags;
				entry->Type = type;
			}

			byte[] pageBuffer = buffer.Acquire(address, transaction, AccessMode.Write);

			try
			{
				address = Insert(pageBuffer, entryBuffer, 0);
				binder = new Binder(address, nameID);

				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->Category == PageCategory.Unspecified)
						page->Category = category;

					if (closePage)
						page->Flags |= PageFlags.Closed;
				}
			}
			finally
			{
				buffer.Release(address);
			}

			if (type != ObjectType.Complex)
			{
				if (varying)
					VaryingSet(transaction, binder, value);
				else
					FixedSet(transaction, binder, value);
			}

			return binder;
		}
		#endregion

		#region public unsafe void Remove(Transaction transaction, Binder binder)
		public unsafe void Remove(Transaction transaction, Binder binder)
		{
			if (binder == Binder.Root)
				throw new ArgumentException();

			int chainOffset;

			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Write);

			try
			{
				byte[] entryBuffer;
				Remove(pageBuffer, binder.Address.Index, false, out entryBuffer, out chainOffset);
			}
			finally
			{
				buffer.Release(binder.Address);
			}

			if (chainOffset >= 0)
				RemoveChain(transaction, chainOffset);
		}
		#endregion

		#region private unsafe void RemoveChain(Transaction transaction, int offset)
		private unsafe void RemoveChain(Transaction transaction, int offset)
		{
			Address nextAddress = new Address(FileType.Storage, -1);
			nextAddress.Offset = offset;

			while (nextAddress.Offset >= 0)
			{
				Address chainAddress = nextAddress;

				transaction.Lock(chainAddress, AccessMode.Write);
				byte[] pageBuffer = buffer.Acquire(chainAddress, transaction, AccessMode.Write);

				try
				{
					fixed (byte* p = &pageBuffer[0])
					{
						PageHeader* page = (PageHeader*) p;
						VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader));

						if (varying->NotFinal)
							nextAddress.Offset = varying->Offset;
						else
							nextAddress.Offset = -1;

						int free = pageBuffer.Length - sizeof(PageHeader);
						page->Category = PageCategory.Unspecified;
						page->Flags &= ~PageFlags.Chain;
						page->Free = free;

						Memory.Zero(pageBuffer, sizeof(PageHeader), free);
					}
				}
				finally
				{
					buffer.Release(chainAddress);
				}
			}
		}
		#endregion

		#region public unsafe bool Exists(Transaction transaction, Binder binder)
		public unsafe bool Exists(Transaction transaction, Binder binder)
		{
			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Read);

			try
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->IndexLength < binder.Address.Index)
						return false;

					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
					int offset = index->Offset;

					ObjectEntry* entry = (ObjectEntry*) (p + offset);

					if (entry->Binder != binder || index->Revision != binder.Address.Revision)
						return false;

					return true;
				}
			}
			finally
			{
				buffer.Release(binder.Address);
			}
		}
		#endregion

		#region public unsafe void GetData(Transaction transaction, Binder binder, out Binder parent, out ObjectFlags flags, out ObjectType type, out Binder roleOf)
		public unsafe void GetData(Transaction transaction, Binder binder, out Binder parent, out ObjectFlags flags, out ObjectType type, out Binder roleOf)
		{
			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Read);

			try
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->IndexLength < binder.Address.Index)
						throw new ObjectNotFoundException();

					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
					int offset = index->Offset;

					ObjectEntry* entry = (ObjectEntry*) (p + offset);

					if (entry->Binder != binder || index->Revision != binder.Address.Revision)
						throw new ObjectNotFoundException();

					parent = entry->Parent;
					flags = entry->Flags;
					type = entry->Type;

					if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
					{
						ComplexEntry* complex = (ComplexEntry*) (p + offset + sizeof(ObjectEntry));

						roleOf = complex->RoleOf;
					}
					else
					{
						roleOf = Binder.Empty;
					}
				}
			}
			finally
			{
				buffer.Release(binder.Address);
			}
		}
		#endregion

		#region public unsafe void SetData(Transaction transaction, Binder binder, Binder parent, ObjectFlags flags, Binder roleOf)
		public unsafe void SetData(Transaction transaction, Binder binder, Binder parent, ObjectFlags flags, Binder roleOf)
		{
			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Write);

			try
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->IndexLength < binder.Address.Index)
						throw new ObjectNotFoundException();

					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
					int offset = index->Offset;

					ObjectEntry* entry = (ObjectEntry*) (p + offset);

					if (entry->Binder != binder || index->Revision != binder.Address.Revision)
						throw new ObjectNotFoundException();

					entry->Parent = parent;
					entry->Flags = flags;

					if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
					{
						ComplexEntry* complex = (ComplexEntry*) (p + offset + sizeof(ObjectEntry));

						complex->RoleOf = roleOf;
					}
				}
			}
			finally
			{
				buffer.Release(binder.Address);
			}
		}
		#endregion

		//
		// Value operations
		///////////////////////////////////////////////////////////////////////

		#region private unsafe int GetEntryByteCount(ObjectType type, out bool varying)
		private unsafe int GetEntryByteCount(ObjectType type, out bool varying)
		{
			varying = false;

			switch (type)
			{
				case ObjectType.Boolean:
					return sizeof(ObjectEntry) + sizeof(bool);
				case ObjectType.Long:
				case ObjectType.DateTime:
					return sizeof(ObjectEntry) + sizeof(long);
				case ObjectType.Decimal:
					return sizeof(ObjectEntry) + sizeof(decimal);
				case ObjectType.Double:
					return sizeof(ObjectEntry) + sizeof(double);
				case ObjectType.Pointer:
					return sizeof(ObjectEntry) + sizeof(Binder);
				case ObjectType.Binary:
				case ObjectType.String:
					varying = true;
					return sizeof(ObjectEntry) + sizeof(VaryingEntry);
				case ObjectType.Complex:
					varying = true;
					return sizeof(ObjectEntry) + sizeof(ComplexEntry) + sizeof(VaryingEntry);
			}

			throw new ArgumentException();
		}
		#endregion

		#region private unsafe int GetVaryingValueLength(ObjectType type, object value)
		private unsafe int GetVaryingValueLength(ObjectType type, object value)
		{
			switch (type)
			{
				case ObjectType.Binary:
					return ((byte[]) value).Length;
				case ObjectType.String:
					return encoding.GetByteCount((string) value);
				case ObjectType.Complex:
					return 0;
			}

			throw new ArgumentException();
		}
		#endregion

		///////////////////////////////////////////////////////////////////////

		#region public unsafe object FixedGet(Transaction transaction, Binder binder)
		public unsafe object FixedGet(Transaction transaction, Binder binder)
		{
			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Read);

			try
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->IndexLength < binder.Address.Index)
						throw new ObjectNotFoundException();

					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
					int offset = index->Offset;

					ObjectEntry* entry = (ObjectEntry*) (p + offset);

					if (entry->Binder != binder || index->Revision != binder.Address.Revision)
						throw new ObjectNotFoundException();

					if (entry->Type == ObjectType.Boolean)
						return *((bool*) (p + offset + sizeof(ObjectEntry)));
					else if (entry->Type == ObjectType.Long)
						return *((long*) (p + offset + sizeof(ObjectEntry)));
					else if (entry->Type == ObjectType.DateTime)
						return DateTime.FromBinary(*((long*) (p + offset + sizeof(ObjectEntry))));
					else if (entry->Type == ObjectType.Decimal)
						return *((decimal*) (p + offset + sizeof(ObjectEntry)));
					else if (entry->Type == ObjectType.Double)
						return *((double*) (p + offset + sizeof(ObjectEntry)));
					else if (entry->Type == ObjectType.Pointer)
						return *((Binder*) (p + offset + sizeof(ObjectEntry)));

					throw new InvalidOperationException();
				}
			}
			finally
			{
				buffer.Release(binder.Address);
			}
		}
		#endregion

		#region public unsafe void FixedSet(Transaction transaction, Binder binder, object value)
		public unsafe void FixedSet(Transaction transaction, Binder binder, object value)
		{
			byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Write);

			try
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if (page->IndexLength < binder.Address.Index)
						throw new ObjectNotFoundException();

					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
					int offset = index->Offset;

					ObjectEntry* entry = (ObjectEntry*) (p + offset);

					if (entry->Binder != binder || index->Revision != binder.Address.Revision)
						throw new ObjectNotFoundException();

					if (entry->Type == ObjectType.Boolean)
						*((bool*) (p + offset + sizeof(ObjectEntry))) = (bool) value;
					else if (entry->Type == ObjectType.Long)
						*((long*) (p + offset + sizeof(ObjectEntry))) = (long) value;
					else if (entry->Type == ObjectType.DateTime)
						*((long*) (p + offset + sizeof(ObjectEntry))) = ((DateTime) value).ToBinary();
					else if (entry->Type == ObjectType.Decimal)
						*((decimal*) (p + offset + sizeof(ObjectEntry))) = (decimal) value;
					else if (entry->Type == ObjectType.Double)
						*((double*) (p + offset + sizeof(ObjectEntry))) = (double) value;
					else if (entry->Type == ObjectType.Pointer)
						*((Binder*) (p + offset + sizeof(ObjectEntry))) = (Binder) value;
					else
						throw new InvalidOperationException();
				}
			}
			finally
			{
				buffer.Release(binder.Address);
			}
		}
		#endregion

		///////////////////////////////////////////////////////////////////////

		#region public unsafe object VaryingGet(Transaction transaction, Binder binder)
		public unsafe object VaryingGet(Transaction transaction, Binder binder)
		{
			VaryingGetState state = new VaryingGetState();
			state.ObjectType = ObjectType.Unspecified;
			state.MemoryStream = new MemoryStream();

			VaryingReader(transaction, binder, VaryingGetHandler, state);

			if (state.ObjectType == ObjectType.Binary)
				return state.MemoryStream.ToArray();
			else if (state.ObjectType == ObjectType.String)
				return encoding.GetString(state.MemoryStream.ToArray());

			return null;
		}

		private class VaryingGetState
		{
			public ObjectType ObjectType;
			public MemoryStream MemoryStream;
		}

		private unsafe bool VaryingGetHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			VaryingGetState s = (VaryingGetState) state;

			if (entry != null)
			{
				if (entry->Type == ObjectType.Binary)
					s.ObjectType = ObjectType.Binary;
				if (entry->Type == ObjectType.String)
					s.ObjectType = ObjectType.String;
				else
					throw new InvalidOperationException();
			}

			byte* p = (((byte*) varying) + sizeof(VaryingEntry));

			for (int i = 0; i < varying->Length; i++, p++)
				s.MemoryStream.WriteByte(*p);

			return false;
		}
		#endregion

		#region public unsafe void VaryingSet(Transaction transaction, Binder binder, object value)
		public unsafe void VaryingSet(Transaction transaction, Binder binder, object value)
		{
			VaryingSetState state = new VaryingSetState();
			state.Value = value;
			state.Buffer = null;
			state.StoredLength = 0;

			VaryingWriter(transaction, binder, VaryingSetHandler, state);
		}

		private class VaryingSetState
		{
			public object Value;
			public byte[] Buffer;
			public int StoredLength;
		}

		private unsafe WriterHandlerResult VaryingSetHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			VaryingSetState s = (VaryingSetState) state;

			if (entry != null)
			{
				if (entry->Type == ObjectType.Binary)
					s.Buffer = (byte[]) s.Value;
				else if (entry->Type == ObjectType.String)
					s.Buffer = encoding.GetBytes((string) s.Value);
				else
					throw new InvalidOperationException();
			}

			if (entry != null)
				entry->Length -= varying->Length;

			Memory.Zero((byte*) varying + sizeof(VaryingEntry), varying->Length);
			page->Free += varying->Length;
			varying->Length = 0;

			int length;
			if (s.Buffer.Length - s.StoredLength > page->Free)
				length = page->Free;
			else
				length = s.Buffer.Length - s.StoredLength;

			fixed (byte* p = &s.Buffer[0])
				Memory.Copy(p + s.StoredLength, (byte*) varying + sizeof(VaryingEntry), length);
			page->Free -= length;
			varying->Length = length;

			if (entry != null)
				entry->Length += length;

			s.StoredLength += length;

			if (s.StoredLength < s.Buffer.Length)
				return WriterHandlerResult.ExpandAtEnd;
			else
				return WriterHandlerResult.StopAtEnd;
		}
		#endregion

		///////////////////////////////////////////////////////////////////////

		#region public unsafe void ComplexFill(Transaction transaction, Binder binder, ComplexAxis axis, ICollection<Binder> collection)
		public unsafe void ComplexFill(Transaction transaction, Binder binder, ComplexAxis axis, ICollection<Binder> collection)
		{
			ComplexFillState state = new ComplexFillState();
			state.Axis = axis;
			state.Collection = collection;

			VaryingReader(transaction, binder, ComplexFillHandler, state);
		}

		private class ComplexFillState
		{
			public ComplexAxis Axis;
			public ICollection<Binder> Collection;
		}

		private unsafe bool ComplexFillHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			ComplexFillState s = (ComplexFillState) state;

			for (int i = 0; i < varying->Length / sizeof(AxisEntry); i++)
			{
				AxisEntry* complex = (AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + i * sizeof(AxisEntry));

				if ((complex->Axis & s.Axis) != 0)
					s.Collection.Add(complex->Binder);
			}

			return false;
		}
		#endregion

		#region private unsafe void ComplexCopy(Transaction transaction, Binder binder, ComplexAxis axis, ICollection<AxisEntry> collection)
		private unsafe void ComplexCopy(Transaction transaction, Binder binder, ComplexAxis axis, ICollection<AxisEntry> collection)
		{
			ComplexCopyState state = new ComplexCopyState();
			state.Axis = axis;
			state.Collection = collection;

			VaryingReader(transaction, binder, ComplexCopyHandler, state);
		}

		private class ComplexCopyState
		{
			public ComplexAxis Axis;
			public ICollection<AxisEntry> Collection;
		}

		private unsafe bool ComplexCopyHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			ComplexCopyState s = (ComplexCopyState) state;

			for (int i = 0; i < varying->Length / sizeof(AxisEntry); i++)
			{
				AxisEntry* complex = (AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + i * sizeof(AxisEntry));

				if ((complex->Axis & s.Axis) != 0)
					s.Collection.Add(*complex);
			}

			return false;
		}
		#endregion

		#region public unsafe Binder ComplexFind(Transaction transaction, Binder binder, ComplexAxis axis, int nameID)
		public unsafe Binder ComplexFind(Transaction transaction, Binder binder, ComplexAxis axis, int nameID)
		{
			ComplexFindState state = new ComplexFindState();
			state.Axis = axis;
			state.Binder = Binder.Empty;
			state.NameID = nameID;

			VaryingReader(transaction, binder, ComplexFindHandler, state);

			return state.Binder;
		}

		private class ComplexFindState
		{
			public ComplexAxis Axis;
			public int NameID;
			public Binder Binder;
		}

		private unsafe bool ComplexFindHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			ComplexFindState s = (ComplexFindState) state;

			for (int i = 0; i < varying->Length / sizeof(AxisEntry); i++)
			{
				AxisEntry* complex = (AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + i * sizeof(AxisEntry));

				if (complex->Axis == s.Axis && complex->Binder.NameID == s.NameID)
				{
					s.Binder = complex->Binder;
					return true;
				}
			}

			return false;
		}
		#endregion

		#region public unsafe void ComplexAdd(Transaction transaction, Binder binder, ComplexAxis axis, Binder child)
		public unsafe void ComplexAdd(Transaction transaction, Binder binder, ComplexAxis axis, Binder child)
		{
			VaryingWriter(transaction, binder, ComplexAddHandler, new AxisEntry(axis, child));
		}

		private unsafe WriterHandlerResult ComplexAddHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			if (page->Free >= sizeof(AxisEntry))
			{
				*((AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + varying->Length)) = (AxisEntry) state;

				varying->Length += sizeof(AxisEntry);
				page->Free -= sizeof(AxisEntry);

				if (entry != null)
					entry->Length += sizeof(AxisEntry);

				return WriterHandlerResult.StopNow;
			}

			return WriterHandlerResult.ExpandAtEnd;
		}
		#endregion

		#region public unsafe void ComplexRemove(Transaction transaction, Binder binder, ComplexAxis axis, Binder child)
		public unsafe void ComplexRemove(Transaction transaction, Binder binder, ComplexAxis axis, Binder child)
		{
			VaryingWriter(transaction, binder, ComplexRemoveHandler, new AxisEntry(axis, child));
		}

		private unsafe WriterHandlerResult ComplexRemoveHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state)
		{
			int childIndex = -1;
			for (int i = 0; i < varying->Length / sizeof(AxisEntry); i++)
			{
				AxisEntry* complex = (AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + i * sizeof(AxisEntry));

				if (complex->Axis == ((AxisEntry) state).Axis && complex->Binder == ((AxisEntry) state).Binder)
				{
					childIndex = i;
					break;
				}
			}

			if (childIndex >= 0)
			{
				if (childIndex < ((varying->Length / sizeof(AxisEntry)) - 1))
					*((AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + childIndex * sizeof(AxisEntry))) = *((AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + ((varying->Length / sizeof(AxisEntry)) - 1) * sizeof(AxisEntry)));

				*((AxisEntry*) (((byte*) varying) + sizeof(VaryingEntry) + ((varying->Length / sizeof(AxisEntry)) - 1) * sizeof(AxisEntry))) = AxisEntry.Empty;

				varying->Length -= sizeof(AxisEntry);
				page->Free += sizeof(AxisEntry);

				if (entry != null)
					entry->Length -= sizeof(AxisEntry);

				return WriterHandlerResult.StopNow;
			}

			return WriterHandlerResult.StopAtEnd;
		}
		#endregion

		///////////////////////////////////////////////////////////////////////

		#region private unsafe void VaryingReader(Transaction transaction, Binder binder, VariableReaderHandler entryFunction, object state)
		private unsafe delegate bool VaryingReaderHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state);

		private unsafe void VaryingReader(Transaction transaction, Binder binder, VaryingReaderHandler entryFunction, object state)
		{
			Address nextAddress = new Address(FileType.Storage);

			{
				byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Read);

				try
				{
					fixed (byte* p = &pageBuffer[0])
					{
						PageHeader* page = (PageHeader*) p;

						if (page->IndexLength < binder.Address.Index)
							throw new ObjectNotFoundException();

						IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
						int offset = index->Offset;

						ObjectEntry* entry = (ObjectEntry*) (p + offset);

						if (entry->Binder != binder || index->Revision != binder.Address.Revision)
							throw new ObjectNotFoundException();

						VaryingEntry* varying;
						if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
							varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry) + sizeof(ComplexEntry));
						else
							varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry));

						if (entryFunction(page, entry, varying, state))
							return;

						if (varying->NotFinal)
							nextAddress.Offset = varying->Offset;
						else
							return;
					}
				}
				finally
				{
					buffer.Release(binder.Address);
				}
			}

			while (true)
			{
				Address chainAddress = nextAddress;

				byte[] pageBuffer = buffer.Acquire(chainAddress, transaction, AccessMode.Read);

				try
				{
					fixed (byte* p = &pageBuffer[0])
					{
						PageHeader* page = (PageHeader*) p;
						VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader));

						if (entryFunction(page, null, varying, state))
							return;

						if (varying->NotFinal)
							nextAddress.Offset = varying->Offset;
						else
							return;
					}
				}
				finally
				{
					buffer.Release(chainAddress);
				}
			}
		}
		#endregion

		#region private unsafe void VaryingWriter(Transaction transaction, Binder binder, VariableWriterHandler entryFunction, object state)
		private enum WriterHandlerResult
		{
			StopNow,
			StopAtEnd,
			ExpandAtEnd,
		}

		private unsafe delegate WriterHandlerResult VaryingWriterHandler(PageHeader* page, ObjectEntry* entry, VaryingEntry* varying, object state);

		private unsafe void VaryingWriter(Transaction transaction, Binder binder, VaryingWriterHandler entryFunction, object state)
		{
			Address nextAddress = new Address(FileType.Storage);
			bool created;

			{
				bool expand = false;

				{
					byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Write);

					try
					{
						fixed (byte* p = &pageBuffer[0])
						{
							PageHeader* page = (PageHeader*) p;

							if (page->IndexLength < binder.Address.Index)
								throw new ObjectNotFoundException();

							SwapLast(pageBuffer, binder.Address.Index);

							IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
							int offset = index->Offset;

							ObjectEntry* entry = (ObjectEntry*) (p + offset);

							if (entry->Binder != binder || index->Revision != binder.Address.Revision)
								throw new ObjectNotFoundException();

							VaryingEntry* varying;
							if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
								varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry) + sizeof(ComplexEntry));
							else
								varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry));

							WriterHandlerResult result = entryFunction(page, entry, varying, state);

							if (result == WriterHandlerResult.StopNow)
								return;

							if (varying->NotFinal)
								nextAddress.Offset = varying->Offset;
							else if (result == WriterHandlerResult.ExpandAtEnd)
								expand = true;
							else
								return;
						}
					}
					finally
					{
						buffer.Release(binder.Address);
					}
				}

				if (expand)
				{
					nextAddress = allocator.GetPage(transaction, PageCategory.Regular, -1);

					byte[] pageBuffer = buffer.Acquire(binder.Address, transaction, AccessMode.Write);

					try
					{
						fixed (byte* p = &pageBuffer[0])
						{
							IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - binder.Address.Index * sizeof(IndexEntry));
							int offset = index->Offset;

							ObjectEntry* entry = (ObjectEntry*) (p + offset);

							VaryingEntry* varying;
							if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
								varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry) + sizeof(ComplexEntry));
							else
								varying = (VaryingEntry*) (p + offset + sizeof(ObjectEntry));

							varying->NotFinal = true;
							varying->Offset = nextAddress.Offset;
						}
					}
					finally
					{
						buffer.Release(binder.Address);
					}

					created = true;
				}
				else
					created = false;
			}

			while (true)
			{
				bool expand = false;
				Address chainAddress = nextAddress;

				transaction.Lock(chainAddress, AccessMode.Write);

				{
					byte[] pageBuffer = buffer.Acquire(chainAddress, transaction, AccessMode.Write);

					try
					{
						fixed (byte* p = &pageBuffer[0])
						{
							PageHeader* page = (PageHeader*) p;
							VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader));

							if (created)
							{
								page->Category = PageCategory.Regular;
								page->Flags |= PageFlags.Chain;
								page->Free -= sizeof(VaryingEntry);
							}

							WriterHandlerResult result = entryFunction(page, null, varying, state);

							if (result == WriterHandlerResult.StopNow)
								return;

							if (varying->NotFinal)
								nextAddress.Offset = varying->Offset;
							else if (result == WriterHandlerResult.ExpandAtEnd)
								expand = true;
							else
								return;
						}
					}
					finally
					{
						buffer.Release(chainAddress);
					}
				}

				if (expand)
				{
					nextAddress = allocator.GetPage(transaction, PageCategory.Regular, -1);

					byte[] pageBuffer = buffer.Acquire(chainAddress, transaction, AccessMode.Write);

					try
					{
						fixed (byte* p = &pageBuffer[0])
						{
							VaryingEntry* varying = (VaryingEntry*) (p + sizeof(PageHeader));

							varying->NotFinal = true;
							varying->Offset = nextAddress.Offset;
						}
					}
					finally
					{
						buffer.Release(chainAddress);
					}

					created = true;
				}
				else
					created = false;
			}
		}
		#endregion

		//
		// Page buffer operations
		///////////////////////////////////////////////////////////////////////

		#region private Address short Insert(byte[] pageBuffer, byte[] entryBuffer, short index)
		private unsafe Address Insert(byte[] pageBuffer, byte[] entryBuffer, short indexPosition)
		{
			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				int lastOffset = 0;
				short freeIndex = indexPosition;

				for (short i = 1; i <= page->IndexLength; i++)
				{
					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - i * sizeof(IndexEntry));

					if (index->Offset == 0 && index->Revision < byte.MaxValue)
					{
						if (freeIndex == 0)
							freeIndex = i;
					}
					else if (index->Offset > lastOffset)
						lastOffset = index->Offset;
				}

				if (lastOffset == 0)
					lastOffset = sizeof(PageHeader);
				else
					lastOffset += ((ObjectEntry*) (p + lastOffset))->Length;

				if (freeIndex == 0)
				{
					page->Free -= sizeof(IndexEntry);
					page->IndexLength++;

					freeIndex = page->IndexLength;
				}

				Address address;

				{
					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - freeIndex * sizeof(IndexEntry));
					index->Offset = lastOffset;

					address = new Address(page->File, page->Offset, freeIndex, index->Revision);
				}

				fixed (byte* pp = &entryBuffer[0])
				{
					ObjectEntry* entry = (ObjectEntry*) pp;
					entry->Binder.Address = address;
				}

				Memory.Copy(entryBuffer, 0, pageBuffer, lastOffset, entryBuffer.Length);

				page->Free -= entryBuffer.Length;

				return address;
			}
		}
		#endregion

		#region private unsafe void Remove(byte[] pageBuffer, short index, bool isSwap, out byte[] entryBuffer, out int chainOffset)
		private unsafe void Remove(byte[] pageBuffer, short indexPosition, bool isSwap, out byte[] entryBuffer, out int chainOffset)
		{
			chainOffset = -1;

			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				IndexEntry* removeIndex = (IndexEntry*) (p + pageBuffer.Length - indexPosition * sizeof(IndexEntry));
				int removeOffset = removeIndex->Offset;
				int removeLength = ((ObjectEntry*) (p + removeOffset))->Length;

				int lastOffset = 0;

				for (short i = 1; i <= page->IndexLength; i++)
				{
					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - i * sizeof(IndexEntry));
					int offset = index->Offset;

					if (offset > lastOffset)
						lastOffset = offset;
				}

				if (isSwap)
				{
					entryBuffer = new byte[removeLength];
					Memory.Copy(pageBuffer, removeOffset, entryBuffer, 0, removeLength);
				}
				else
				{
					entryBuffer = null;

					ObjectEntry* entry = (ObjectEntry*) (p + removeOffset);

					if ((entry->Flags & ObjectFlags.Varying) == ObjectFlags.Varying)
					{
						VaryingEntry* varying;
						if ((entry->Flags & ObjectFlags.Complex) == ObjectFlags.Complex)
							varying = (VaryingEntry*) (p + removeOffset + sizeof(ObjectEntry) + sizeof(ComplexEntry));
						else
							varying = (VaryingEntry*) (p + removeOffset + sizeof(ObjectEntry));

						if (varying->NotFinal)
							chainOffset = varying->Offset;
					}
				}

				if (removeOffset < lastOffset)
				{
					int lastLength = ((ObjectEntry*) (p + lastOffset))->Length;

					Memory.Copy(pageBuffer, removeOffset + removeLength, pageBuffer, removeOffset, lastOffset + lastLength - removeOffset - removeLength);
					Memory.Zero(pageBuffer, lastOffset + lastLength - removeLength, removeLength);

					for (short i = 1; i <= page->IndexLength; i++)
					{
						IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - i * sizeof(IndexEntry));

						if (index->Offset > removeOffset)
							index->Offset -= removeLength;
					}
				}
				else
					Memory.Zero(pageBuffer, removeOffset, removeLength);

				page->Free += removeLength;

				removeIndex->Offset = 0;

				if (!isSwap)
					removeIndex->Revision++;
			}
		}
		#endregion

		#region private unsafe void SwapLast(byte[] pageBuffer, short index)
		private unsafe void SwapLast(byte[] pageBuffer, short indexPosition)
		{
			bool shouldSwap = false;

			fixed (byte* p = &pageBuffer[0])
			{
				PageHeader* page = (PageHeader*) p;

				IndexEntry* swapIndex = (IndexEntry*) (p + pageBuffer.Length - indexPosition * sizeof(IndexEntry));

				for (short i = 1; i <= page->IndexLength; i++)
				{
					IndexEntry* index = (IndexEntry*) (p + pageBuffer.Length - i * sizeof(IndexEntry));

					if (index->Offset > swapIndex->Offset)
					{
						shouldSwap = true;
						break;
					}
				}
			}

			if (shouldSwap)
			{
				byte[] entryBuffer;
				int chainOffset;
				Remove(pageBuffer, indexPosition, true, out entryBuffer, out chainOffset);

				Insert(pageBuffer, entryBuffer, indexPosition);
			}
		}
		#endregion

		///////////////////////////////////////////////////////////////////////
	}
}
