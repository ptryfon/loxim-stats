using System;
using System.Collections.Generic;
using System.Threading;
using Loxim.Transactions;

namespace Loxim.Store
{
	public enum AllocationType
	{
		Sequential = 1,
	}

	public class FileFullException : Exception
	{
		private FileType file;

		public FileFullException(FileType file)
		{
			this.file = file;
		}

		public FileType File
		{
			get { return file; }
		}
	}

	internal sealed partial class Storage
	{
		internal abstract class BaseAllocator
		{
			private readonly BufferManager buffer;
			private readonly FileHandler handler;
			private readonly double fillLevel;
			private readonly int maxFree;

			public unsafe BaseAllocator(BufferManager buffer, FileHandler handler, double fillLevel)
			{
				this.buffer = buffer;
				this.handler = handler;
				this.fillLevel = fillLevel;
				this.maxFree = handler.PageSize - sizeof(PageHeader);
			}

			protected BufferManager Buffer { get { return buffer; } }
			protected FileHandler Handler { get { return handler; } }
			protected double FillLevel { get { return fillLevel; } }
			public int MaxFree { get { return maxFree; } }

			public abstract Address GetPage(Transaction transaction, PageCategory category, int capacity);
		}

		internal sealed class SequentialAlocator : BaseAllocator
		{
			private Dictionary<PageCategory, int> lastOffsets;

			public SequentialAlocator(BufferManager buffer, FileHandler handler, double fillLevel)
				: base(buffer, handler, fillLevel)
			{
				lastOffsets = new Dictionary<PageCategory, int>();

				foreach (PageCategory category in Enum.GetValues(typeof(PageCategory)))
					lastOffsets[category] = 0;
			}

			public override Address GetPage(Transaction transaction, PageCategory category, int capacity)
			{
				if (category == PageCategory.Unspecified)
					throw new InvalidOperationException();

				if (capacity <= 0 || capacity > MaxFree)
					capacity = MaxFree;

				bool triedLock;
				Address pageAddress = new Address(FileType.Storage);

				triedLock = false;

				for (int i = lastOffsets[category]; i < Handler.PageCount; i++)
				{
					pageAddress.Offset = i;

					{
						byte[] pageBuffer = Buffer.Acquire(pageAddress, transaction, AccessMode.Read);

						try
						{
							if (!IsValid(pageBuffer, category, capacity))
							{
								if (!triedLock)
									lastOffsets[category] = i;

								continue;
							}
						}
						finally
						{
							Buffer.Release(pageAddress);
						}
					}

					triedLock = true;

					if (transaction.TryLock(pageAddress, AccessMode.Write))
					{
						byte[] pageBuffer = Buffer.Acquire(pageAddress, transaction, AccessMode.Read);

						try
						{
							if (IsValid(pageBuffer, category, capacity))
								return pageAddress;
						}
						finally
						{
							Buffer.Release(pageAddress);
						}
					}
				}

				triedLock = false;

				for (int i = 0; i < Handler.PageCount; i++)
				{
					pageAddress.Offset = i;

					{
						byte[] pageBuffer = Buffer.Acquire(pageAddress, transaction, AccessMode.Read);

						try
						{
							if (!IsValid(pageBuffer, category, capacity))
							{
								if (!triedLock)
									lastOffsets[category] = i;

								continue;
							}
						}
						finally
						{
							Buffer.Release(pageAddress);
						}
					}

					triedLock = true;

					{
						transaction.Lock(pageAddress, AccessMode.Write);

						byte[] pageBuffer = Buffer.Acquire(pageAddress, transaction, AccessMode.Read);

						try
						{
							if (IsValid(pageBuffer, category, capacity))
								return pageAddress;
						}
						finally
						{
							Buffer.Release(pageAddress);
						}
					}
				}

				throw new FileFullException(FileType.Storage);
			}

			private unsafe bool IsValid(byte[] pageBuffer, PageCategory category, int capacity)
			{
				fixed (byte* p = &pageBuffer[0])
				{
					PageHeader* page = (PageHeader*) p;

					if ((page->Flags & PageFlags.Closed) != 0)
						return false;

					if (page->Free < capacity)
						return false;

					if (page->IndexLength == short.MaxValue)
						return false;

					if (page->Category != PageCategory.Unspecified && page->Category != category)
						return false;

					if ((double) (MaxFree - page->Free - capacity) / (double) MaxFree > FillLevel)
						return false;
				}

				return true;
			}
		}
	}
}
