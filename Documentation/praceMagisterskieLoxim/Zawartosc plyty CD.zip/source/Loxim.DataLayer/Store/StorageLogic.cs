using System;
using System.Collections.Generic;
using Loxim.Diagnostics;
using Loxim.Transactions;

namespace Loxim.Store
{
	public class NestingException : Exception
	{
	}

	internal sealed partial class Storage
	{
		///////////////////////////////////////////////////////////////////////

		public ObjectPointer GetObject(Transaction transaction, Binder binder)
		{
			Binder parent;
			ObjectFlags flags;
			ObjectType type;
			Binder roleOf;

			transaction.Lock(binder.Address.Physical, AccessMode.Read);
			GetData(transaction, binder, out parent, out flags, out type, out roleOf);

			return new ObjectPointer(transaction, binder, type);
		}

		///////////////////////////////////////////////////////////////////////

		public BinderCollection GetRoots(Transaction transaction)
		{
			return new BinderCollection(transaction, Binder.Root, ComplexAxis.Children);
		}

		public BinderCollection GetRoots(Transaction transaction, int nameID)
		{
			Binder nameRootBinder = ComplexFind(transaction, Binder.Root, ComplexAxis.Children, nameID);

			return new BinderCollection(transaction, nameRootBinder, ComplexAxis.Children);
		}

		///////////////////////////////////////////////////////////////////////

		public ObjectPointer CreateObject(Transaction transaction, int nameID, Binder parent, ObjectType type, object value)
		{
			if (value == null && type != ObjectType.Complex)
				throw new ArgumentNullException();

			PreserveTranslation(transaction, nameID);

			ObjectFlags flags = ObjectFlags.None;

			if (parent == Binder.Empty)
			{
				transaction.Lock(Binder.Root.Address.Physical, AccessMode.Read);
				Binder nameBinder = ComplexFind(transaction, Binder.Root, ComplexAxis.Children, nameID);

				if (nameBinder == Binder.Empty)
				{
					transaction.Lock(Binder.Root.Address.Physical, AccessMode.Write);
					nameBinder = ComplexFind(transaction, Binder.Root, ComplexAxis.Children, nameID);

					if (nameBinder == Binder.Empty)
					{
						nameBinder = Create(transaction, Binder.Root, nameID, ObjectFlags.Meta, ObjectType.Complex, null, PageCategory.Regular, true);
						ComplexAdd(transaction, Binder.Root, ComplexAxis.Children, nameBinder);
						console.WriteLine(LogLevel.Verbose, "RootAdd (nameID={0})", nameID);
					}
				}
				else
					transaction.Lock(nameBinder.Address.Physical, AccessMode.Write);

				parent = nameBinder;
				flags |= ObjectFlags.TopLevel;
			}
			else
				transaction.Lock(parent.Address.Physical, AccessMode.Write);

			Binder binder = Create(transaction, parent, nameID, flags, type, value, PageCategory.Regular, false);
			ComplexAdd(transaction, parent, ComplexAxis.Children, binder);

			return new ObjectPointer(transaction, binder, type);
		}

		public void RemoveObject(Transaction transaction, Binder binder)
		{
			bool first = true;
			Dictionary<Binder, bool> removed = new Dictionary<Binder, bool>();
			LinkedList<AxisEntry> children = new LinkedList<AxisEntry>();

			children.AddLast(new AxisEntry(ComplexAxis.Children, binder));

			while (children.Count > 0)
			{
				Binder current = children.First.Value.Binder;

				Binder parent;
				ObjectFlags flags;
				ObjectType type;
				Binder roleOf;

				transaction.Lock(current.Address.Physical, AccessMode.Write);
				GetData(transaction, current, out parent, out flags, out type, out roleOf);

				if (first)
				{
					transaction.Lock(parent.Address.Physical, AccessMode.Write);
					ComplexRemove(transaction, parent, ComplexAxis.Children, current);

					if (roleOf != Binder.Empty)
					{
						transaction.Lock(roleOf.Address.Physical, AccessMode.Write);
						ComplexRemove(transaction, roleOf, ComplexAxis.Roles, current);
					}

					first = false;
				}

				if (type == ObjectType.Complex)
					ComplexCopy(transaction, current, ComplexAxis.Children | ComplexAxis.Roles, children);

				if (children.First.Value.Axis == ComplexAxis.Roles)
					if (!removed.ContainsKey(current))
					{
						transaction.Lock(parent.Address.Physical, AccessMode.Write);
						ComplexRemove(transaction, parent, ComplexAxis.Children, current);
					}

				Remove(transaction, current);
				removed.Add(current, true);

				children.RemoveFirst();
			}
		}

		public void SetParent(Transaction transaction, Binder binder, Binder newParent)
		{
			Binder oldParent;
			ObjectFlags flags;
			ObjectType type;
			Binder roleOf;

			if (binder == newParent)
				throw new NestingException();

			transaction.Lock(binder.Address.Physical, AccessMode.Write);
			GetData(transaction, binder, out oldParent, out flags, out type, out roleOf);

			transaction.Lock(oldParent.Address.Physical, AccessMode.Write);

			if (newParent == Binder.Empty)
			{
				transaction.Lock(Binder.Root.Address.Physical, AccessMode.Read);
				Binder nameBinder = ComplexFind(transaction, Binder.Root, ComplexAxis.Children, binder.NameID);

				if (nameBinder == Binder.Empty)
				{
					transaction.Lock(Binder.Root.Address.Physical, AccessMode.Write);
					nameBinder = ComplexFind(transaction, Binder.Root, ComplexAxis.Children, binder.NameID);

					if (nameBinder == Binder.Empty)
					{
						nameBinder = Create(transaction, Binder.Root, binder.NameID, ObjectFlags.None, ObjectType.Complex, null, PageCategory.Regular, true);
						ComplexAdd(transaction, Binder.Root, ComplexAxis.Children, nameBinder);
						console.WriteLine(LogLevel.Verbose, "RootAdd (nameID={0})", binder.NameID);
					}
				}
				else
					transaction.Lock(nameBinder.Address.Physical, AccessMode.Write);

				newParent = nameBinder;
				flags |= ObjectFlags.TopLevel;
			}
			else
			{
				Binder newParentParent;
				ObjectFlags newParentFlags;
				ObjectType newParentType;
				Binder newParentRoleOf;

				transaction.Lock(newParent.Address.Physical, AccessMode.Write);
				GetData(transaction, newParent, out newParentParent, out newParentFlags, out newParentType, out newParentRoleOf);

				if (newParentType != ObjectType.Complex)
					throw new InvalidOperationException();

				while (newParentParent != Binder.Root)
				{
					if (newParentParent == binder)
						throw new NestingException();

					if ((newParentFlags & ObjectFlags.TopLevel) == ObjectFlags.TopLevel)
						break;

					transaction.Lock(newParentParent.Address.Physical, AccessMode.Read);
					GetData(transaction, newParentParent, out newParentParent, out newParentFlags, out newParentType, out newParentRoleOf);
				}

				flags &= ~ObjectFlags.TopLevel;
			}

			SetData(transaction, binder, newParent, flags, roleOf);
			ComplexRemove(transaction, oldParent, ComplexAxis.Children, binder);
			ComplexAdd(transaction, newParent, ComplexAxis.Children, binder);
		}

		public void SetRoleOf(Transaction transaction, Binder binder, Binder newRoleOf)
		{
			Binder parent;
			ObjectFlags flags;
			ObjectType type;
			Binder oldRoleOf;

			if (binder == newRoleOf)
				throw new NestingException();

			transaction.Lock(binder.Address.Physical, AccessMode.Write);
			GetData(transaction, binder, out parent, out flags, out type, out oldRoleOf);

			if (oldRoleOf != Binder.Empty)
				transaction.Lock(oldRoleOf.Address.Physical, AccessMode.Write);

			if (newRoleOf != Binder.Empty)
			{
				Binder newRoleOfParent;
				ObjectFlags newRoleOfFlags;
				ObjectType newRoleOfType;
				Binder newRoleOfRoleOf;

				transaction.Lock(newRoleOf.Address.Physical, AccessMode.Write);
				GetData(transaction, newRoleOf, out newRoleOfParent, out newRoleOfFlags, out newRoleOfType, out newRoleOfRoleOf);

				if (newRoleOfType != ObjectType.Complex)
					throw new InvalidOperationException();

				while (newRoleOfRoleOf != Binder.Empty)
				{
					if (newRoleOfRoleOf == binder)
						throw new NestingException();

					transaction.Lock(newRoleOfRoleOf.Address.Physical, AccessMode.Read);
					GetData(transaction, newRoleOfRoleOf, out newRoleOfParent, out newRoleOfFlags, out newRoleOfType, out newRoleOfRoleOf);
				}
			}

			SetData(transaction, binder, parent, flags, newRoleOf);

			if (oldRoleOf != Binder.Empty)
				ComplexRemove(transaction, oldRoleOf, ComplexAxis.Roles, binder);

			if (newRoleOf != Binder.Empty)
				ComplexAdd(transaction, newRoleOf, ComplexAxis.Roles, binder);
		}

		///////////////////////////////////////////////////////////////////////
	}
}
