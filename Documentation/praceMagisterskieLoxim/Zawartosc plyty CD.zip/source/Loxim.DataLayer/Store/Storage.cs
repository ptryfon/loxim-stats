using System;
using System.Configuration;
using Loxim.Configuration;
using Loxim.Diagnostics;
using System.Text;

namespace Loxim.Store
{
	internal sealed partial class Storage
	{
		private static Storage current = null;

		public static Storage Current
		{
			get { return current; }
		}

		///////////////////////////////////////////////////////////////////////

		private readonly ErrorConsole console = new ErrorConsole("Storage");
		private readonly BufferManager buffer;
		private readonly BaseAllocator allocator;
		private readonly Encoding encoding;

		public Storage(BufferManager buffer)
		{
			lock (typeof(Storage))
			{
				if (current != null)
					throw new InvalidOperationException();

				current = this;
			}

			this.buffer = buffer;

			StoreStorageElement config = ((StoreSection) ConfigurationManager.GetSection("store")).Storage;
			StorageHandler handler = new StorageHandler(config.FileName, config.FileGrowth, config.PageSize);

			FileManager.Current.RegisterHandler(handler);

			switch (config.Allocation)
			{
				case AllocationType.Sequential:
					this.allocator = new SequentialAlocator(buffer, handler, config.FillFactor);
					break;
				default:
					throw new NotImplementedException();
			}

			encoding = Encoding.GetEncoding(config.Encoding);
		}

		~Storage()
		{
			lock (typeof(Storage))
			{
				if (current == this)
					current = null;
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
