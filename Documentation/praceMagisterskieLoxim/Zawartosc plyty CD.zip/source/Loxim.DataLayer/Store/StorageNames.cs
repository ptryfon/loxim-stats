using System;
using System.Collections.Generic;
using System.Threading;
using Loxim.Diagnostics;
using Loxim.Transactions;

namespace Loxim.Store
{
	public class MissingTranslationException : Exception
	{
	}

	internal sealed partial class Storage
	{
		private sealed class RecentTranslation
		{
			public readonly string Name;
			public readonly int NameID;
			public readonly long TransactionID;
			public readonly Binder Binder;

			public RecentTranslation(string name, int nameID, long transactionID, Binder binder)
			{
				this.Name = name;
				this.NameID = nameID;
				this.TransactionID = transactionID;
				this.Binder = binder;
			}
		}

		///////////////////////////////////////////////////////////////////////

		private bool namesLoaded = false;
		private object namesMutex = new object();
		private readonly Dictionary<string, int> forward = new Dictionary<string, int>();
		private readonly Dictionary<string, int> forwardCache = new Dictionary<string, int>();
		private readonly Dictionary<int, string> reverse = new Dictionary<int, string>();
		private readonly Dictionary<int, string> reverseCache = new Dictionary<int, string>();
		private readonly Dictionary<int, RecentTranslation> recent = new Dictionary<int, RecentTranslation>();

		///////////////////////////////////////////////////////////////////////

		private void LoadNames(Transaction transaction)
		{
			if (namesLoaded)
				return;

			LinkedList<Binder> names = new LinkedList<Binder>();
			ComplexFill(transaction, Binder.Names, ComplexAxis.Children, names);

			foreach (Binder binder in names)
			{
				string name = (string) VaryingGet(transaction, binder);

				forward.Add(name, binder.NameID);
				reverse.Add(binder.NameID, name);
			}

			console.WriteLine(LogLevel.Verbose, "NameLoad (count={0})", forward.Count);
			namesLoaded = true;
		}

		private int Assign()
		{
			for (int i = 1; i < int.MaxValue; i++)
			{
				if (reverse.ContainsKey(i))
					continue;

				if (reverseCache.ContainsKey(i))
					continue;

				return i;
			}

			throw new ApplicationException();
		}

		private bool PreserveTranslation(Transaction transaction, int nameID)
		{
			try
			{
				Monitor.Enter(namesMutex);

				if (!namesLoaded)
					LoadNames(transaction);

				if (reverse.ContainsKey(nameID))
					return true;

				if (!reverseCache.ContainsKey(nameID))
					throw new InvalidOperationException();

				try
				{
					Monitor.Exit(namesMutex);
					transaction.Lock(Binder.Names.Address.Physical, AccessMode.Write);
				}
				finally
				{
					Monitor.Enter(namesMutex);
				}

				if (reverse.ContainsKey(nameID))
					return true;

				RecentTranslation r;

				if (recent.TryGetValue(nameID, out r))
				{
					if (r.TransactionID == transaction.TransactionID)
						return false;

					if (recent.TryGetValue(nameID, out r))
					{
						if (Exists(transaction, r.Binder))
						{
							forward.Add(r.Name, r.NameID);
							forwardCache.Remove(r.Name);
							reverse.Add(r.NameID, r.Name);
							reverseCache.Remove(r.NameID);

							recent.Remove(r.NameID);
							console.WriteLine(LogLevel.Verbose, "NameConfirm (name={0}, nameID={1})", r.Name, r.NameID);
							return true;
						}
						else
						{
							recent.Remove(r.NameID);
							console.WriteLine(LogLevel.Verbose, "NameDiscard (name={0}, nameID={1})", r.Name, r.NameID);
						}
					}
				}

				string name = reverseCache[nameID];

				Binder binder = Create(transaction, Binder.Names, nameID, ObjectFlags.Meta, ObjectType.String, name, PageCategory.Names, false);
				ComplexAdd(transaction, Binder.Names, ComplexAxis.Children, binder);

				recent.Add(nameID, new RecentTranslation(name, nameID, transaction.TransactionID, binder));
				console.WriteLine(LogLevel.Verbose, "NameAdd (name={0}, nameID={1})", name, nameID);
				return false;
			}
			finally
			{
				Monitor.Exit(namesMutex);
			}
		}

		public int Translate(Transaction transaction, string name)
		{
			if (string.IsNullOrEmpty(name))
				throw new ArgumentException();

			lock (namesMutex)
			{
				if (!namesLoaded)
					LoadNames(transaction);

				int nameID;

				if (forward.TryGetValue(name, out nameID))
					return nameID;

				if (forwardCache.TryGetValue(name, out nameID))
					return nameID;

				nameID = Assign();
				forwardCache.Add(name, nameID);
				reverseCache.Add(nameID, name);
				return nameID;
			}
		}

		public string ReverseTranslate(Transaction transaction, int nameID)
		{
			lock (namesMutex)
			{
				if (!namesLoaded)
					LoadNames(transaction);

				string name;

				if (reverse.TryGetValue(nameID, out name))
					return name;

				if (reverseCache.TryGetValue(nameID, out name))
					return name;

				throw new MissingTranslationException();
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
