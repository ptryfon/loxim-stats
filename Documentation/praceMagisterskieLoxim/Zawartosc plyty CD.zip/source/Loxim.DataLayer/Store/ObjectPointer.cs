using System;
using Loxim.Transactions;

namespace Loxim.Store
{
	public sealed class ObjectPointer
	{
		private Transaction transaction;
		private Binder binder;
		private ObjectType type;

		private string name;
		private BinderCollection children;
		private BinderCollection roles;

		internal ObjectPointer(Transaction transaction, Binder binder, ObjectType type)
		{
			this.transaction = transaction;
			this.binder = binder;
			this.type = type;

			this.name = null;
			this.children = null;
			this.roles = null;
		}

		internal ObjectPointer(Transaction transaction, Binder binder)
			: this(transaction, binder, ObjectType.Unspecified)
		{
		}

		///////////////////////////////////////////////////////////////////////

		public Binder Binder
		{
			get
			{
				return binder;
			}
		}

		public string Name
		{
			get
			{
				if (name == null)
					name = Storage.Current.ReverseTranslate(transaction, binder.NameID);
				
				return name;
			}
		}

		public ObjectType Type
		{
			get
			{
				if (type == ObjectType.Unspecified)
				{
					Binder parent;
					ObjectFlags flags;
					Binder roleOf;

					transaction.Lock(binder.Address.Physical, AccessMode.Read);
					Storage.Current.GetData(transaction, binder, out parent, out flags, out type, out roleOf);
				}

				return type;
			}
		}

		public Binder Parent
		{
			get
			{
				Binder parent;
				ObjectFlags flags;
				Binder roleOf;

				transaction.Lock(binder.Address.Physical, AccessMode.Read);
				Storage.Current.GetData(transaction, binder, out parent, out flags, out type, out roleOf);

				if ((flags & ObjectFlags.TopLevel) == ObjectFlags.TopLevel)
					return Binder.Empty;

				return parent;
			}
			set
			{
				Storage.Current.SetParent(transaction, binder, value);
			}
		}

		public BinderCollection Children
		{
			get
			{
				if (type != ObjectType.Complex)
					throw new InvalidOperationException();

				if (children == null)
					children = new BinderCollection(transaction, binder, ComplexAxis.Children);

				return children;
			}
		}

		public Binder RoleOf
		{
			get
			{
				Binder parent;
				ObjectFlags flags;
				Binder roleOf;

				transaction.Lock(binder.Address.Physical, AccessMode.Read);
				Storage.Current.GetData(transaction, binder, out parent, out flags, out type, out roleOf);

				return roleOf;
			}
			set
			{
				Storage.Current.SetRoleOf(transaction, binder, value);
			}
		}

		public BinderCollection Roles
		{
			get
			{
				if (type != ObjectType.Complex)
					throw new InvalidOperationException();

				if (roles == null)
					roles = new BinderCollection(transaction, binder, ComplexAxis.Roles);

				return roles;
			}
		}

		///////////////////////////////////////////////////////////////////////

		public object Value
		{
			get
			{
				switch (Type)
				{
					case ObjectType.Boolean:
					case ObjectType.Long:
					case ObjectType.DateTime:
					case ObjectType.Decimal:
					case ObjectType.Double:
					case ObjectType.Pointer:
						transaction.Lock(binder.Address.Physical, AccessMode.Read);
						return Storage.Current.FixedGet(transaction, binder);
					case ObjectType.Binary:
					case ObjectType.String:
						transaction.Lock(binder.Address.Physical, AccessMode.Read);
						return Storage.Current.VaryingGet(transaction, binder);
					case ObjectType.Complex:
						return Children;
					default:
						throw new NotImplementedException();
				}
			}
			set
			{
				switch (Type)
				{
					case ObjectType.Boolean:
					case ObjectType.Long:
					case ObjectType.DateTime:
					case ObjectType.Decimal:
					case ObjectType.Double:
					case ObjectType.Pointer:
						transaction.Lock(binder.Address.Physical, AccessMode.Write);
						Storage.Current.FixedSet(transaction, binder, value);
						return;
					case ObjectType.Binary:
					case ObjectType.String:
						transaction.Lock(binder.Address.Physical, AccessMode.Write);
						Storage.Current.VaryingSet(transaction, binder, value);
						return;
					case ObjectType.Complex:
						throw new InvalidOperationException();
					default:
						throw new NotImplementedException();
				}
			}
		}

		public bool BooleanValue
		{
			get
			{
				if (Type != ObjectType.Boolean)
					throw new InvalidOperationException();

				return (bool) Value;
			}
			set
			{
				if (Type != ObjectType.Boolean)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public long LongValue
		{
			get
			{
				if (Type != ObjectType.Long)
					throw new InvalidOperationException();

				return (long) Value;
			}
			set
			{
				if (Type != ObjectType.Long)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public DateTime DateTimeValue
		{
			get
			{
				if (Type != ObjectType.DateTime)
					throw new InvalidOperationException();

				return (DateTime) Value;
			}
			set
			{
				if (Type != ObjectType.DateTime)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public decimal DecimalValue
		{
			get
			{
				if (Type != ObjectType.Decimal)
					throw new InvalidOperationException();

				return (decimal) Value;
			}
			set
			{
				if (Type != ObjectType.Decimal)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public double DoubleValue
		{
			get
			{
				if (Type != ObjectType.Double)
					throw new InvalidOperationException();

				return (double) Value;
			}
			set
			{
				if (Type != ObjectType.Double)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public Binder PointerValue
		{
			get
			{
				if (type != ObjectType.Pointer)
					throw new InvalidOperationException();

				return (Binder) Value;
			}
			set
			{
				if (type != ObjectType.Pointer)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public byte[] BinaryValue
		{
			get
			{
				if (Type != ObjectType.Binary)
					throw new InvalidOperationException();

				return (byte[]) Value;
			}
			set
			{
				if (Type != ObjectType.Binary)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		public string StringValue
		{
			get
			{
				if (Type != ObjectType.String)
					throw new InvalidOperationException();

				return (string) Value;
			}
			set
			{
				if (Type != ObjectType.String)
					throw new InvalidOperationException();

				Value = value;
			}
		}

		///////////////////////////////////////////////////////////////////////

		public ObjectPointer CreateObject(int nameID, bool value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Boolean, value);
		}

		public ObjectPointer CreateObject(int nameID, long value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Long, value);
		}

		public ObjectPointer CreateObject(int nameID, DateTime value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.DateTime, value);
		}

		public ObjectPointer CreateObject(int nameID, decimal value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Decimal, value);
		}

		public ObjectPointer CreateObject(int nameID, double value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Double, value);
		}

		public ObjectPointer CreateObject(int nameID, Binder value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Pointer, value);
		}

		public ObjectPointer CreateObject(int nameID, byte[] value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Binary, value);
		}

		public ObjectPointer CreateObject(int nameID, string value)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.String, value);
		}

		public ObjectPointer CreateObject(int nameID)
		{
			return Storage.Current.CreateObject(transaction, nameID, binder, ObjectType.Complex, null);
		}

		public void Remove()
		{
			Storage.Current.RemoveObject(transaction, binder);
		}

		///////////////////////////////////////////////////////////////////////
	}
}
