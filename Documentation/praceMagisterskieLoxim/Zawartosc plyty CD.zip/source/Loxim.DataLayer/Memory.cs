using System;

namespace Loxim
{
	internal static class Memory
	{
		///////////////////////////////////////////////////////////////////////

		#region public unsafe static bool Equals(byte[] first, int firstIndex, byte[] second, int secondIndex, int length)
		public unsafe static bool Equals(byte[] first, int firstIndex, byte[] second, int secondIndex, int length)
		{
			fixed (byte* pps = first, ppt = second)
			{
				byte* ps = pps + firstIndex;
				byte* pt = ppt + secondIndex;

				return Equals(ps, pt, length);
			}
		}

		public unsafe static bool Equals(byte* first, byte* second, int length)
		{
			for (int i = 0; i < length / sizeof(int); i++, first += sizeof(int), second += sizeof(int))
				if (*((int*) first) != *((int*) second))
					return false;

			for (int i = 0; i < length % sizeof(int); i++, first++, second++)
				if (*first != *second)
					return false;

			return true;
		}
		#endregion

		#region public unsafe static bool IsZero(byte[] buffer, int index, int length)
		public unsafe static bool IsZero(byte[] buffer, int index, int length)
		{
			fixed (byte* ppt = buffer)
			{
				byte* pt = ppt + index;

				return IsZero(pt, length);
			}
		}

		public unsafe static bool IsZero(byte* buffer, int length)
		{
			for (int i = 0; i < length / sizeof(int); i++, buffer += sizeof(int))
				if (*((int*) buffer) != 0)
					return false;

			for (int i = 0; i < length % sizeof(int); i++, buffer++)
				if (*buffer != 0)
					return false;

			return true;
		}
		#endregion

		#region public unsafe static void Copy(byte[] source, int sourceIndex, byte[] target, int targetIndex, int length)
		public unsafe static void Copy(byte[] source, int sourceIndex, byte[] target, int targetIndex, int length)
		{
			fixed (byte* pps = source, ppt = target)
			{
				byte* ps = pps + sourceIndex;
				byte* pt = ppt + targetIndex;

				Copy(ps, pt, length);
			}
		}

		public unsafe static void Copy(byte* source, byte* target, int length)
		{
			for (int i = 0; i < length / sizeof(int); i++, target += sizeof(int), source += sizeof(int))
				*((int*) target) = *((int*) source);

			for (int i = 0; i < length % sizeof(int); i++, target++, source++)
				*target = *source;
		}
		#endregion

		#region public unsafe static void Zero(byte[] buffer, int index, int length)
		public unsafe static void Zero(byte[] buffer, int index, int length)
		{
			fixed (byte* ppt = buffer)
			{
				byte* pt = ppt + index;

				Zero(pt, length);
			}
		}

		public unsafe static void Zero(byte* buffer, int length)
		{
			for (int i = 0; i < length / sizeof(int); i++, buffer += sizeof(int))
				*((int*) buffer) = 0;

			for (int i = 0; i < length % sizeof(int); i++, buffer++)
				*buffer = 0;
		}
		#endregion

		///////////////////////////////////////////////////////////////////////
	}
}
