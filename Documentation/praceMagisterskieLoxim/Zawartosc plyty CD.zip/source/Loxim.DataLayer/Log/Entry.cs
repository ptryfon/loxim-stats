using System;
using System.IO;
using Loxim.Store;

namespace Loxim.Log
{
	internal enum EntryType : byte
	{
		Header,
		Startup,
		Shutdown,
		TransactionBegin,
		TransactionEnd,
		PageDifference,
		Flush,
	}

	///////////////////////////////////////////////////////////////////////

	internal abstract class Entry
	{
		public abstract EntryType Type { get; }
		public abstract int Length { get; }

		public abstract void Write(BinaryWriter w);

		public static Entry Read(BinaryReader r)
		{
			EntryType type = (EntryType) r.ReadByte();

			switch (type)
			{
				case EntryType.Header:
					return new HeaderEntry(r);
				case EntryType.Startup:
					return new StartupEntry(r);
				case EntryType.Shutdown:
					return new ShutdownEntry(r);
				case EntryType.TransactionBegin:
					return new TransactionBeginEntry(r);
				case EntryType.TransactionEnd:
					return new TransactionEndEntry(r);
				case EntryType.PageDifference:
					return new PageDifferenceEntry(r);
				case EntryType.Flush:
					return new FlushEntry(r);
			}

			throw new InvalidDataException();
		}
	}

	///////////////////////////////////////////////////////////////////////

	#region internal sealed class HeaderEntry : Entry
	internal sealed class HeaderEntry : Entry
	{
		private long offset;

		public HeaderEntry(long offset)
		{
			this.offset = offset;
		}

		internal HeaderEntry(BinaryReader r)
		{
			this.offset = r.ReadInt64();
		}

		public long Offset
		{
			get { return offset; }
		}

		public override EntryType Type { get { return EntryType.Header; } }
		public override int Length { get { return sizeof(byte) + sizeof(long); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.Header);
			w.Write(offset);
		}
	}
	#endregion

	#region internal sealed class StartupEntry : Entry
	internal sealed class StartupEntry : Entry
	{
		public StartupEntry() { }
		internal StartupEntry(BinaryReader r) { }

		public override EntryType Type { get { return EntryType.Startup; } }
		public override int Length { get { return sizeof(byte); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.Startup);
		}
	}
	#endregion

	#region internal sealed class ShutdownEntry : Entry
	internal sealed class ShutdownEntry : Entry
	{
		public ShutdownEntry() { }
		internal ShutdownEntry(BinaryReader r) { }

		public override EntryType Type { get { return EntryType.Shutdown; } }
		public override int Length { get { return sizeof(byte); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.Shutdown);
		}
	}
	#endregion

	#region internal sealed class TransactionBeginEntry : Entry
	internal sealed class TransactionBeginEntry : Entry
	{
		private long transactionID;

		public TransactionBeginEntry(long transactionID)
		{
			this.transactionID = transactionID;
		}

		internal TransactionBeginEntry(BinaryReader r)
		{
			this.transactionID = r.ReadInt64();
		}

		public long TransactionID
		{
			get { return transactionID; }
		}

		public override EntryType Type { get { return EntryType.TransactionBegin; } }
		public override int Length { get { return sizeof(byte) + sizeof(long); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.TransactionBegin);
			w.Write((long) transactionID);
		}
	}
	#endregion

	#region internal sealed class TransactionEndEntry : Entry
	internal sealed class TransactionEndEntry : Entry
	{
		private long transactionID;

		public TransactionEndEntry(long transactionID)
		{
			this.transactionID = transactionID;
		}

		internal TransactionEndEntry(BinaryReader r)
		{
			this.transactionID = r.ReadInt64();
		}

		public long TransactionID
		{
			get { return transactionID; }
		}

		public override EntryType Type { get { return EntryType.TransactionEnd; } }
		public override int Length { get { return sizeof(byte) + sizeof(long); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.TransactionEnd);
			w.Write((long) transactionID);
		}
	}
	#endregion

	#region internal sealed class PageDifferenceEntry : Entry
	internal sealed class PageDifferenceEntry : Entry
	{
		private long transactionID;
		private Address address;
		private byte[] difference;

		public PageDifferenceEntry(long transactionID, Address address, byte[] difference)
		{
			this.transactionID = transactionID;
			this.address = address;
			this.difference = difference;
		}

		internal PageDifferenceEntry(BinaryReader r)
		{
			transactionID = r.ReadInt64();

			address = Address.FromBinary(r.ReadInt64());

			int length = r.ReadInt32();
			difference = new byte[length];
			r.Read(difference, 0, length);
		}

		public long TransactionID
		{
			get { return transactionID; }
		}

		public Address Address
		{
			get { return address; }
		}

		public byte[] Difference
		{
			get { return difference; }
		}

		public override EntryType Type { get { return EntryType.PageDifference; } }
		public override int Length { get { return sizeof(byte) + sizeof(long) + sizeof(long) + sizeof(int) + difference.Length; } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.PageDifference);
			w.Write((long) transactionID);
			w.Write((long) address.ToBinary());

			w.Write((int) difference.Length);
			w.Write(difference);
		}
	}
	#endregion

	#region internal sealed class FlushEntry : Entry
	internal sealed class FlushEntry : Entry
	{
		private long time;

		public FlushEntry(long time)
		{
			this.time = time;
		}

		internal FlushEntry(BinaryReader r)
		{
			this.time = r.ReadInt64();
		}

		public long Time
		{
			get { return time; }
		}

		public override EntryType Type { get { return EntryType.Flush; } }
		public override int Length { get { return sizeof(byte) + sizeof(long); } }

		public override void Write(BinaryWriter w)
		{
			w.Write((byte) EntryType.Flush);
			w.Write((long) time);
		}
	}
	#endregion

	///////////////////////////////////////////////////////////////////////
}
