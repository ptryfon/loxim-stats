using System;
using System.Collections.Generic;
using System.IO;

namespace Loxim.Log
{
	///////////////////////////////////////////////////////////////////////

	internal sealed class CompareDifferentiator : IDifferentiator
	{
		public IDifference Differentiate(byte[] original, byte[] modified)
		{
			return new CompareDifference(Crc32.Checksum(original), Crc32.Checksum(modified), Differentiate(original, modified, 10));
		}

		private LinkedList<Chunk> Differentiate(byte[] original, byte[] modified, int overhead)
		{
			LinkedList<Chunk> chunks = new LinkedList<Chunk>();

			bool diff = false;
			int offset = 0;
			int equality = 0;

			for (int i = 0; i < original.Length; i++)
			{
				if (original[i] != modified[i])
				{
					if (!diff)
					{
						offset = i;
						diff = true;
					}

					equality = 0;
				}
				else
				{
					if (diff)
					{
						equality++;

						if (equality > overhead)
						{
							int length = i - offset - equality + 1;
							Extract(original, modified, offset, length, chunks);
							diff = false;
						}
					}
				}
			}

			if (diff)
			{
				int length = original.Length - offset - equality;
				Extract(original, modified, offset, length, chunks);
				diff = false;
			}

			return chunks;
		}

		private void Extract(byte[] original, byte[] modified, int offset, int length, LinkedList<Chunk> chunks)
		{
			if (Memory.IsZero(original, offset, length))
			{
				byte[] m = new byte[length];
				Memory.Copy(modified, offset, m, 0, length);
				chunks.AddLast(new Chunk(ChunkType.Insertion, offset, length, null, m));
			}
			else if (Memory.IsZero(modified, offset, length))
			{
				byte[] o = new byte[length];
				Memory.Copy(original, offset, o, 0, length);
				chunks.AddLast(new Chunk(ChunkType.Deletion, offset, length, o, null));
			}
			else
			{
				byte[] o = new byte[length];
				byte[] m = new byte[length];
				Memory.Copy(original, offset, o, 0, length);
				Memory.Copy(modified, offset, m, 0, length);
				chunks.AddLast(new Chunk(ChunkType.Modification, offset, length, o, m));
			}
		}

		public IDifference FromArray(byte[] difference)
		{
			MemoryStream m = new MemoryStream(difference);
			BinaryReader r = new BinaryReader(m);

			int originalChecksum = r.ReadInt32();
			int modifiedChecksum = r.ReadInt32();
			int count = r.ReadInt32();

			LinkedList<Chunk> chunks = new LinkedList<Chunk>();

			for (int i = 0; i < count; i++)
			{
				ChunkType type = (ChunkType) r.ReadByte();
				int offset = r.ReadInt32();
				int length = r.ReadInt32();

				byte[] original = null;
				byte[] modified = null;

				if (type == ChunkType.Insertion)
				{
					modified = new byte[length];
					r.Read(modified, 0, length);
				}
				else if (type == ChunkType.Deletion)
				{
					original = new byte[length];
					r.Read(original, 0, length);
				}
				else
				{
					original = new byte[length];
					modified = new byte[length];
					r.Read(original, 0, length);
					r.Read(modified, 0, length);
				}

				chunks.AddLast(new Chunk(type, offset, length, original, modified)); 
			}

			return new CompareDifference(originalChecksum, modifiedChecksum, chunks);
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal sealed class CompareDifference : IDifference
	{
		private int originalChecksum;
		private int modifiedChecksum;
		private LinkedList<Chunk> chunks;

		internal CompareDifference(int originalChecksum, int modifiedChecksum, LinkedList<Chunk> chunks)
		{
			this.originalChecksum = originalChecksum;
			this.modifiedChecksum = modifiedChecksum;
			this.chunks = chunks;
		}

		public int Length
		{
			get
			{
				int length = sizeof(int) + sizeof(int) + sizeof(int);

				foreach (Chunk chunk in chunks)
				{
					length += sizeof(byte) + sizeof(int) + sizeof(int);

					if (chunk.Original != null)
						length += chunk.Length;
					if (chunk.Modified != null)
						length += chunk.Length;
				}

				return length;
			}
		}

		public byte[] ToArray()
		{
			MemoryStream m = new MemoryStream();
			BinaryWriter w = new BinaryWriter(m);

			w.Write((int) originalChecksum);
			w.Write((int) modifiedChecksum);
			w.Write((int) chunks.Count);

			foreach (Chunk chunk in chunks)
			{
				w.Write((byte) chunk.Type);
				w.Write((int) chunk.Offset);
				w.Write((int) chunk.Length);

				if (chunk.Original != null)
					w.Write(chunk.Original);
				if (chunk.Modified != null)
					w.Write(chunk.Modified);
			}

			return m.ToArray();
		}

		public void Apply(byte[] original)
		{
			foreach (Chunk chunk in chunks)
				chunk.Apply(original);
		}

		public void Revert(byte[] modified)
		{
			foreach (Chunk chunk in chunks)
				chunk.Revert(modified);
		}

		public VerificationResult Verify(byte[] buffer)
		{
			int checksum = Crc32.Checksum(buffer);
			VerificationResult result;

			if (checksum == originalChecksum)
				result = VerificationResult.Unapplied;
			else if (checksum == modifiedChecksum)
				result = VerificationResult.Applied;
			else
				return VerificationResult.Undetermined;

			foreach (Chunk chunk in chunks)
				if (chunk.Verify(buffer) != result)
					return VerificationResult.Undetermined;

			return result;
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal enum ChunkType : byte
	{
		Modification,
		Insertion,
		Deletion,
	}

	internal class Chunk
	{
		public readonly ChunkType Type;
		public readonly int Offset;
		public readonly int Length;
		public readonly byte[] Original;
		public readonly byte[] Modified;

		public Chunk(ChunkType type, int offset, int length, byte[] original, byte[] modified)
		{
			this.Type = type;
			this.Offset = offset;
			this.Length = length;
			this.Original = original;
			this.Modified = modified;
		}

		public void Apply(byte[] original)
		{
			if (Modified != null)
				Memory.Copy(Modified, 0, original, Offset, Length);
			else
				Memory.Zero(original, Offset, Length);
		}

		public void Revert(byte[] modified)
		{
			if (Original != null)
				Memory.Copy(Original, 0, modified, Offset, Length);
			else
				Memory.Zero(modified, Offset, Length);
		}

		public VerificationResult Verify(byte[] buffer)
		{
			if (Type == ChunkType.Insertion)
			{
				if (Memory.IsZero(buffer, Offset, Length))
					return VerificationResult.Unapplied;
				else if (Memory.Equals(buffer, Offset, Modified, 0, Length))
					return VerificationResult.Applied;

				return VerificationResult.Undetermined;
			}
			else if (Type == ChunkType.Deletion)
			{
				if (Memory.Equals(buffer, Offset, Original, 0, Length))
					return VerificationResult.Unapplied;
				else if (Memory.IsZero(buffer, Offset, Length))
					return VerificationResult.Applied;

				return VerificationResult.Undetermined;
			}
			else
			{
				if (Memory.Equals(buffer, Offset, Original, 0, Length))
					return VerificationResult.Unapplied;
				else if (Memory.Equals(buffer, Offset, Modified, 0, Length))
					return VerificationResult.Applied;

				return VerificationResult.Undetermined;
			}
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal static class Crc32
	{
		private static uint[] table;

		static Crc32()
		{
			table = new uint[256];

			for (int i = 0; i < 256; i++)
			{
				uint crc = (uint) i;

				for (int j = 8; j > 0; j--)
				{
					if ((crc & 1) != 0)
						crc = (crc >> 1) ^ 0xedb88320;
					else
						crc >>= 1;
				}

				table[i] = crc;
			}
		}

		public static int Checksum(byte[] buffer)
		{
			uint crc = 0xffffffff;

			for (int i = 0; i < buffer.Length; i++)
				crc = (crc >> 8) ^ table[(uint) buffer[i] ^ (crc & 0x000000ff)];

			return unchecked((int) (crc ^ 0xffffffff));
		}
	}

	///////////////////////////////////////////////////////////////////////
}
