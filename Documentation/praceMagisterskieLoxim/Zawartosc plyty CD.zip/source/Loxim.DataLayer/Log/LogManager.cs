using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading;
using Loxim.Configuration;
using Loxim.Diagnostics;
using Loxim.Store;

namespace Loxim.Log
{
	internal sealed class LogManager
	{
		private static LogManager current = null;

		public static LogManager Current
		{
			get { return current; }
		}

		///////////////////////////////////////////////////////////////////////

		private readonly ErrorConsole console;
		private readonly LogSection config;
		private readonly IDifferentiator differentiator;
		private readonly LinkedList<Entry> logBuffer;

		private FileStream dataStream;
		private BinaryReader dataReader;
		private BinaryWriter dataWriter;

		private long lastOffset;
		private long lastSize;

		///////////////////////////////////////////////////////////////////////

		public LogManager()
		{
			lock (typeof(LogManager))
			{
				if (current != null)
					throw new InvalidOperationException();

				current = this;
			}

			console = new ErrorConsole("LogManager");
			config = (LogSection) ConfigurationManager.GetSection("log");
			logBuffer = new LinkedList<Entry>();
			differentiator = (IDifferentiator) Activator.CreateInstance(Type.GetType(config.Differentiator));

			if (config.Compress)
				differentiator = new CompressDifferentiator(differentiator);
		}

		~LogManager()
		{
			lock (typeof(LogManager))
			{
				if (current == this)
					current = null;
			}
		}

		public void Start()
		{
			lock (this)
			{
				bool created = false;
				bool recoveryRequired = false;

				if (!File.Exists(config.FileName))
				{
					dataStream = new FileStream(config.FileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
					console.WriteLine(LogLevel.Warning, "Create (fileName={0})", config.FileName);

					created = true;
				}
				else
				{
					dataStream = new FileStream(config.FileName, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
					console.WriteLine(LogLevel.Information, "Open (fileName={0})", config.FileName);

					if (dataStream.Length == 0)
						created = true;
				}

				dataReader = new BinaryReader(dataStream);
				dataWriter = new BinaryWriter(dataStream);

				if (created)
				{
					HeaderEntry header = new HeaderEntry(100);

					Write(header);

					lastOffset = header.Offset;
					lastSize = header.Length + sizeof(int);
				}
				else
				{
					dataStream.Seek(0, SeekOrigin.Begin);
					HeaderEntry header = (HeaderEntry) Entry.Read(dataReader);

					lastOffset = header.Offset + dataStream.Length;

					foreach (Entry entry in GetEnumerator())
					{
						lastSize = entry.Length + sizeof(int);

						if (entry.Type != EntryType.Shutdown)
							recoveryRequired = true;

						break;
					}
				}

				if (recoveryRequired)
				{
					Recover();
					BufferManager.Current.Flush();
					WriteShutdown();
				}

				WriteStartup();
				Flush();
			}
		}

		public void Stop()
		{
			lock (this)
			{
				WriteShutdown();
				Flush();

				logBuffer.Clear();

				dataStream.Flush();
				dataStream = null;
			}
		}

		///////////////////////////////////////////////////////////////////////

		private void Recover()
		{
			long transactionID = 0;

			console.WriteLine(LogLevel.Warning, "RecoveryStart");

			foreach (Entry entry in GetEnumerator())
			{
				if (entry.Type == EntryType.TransactionEnd)
					transactionID = ((TransactionEndEntry) entry).TransactionID;
				else if (entry.Type == EntryType.PageDifference)
				{
					PageDifferenceEntry differenceEntry = (PageDifferenceEntry) entry;

					if (differenceEntry.TransactionID != transactionID)
						continue;

					IDifference difference = differentiator.FromArray(differenceEntry.Difference);
					PageBuffer page = null;

					try
					{
						page = BufferManager.Current.Acquire(differenceEntry.Address);
						VerificationResult result = difference.Verify(page.Original);

						if (result == VerificationResult.Undetermined)
							throw new ApplicationException();

						if (result == VerificationResult.Unapplied)
						{
							difference.Apply(page.Original);
							page.Dirty = true;
							console.WriteLine(LogLevel.Warning, "RecoveryPage (transactionID={0}, address={1})", transactionID, differenceEntry.Address);
						}
					}
					finally
					{
						if (page != null)
							page.Release();
					}
				}
				else if (entry.Type == EntryType.Flush || entry.Type == EntryType.Startup)
					break;
			}

			console.WriteLine(LogLevel.Warning, "RecoveryComplete");
		}

		///////////////////////////////////////////////////////////////////////

		private void Flush()
		{
			if (logBuffer.Count == 0)
				return;

			int count = logBuffer.Count;

			dataStream.Seek(0, SeekOrigin.End);

			while (logBuffer.Count > 0)
			{
				logBuffer.First.Value.Write(dataWriter);
				dataWriter.Write((int) logBuffer.First.Value.Length);

				logBuffer.RemoveFirst();
			}

			dataWriter.Flush();

			console.WriteLine(LogLevel.Verbose, "Flush (time={0}, count={1})", lastOffset, count);
		}

		private void Write(Entry entry)
		{
			lastOffset += lastSize;
			lastSize = entry.Length + sizeof(int);

			logBuffer.AddLast(entry);
		}

		public void Lock()
		{
			Monitor.Enter(this);
		}

		public void Unlock()
		{
			Monitor.Exit(this);
		}

		///////////////////////////////////////////////////////////////////////

		public void WriteStartup()
		{
			Write(new StartupEntry());
		}

		public void WriteShutdown()
		{
			Write(new ShutdownEntry());
		}

		///////////////////////////////////////////////////////////////////////

		public long CurrentOffset
		{
			get { return lastOffset + lastSize; }
		}

		public void WriteTransactionBegin(long transactionID)
		{
			Write(new TransactionBeginEntry(transactionID));
		}

		public void WriteTransactionEnd(long transactionID)
		{
			Write(new TransactionEndEntry(transactionID));
			Flush();
		}

		public void WritePageDifference(long transactionID, Address address, byte[] original, byte[] modified)
		{
			Write(new PageDifferenceEntry(transactionID, address, differentiator.Differentiate(original, modified).ToArray()));
		}

		///////////////////////////////////////////////////////////////////////

		public void WriteFlush(long time)
		{
			Write(new FlushEntry(time));
			Flush();
		}

		///////////////////////////////////////////////////////////////////////

		private LogEnumerator GetEnumerator()
		{
			return new LogEnumerator(dataReader);
		}

		private class LogEnumerator : IEnumerator<Entry>, IEnumerable<Entry>
		{
			private BinaryReader dataReader;

			private int length;
			private Entry current;

			public LogEnumerator(BinaryReader dataReader)
			{
				this.dataReader = dataReader;

				length = 0;
				current = null;

				Reset();
			}

			public Entry Current
			{
				get
				{
					if (current == null)
					{
						dataReader.BaseStream.Seek(-1 * length, SeekOrigin.Current);
						current = Entry.Read(dataReader);
						dataReader.BaseStream.Seek(-1 * length, SeekOrigin.Current);
					}

					return current;
				}
			}

			object System.Collections.IEnumerator.Current
			{
				get { return Current; }
			}

			public bool MoveNext()
			{
				try
				{
					dataReader.BaseStream.Seek(-1 * sizeof(int), SeekOrigin.Current);
					length = dataReader.ReadInt32();
					dataReader.BaseStream.Seek(-1 * sizeof(int), SeekOrigin.Current);

					current = null;

					return true;
				}
				catch
				{
					return false;
				}
			}

			public void Reset()
			{
				dataReader.BaseStream.Seek(0, SeekOrigin.End);
			}

			public void Dispose()
			{
			}

			public IEnumerator<Entry> GetEnumerator()
			{
				return this;
			}

			System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
			{
				return this;
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
