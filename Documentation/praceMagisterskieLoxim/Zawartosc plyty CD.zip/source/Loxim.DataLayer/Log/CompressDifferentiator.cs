using System;
using System.IO;
using System.IO.Compression;

namespace Loxim.Log
{
	///////////////////////////////////////////////////////////////////////

	internal sealed class CompressDifferentiator : IDifferentiator
	{
		private IDifferentiator differentiator;

		public CompressDifferentiator(IDifferentiator differentiator)
		{
			this.differentiator = differentiator;
		}

		public IDifference Differentiate(byte[] original, byte[] modified)
		{
			IDifference difference = differentiator.Differentiate(original, modified);

			return new CompressDifference(differentiator, difference);
		}

		public IDifference FromArray(byte[] compressed)
		{
			return new CompressDifference(differentiator, compressed);
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal sealed class CompressDifference : IDifference
	{
		private IDifferentiator differentiator;
		private byte[] compressed;
		private IDifference difference;

		internal CompressDifference(IDifferentiator differentiator, IDifference difference)
		{
			this.differentiator = differentiator;
			this.compressed = null;
			this.difference = difference;
		}

		internal CompressDifference(IDifferentiator differentiator, byte[] compressed)
		{
			this.differentiator = differentiator;
			this.compressed = compressed;
			this.difference = null;
		}

		public int Length
		{
			get
			{
				if (compressed == null)
					compressed = Compress(difference.ToArray());

				return compressed.Length;
			}
		}

		public byte[] ToArray()
		{
			if (compressed == null)
				compressed = Compress(difference.ToArray());

			return compressed;
		}

		public void Apply(byte[] original)
		{
			if (difference == null)
				difference = differentiator.FromArray(Decompress(compressed));

			difference.Apply(original);
		}

		public void Revert(byte[] modified)
		{
			if (difference == null)
				difference = differentiator.FromArray(Decompress(compressed));

			difference.Revert(modified);
		}

		public VerificationResult Verify(byte[] buffer)
		{
			if (difference == null)
				difference = differentiator.FromArray(Decompress(compressed));

			return difference.Verify(buffer);
		}

		private byte[] Compress(byte[] uncompressed)
		{
			MemoryStream ms = new MemoryStream();
			ms.Write(BitConverter.GetBytes((int) (uncompressed.Length)), 0, 4);

			DeflateStream cs = new DeflateStream(ms, CompressionMode.Compress);
			cs.Write(uncompressed, 0, uncompressed.Length);
			cs.Close();

			return ms.ToArray();
		}

		private byte[] Decompress(byte[] compressed)
		{
			int length = BitConverter.ToInt32(compressed, 0);
			MemoryStream ms = new MemoryStream(compressed, 4, compressed.Length - 4);

			DeflateStream ds = new DeflateStream(ms, CompressionMode.Decompress);
			byte[] buffer = new byte[length];
			ds.Read(buffer, 0, length);

			return buffer;
		}
	}

	///////////////////////////////////////////////////////////////////////
}
