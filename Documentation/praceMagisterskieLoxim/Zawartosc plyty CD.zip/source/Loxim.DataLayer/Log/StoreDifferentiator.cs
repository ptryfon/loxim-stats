using System;

namespace Loxim.Log
{
	///////////////////////////////////////////////////////////////////////

	internal sealed class StoreDifferentiator : IDifferentiator
	{
		public IDifference Differentiate(byte[] original, byte[] modified)
		{
			byte[] difference = new byte[original.Length + modified.Length];

			Memory.Copy(original, 0, difference, 0, original.Length);
			Memory.Copy(modified, 0, difference, original.Length, modified.Length);

			return new StoreDifference(difference);
		}

		public IDifference FromArray(byte[] difference)
		{
			return new StoreDifference(difference);
		}
	}

	///////////////////////////////////////////////////////////////////////

	internal sealed class StoreDifference : IDifference
	{
		private byte[] difference;

		internal StoreDifference(byte[] difference)
		{
			this.difference = difference;
		}

		public int Length
		{
			get { return difference.Length; }
		}

		public byte[] ToArray()
		{
			return difference;
		}

		public void Apply(byte[] original)
		{
			Memory.Copy(difference, original.Length, original, 0, original.Length);
		}

		public void Revert(byte[] modified)
		{
			Memory.Copy(difference, 0, modified, 0, modified.Length);
		}

		public VerificationResult Verify(byte[] buffer)
		{
			if (Memory.Equals(difference, 0, buffer, 0, buffer.Length))
				return VerificationResult.Unapplied;

			if (Memory.Equals(difference, buffer.Length, buffer, 0, buffer.Length))
				return VerificationResult.Applied;

			return VerificationResult.Undetermined;
		}
	}

	///////////////////////////////////////////////////////////////////////
}
