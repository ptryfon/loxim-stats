using System;
using System.IO;

namespace Loxim.Log
{
	public enum VerificationResult
	{
		Applied,
		Unapplied,
		Undetermined,
	}

	public interface IDifferentiator
	{
		IDifference Differentiate(byte[] original, byte[] modified);
		IDifference FromArray(byte[] difference);
	}

	public interface IDifference
	{
		int Length { get; }
		byte[] ToArray();
		void Apply(byte[] original);
		void Revert(byte[] modified);
		VerificationResult Verify(byte[] buffer);
	}
}
