using System;

namespace Loxim.Transactions
{
	public enum IsolationLevel
	{
		ReadCommited,
		Serializable,
	}
}
