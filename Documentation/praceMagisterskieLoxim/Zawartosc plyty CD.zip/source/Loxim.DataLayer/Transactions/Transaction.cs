using System;
using Loxim.Store;

namespace Loxim.Transactions
{
	public enum TransactionState
	{
		Active,
		Commited,
		Aborted,
		Deadlocked,
	}

	public sealed class Transaction
	{
		private readonly TransactionManager transactionManager;
		private long transactionID;
		private readonly long time;
		private readonly IsolationLevel isolationLevel;
		private TransactionState state;

		///////////////////////////////////////////////////////////////////////

		internal Transaction(TransactionManager transactionManager, long transactionID, IsolationLevel isolationLevel)
		{
			this.transactionManager = transactionManager;
			this.transactionID = transactionID;
			this.time = transactionID;
			this.isolationLevel = isolationLevel;
			this.state = TransactionState.Active;
		}

		///////////////////////////////////////////////////////////////////////

		public long TransactionID
		{
			get { return transactionID; }
			internal set { transactionID = value; }
		}

		internal long Time
		{
			get { return time; }
		}

		public IsolationLevel IsolationLevel
		{
			get { return isolationLevel; }
		}

		public TransactionState State
		{
			get { return state; }
			internal set { state = value; }
		}

		///////////////////////////////////////////////////////////////////////

		public void Commit()
		{
			transactionManager.Commit(this);
		}

		public void Abort()
		{
			transactionManager.Abort(this);
		}

		public void Restart()
		{
			transactionManager.Restart(this);
		}

		///////////////////////////////////////////////////////////////////////

		internal bool Lock(Address address, AccessMode mode)
		{
			return transactionManager.Lock(this, address.Physical, mode, isolationLevel);
		}

		internal bool TryLock(Address address, AccessMode mode)
		{
			return transactionManager.TryLock(this, address.Physical, mode, isolationLevel);
		}

		///////////////////////////////////////////////////////////////////////

		public ObjectPointer CreateObject(int nameID, bool value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Boolean, value);
		}

		public ObjectPointer CreateObject(int nameID, long value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Long, value);
		}

		public ObjectPointer CreateObject(int nameID, DateTime value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.DateTime, value);
		}

		public ObjectPointer CreateObject(int nameID, decimal value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Decimal, value);
		}

		public ObjectPointer CreateObject(int nameID, double value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Double, value);
		}

		public ObjectPointer CreateObject(int nameID, Binder value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Pointer, value);
		}

		public ObjectPointer CreateObject(int nameID, byte[] value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Binary, value);
		}

		public ObjectPointer CreateObject(int nameID, string value)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.String, value);
		}

		public ObjectPointer CreateObject(int nameID)
		{
			return Storage.Current.CreateObject(this, nameID, Binder.Empty, ObjectType.Complex, null);
		}

		///////////////////////////////////////////////////////////////////////

		public ObjectPointer GetObject(Binder binder)
		{
			return Storage.Current.GetObject(this, binder);
		}

		///////////////////////////////////////////////////////////////////////

		public BinderCollection GetRoots()
		{
			return Storage.Current.GetRoots(this);
		}

		public BinderCollection GetRoots(int nameID)
		{
			return Storage.Current.GetRoots(this, nameID);
		}

		///////////////////////////////////////////////////////////////////////

		public int Translate(string name)
		{
			return Storage.Current.Translate(this, name);
		}

		public int this[string name]
		{
			get { return Storage.Current.Translate(this, name); }
		}

		public string ReverseTranslate(int nameID)
		{
			return Storage.Current.ReverseTranslate(this, nameID);
		}

		public string this[int nameID]
		{
			get { return Storage.Current.ReverseTranslate(this, nameID); }
		}

		///////////////////////////////////////////////////////////////////////
	}
}
