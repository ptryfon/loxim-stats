using System;
using System.Threading;
using System.Collections.Generic;
using Loxim.Store;

namespace Loxim.Transactions
{
	internal sealed class LockElement
	{
		private LinkedList<Transaction> readers;
		private Transaction writer;
		private int waiting;

		public LockElement()
		{
			readers = new LinkedList<Transaction>();
			writer = null;
			waiting = 0;
		}

		public bool HasLocks
		{
			get
			{
				return readers.Count + waiting > 0 || writer != null;
			}
		}

		public bool Lock(Transaction transaction, AccessMode mode, bool noWait)
		{
			try
			{
				while (true)
				{
					if (mode == AccessMode.Read)
					{
						if (writer == null || writer == transaction)
						{
							if (!readers.Contains(transaction))
								readers.AddFirst(transaction);

							return true;
						}
						else if (writer.Time < transaction.Time)
						{
							if (noWait)
								return false;

							throw new DeadlockException();
						}
					}

					if (mode == AccessMode.Write)
					{
						if ((readers.Count == 0 || (readers.Count == 1 && readers.First.Value == transaction)) && (writer == null || writer == transaction))
						{
							writer = transaction;

							return true;
						}
						else
						{
							foreach (Transaction reader in readers)
								if (reader.Time < transaction.Time)
								{
									if (noWait)
										return false;

									throw new DeadlockException();
								}

							if (writer != null && writer.Time < transaction.Time)
							{
								if (noWait)
									return false;

								throw new DeadlockException();
							}
						}
					}

					if (noWait)
						return false;

					waiting++;
					Monitor.Exit(transaction);
					Monitor.Wait(this);
					Monitor.Enter(transaction);
					waiting--;

					if (transaction.State != TransactionState.Active)
						throw new TransactionInactiveException();
				}
			}
			finally
			{
				Monitor.Exit(this);
			}
		}

		public void Unlock(Transaction transaction)
		{
			lock (this)
			{
				int pulse = 0;

				if (readers.Remove(transaction) && writer == null)
					pulse = 1;

				if (writer == transaction)
				{
					writer = null;
					pulse = 2;
				}

				if (pulse == 2)
					Monitor.PulseAll(this);
				else if (pulse == 1)
					Monitor.Pulse(this);
			}
		}
	}

	internal sealed class LockTable
	{
		private Dictionary<AccessMode, Dictionary<long, LinkedList<Address>>> transactionLocks;
		private Dictionary<Address, LockElement> locks;

		///////////////////////////////////////////////////////////////////////

		public LockTable()
		{
			transactionLocks = new Dictionary<AccessMode, Dictionary<long, LinkedList<Address>>>();
			locks = new Dictionary<Address, LockElement>();

			transactionLocks[AccessMode.Read] = new Dictionary<long, LinkedList<Address>>();
			transactionLocks[AccessMode.Write] = new Dictionary<long, LinkedList<Address>>();
		}

		///////////////////////////////////////////////////////////////////////

		public LinkedList<Address> GetTransactionLocks(Transaction transaction, AccessMode mode)
		{
			lock (transactionLocks[mode])
			{
				LinkedList<Address> locks = null;

				transactionLocks[mode].TryGetValue(transaction.TransactionID, out locks);

				return locks;
			}
		}

		public void RemoveLocks(Transaction transaction)
		{
			lock (locks)
			{
				foreach (Dictionary<long, LinkedList<Address>> list in transactionLocks.Values)
					if (list.ContainsKey(transaction.TransactionID))
					{
						foreach (Address address in list[transaction.TransactionID])
						{
							LockElement _lock;

							if (!locks.TryGetValue(address, out _lock))
								continue;

							_lock.Unlock(transaction);

							lock (_lock)
							{
								if (!_lock.HasLocks)
									locks.Remove(address);
							}
						}

						list.Remove(transaction.TransactionID);
					}
			}
		}

		public bool TryLock(Transaction transaction, Address address, AccessMode mode)
		{
			return Lock(transaction, address, mode, true);
		}

		public bool Lock(Transaction transaction, Address address, AccessMode mode)
		{
			return Lock(transaction, address, mode, false);
		}

		private bool Lock(Transaction transaction, Address address, AccessMode mode, bool noWait)
		{
			LockElement _lock = null;

			lock (locks)
			{
				if (!locks.TryGetValue(address, out _lock))
				{
					_lock = new LockElement();
					locks[address] = _lock;
				}

				Monitor.Enter(_lock);
			}

			bool locked = _lock.Lock(transaction, mode, noWait);

			if (locked)
				lock (locks)
				{
					LinkedList<Address> list;

					if (!transactionLocks[mode].TryGetValue(transaction.TransactionID, out list))
					{
						list = new LinkedList<Address>();
						transactionLocks[mode][transaction.TransactionID] = list;
					}

					if (!list.Contains(address))
						list.AddFirst(address);
				}

			return locked;
		}

		///////////////////////////////////////////////////////////////////////
	}
}
