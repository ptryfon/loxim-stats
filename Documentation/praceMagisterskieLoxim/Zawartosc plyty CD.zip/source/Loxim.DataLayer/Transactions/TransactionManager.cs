using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading;
using Loxim.Configuration;
using Loxim.Log;
using Loxim.Store;
using Loxim.Diagnostics;

namespace Loxim.Transactions
{
	public class DeadlockException : Exception
	{
	}

	public class TransactionInactiveException : Exception
	{
	}

	internal sealed class TransactionManager
	{
		private static TransactionManager current = null;

		public static TransactionManager Current
		{
			get { return current; }
		}

		///////////////////////////////////////////////////////////////////////

		private readonly ErrorConsole console;
		private readonly TransactionSection config;
		private readonly LinkedList<Transaction> transactions;
		private readonly LockTable lockTable;
		private long lastTransactionID;

		public TransactionManager()
		{
			lock (typeof(TransactionManager))
			{
				if (current != null)
					throw new InvalidOperationException();

				current = this;
			}

			console = new ErrorConsole("TransactionManager");
			config = (TransactionSection) ConfigurationManager.GetSection("transaction");
			transactions = new LinkedList<Transaction>();
			lockTable = new LockTable();
			lastTransactionID = 0;
		}

		~TransactionManager()
		{
			lock (typeof(TransactionManager))
			{
				if (current == this)
					current = null;
			}
		}

		public void Start()
		{
		}

		public void Stop()
		{
			while (transactions.Count > 0)
			{
				try
				{
					Abort(transactions.First.Value);
				}
				catch
				{
				}
			}
		}

		///////////////////////////////////////////////////////////////////////

		public Transaction Begin()
		{
			return Begin(config.IsolationLevel);
		}

		public Transaction Begin(IsolationLevel isolationLevel)
		{
			long transactionID = Interlocked.Increment(ref lastTransactionID);

			Transaction transaction = new Transaction(this, transactionID, isolationLevel);

			lock (transactions)
			{
				console.WriteLine(LogLevel.Debug, "Begin (transactionID={0})", transaction.TransactionID);
				transactions.AddFirst(transaction);
			}

			return transaction;
		}

		public void Restart(Transaction transaction)
		{
			lock (transaction)
			{
				if (transaction.State != TransactionState.Deadlocked)
					throw new InvalidOperationException();

				long transactionID = Interlocked.Increment(ref lastTransactionID);

				transaction.TransactionID = transactionID;
				transaction.State = TransactionState.Active;

				console.WriteLine(LogLevel.Debug, "Restart (transactionID={0})", transaction.TransactionID);
			}
		}

		public void Commit(Transaction transaction)
		{
			lock (transaction)
			{
				if (transaction.State != TransactionState.Active)
					throw new TransactionInactiveException();

				console.WriteLine(LogLevel.Debug, "Commit (transactionID={0})", transaction.TransactionID);
				transaction.State = TransactionState.Commited;

				LinkedList<Address> locks = lockTable.GetTransactionLocks(transaction, AccessMode.Write);

				try
				{
					LogManager.Current.Lock();
					LogManager.Current.WriteTransactionBegin(transaction.TransactionID);

					if (locks != null)
					{
						foreach (Address address in locks)
						{
							PageBuffer page = null;

							try
							{
								page = BufferManager.Current.Acquire(address);

								if (page.IsChanged())
								{
									PageHeader.SetTime(page.Modified, LogManager.Current.CurrentOffset);
									LogManager.Current.WritePageDifference(transaction.TransactionID, address, page.Original, page.Modified);
								}
							}
							finally
							{
								if (page != null)
									page.Release();
							}
						}
					}

					LogManager.Current.WriteTransactionEnd(transaction.TransactionID);

					if (locks != null)
					{
						foreach (Address address in locks)
						{
							PageBuffer page = null;

							try
							{
								page = BufferManager.Current.Acquire(address);

								if (page.IsChanged())
									page.CommitChanges();
								else
									page.AbortChanges();
							}
							finally
							{
								if (page != null)
									page.Release();
							}
						}
					}
				}
				finally
				{
					LogManager.Current.Unlock();
				}

				lockTable.RemoveLocks(transaction);

				lock (transactions)
				{
					transactions.Remove(transaction);
				}
			}
		}

		public void Abort(Transaction transaction)
		{
			lock (transaction)
			{
				if (transaction.State != TransactionState.Active && transaction.State != TransactionState.Deadlocked)
					throw new TransactionInactiveException();

				PerformAbort(transaction, false);
			}
		}

		private void PerformAbort(Transaction transaction, bool deadlocked)
		{
			console.WriteLine(LogLevel.Debug, "Abort (transactionID={0})", transaction.TransactionID);

			if (deadlocked)
				transaction.State = TransactionState.Deadlocked;
			else
				transaction.State = TransactionState.Aborted;

			LinkedList<Address> locks = lockTable.GetTransactionLocks(transaction, AccessMode.Write);

			if (locks != null)
			{
				foreach (Address address in locks)
				{
					PageBuffer page = null;

					try
					{
						page = BufferManager.Current.Acquire(address);
						page.AbortChanges();
					}
					finally
					{
						if (page != null)
							page.Release();
					}
				}
			}

			lockTable.RemoveLocks(transaction);

			if (!deadlocked)
				lock (transactions)
				{
					transactions.Remove(transaction);
				}
		}

		///////////////////////////////////////////////////////////////////////

		public bool Lock(Transaction transaction, Address address, AccessMode mode, IsolationLevel isolationLevel)
		{
			lock (transaction)
			{
				if (transaction.State != TransactionState.Active)
					throw new TransactionInactiveException();

				if (mode == AccessMode.Read && isolationLevel <= IsolationLevel.ReadCommited)
					return true;

				try
				{
					return lockTable.Lock(transaction, address, mode);
				}
				catch (DeadlockException)
				{
					console.WriteLine(LogLevel.Debug, "Deadlock (transactionID={0})", transaction.TransactionID);
					PerformAbort(transaction, true);

					throw; // DeadlockException
				}
			}
		}

		public bool TryLock(Transaction transaction, Address address, AccessMode mode, IsolationLevel isolationLevel)
		{
			lock (transaction)
			{
				if (transaction.State != TransactionState.Active)
					throw new TransactionInactiveException();

				if (mode == AccessMode.Read && isolationLevel <= IsolationLevel.ReadCommited)
					return true;

				return lockTable.TryLock(transaction, address, mode);
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
