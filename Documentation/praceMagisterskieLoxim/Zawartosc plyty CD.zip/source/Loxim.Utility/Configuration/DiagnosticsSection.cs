using System;
using System.Configuration;
using Loxim.Diagnostics;

namespace Loxim.Configuration
{
	public class DiagnosticsSection : ConfigurationSection
	{
		public DiagnosticsSection()
		{
		}

		[ConfigurationProperty("fileName", IsRequired = false, DefaultValue = "Messages.txt")]
		public string FileName
		{
			get { return (string) base["fileName"]; }
			set { base["fileName"] = value; }
		}

		[ConfigurationProperty("bufferSize", IsRequired = false, DefaultValue = 8192)]
		public int BufferSize
		{
			get { return (int) base["bufferSize"]; }
			set { base["bufferSize"] = value; }
		}

		[ConfigurationProperty("level", IsRequired = false, DefaultValue = LogLevel.Warning)]
		public LogLevel Level
		{
			get { return (LogLevel) base["level"]; }
			set { base["level"] = value.ToString(); }
		}

		[ConfigurationProperty("consoleOutput", IsRequired = false, DefaultValue = false)]
		public bool ConsoleOutput
		{
			get { return (bool) base["consoleOutput"]; }
			set { base["consoleOutput"] = value; }
		}
	}
}
