using System;
using System.Collections.Generic;
using System.Text;

namespace Loxim.Diagnostics
{
	public enum LogLevel
	{
		Debug = 1,
		Verbose = 2,
		Information = 3,
		Warning = 4,
		Error = 5,
	}
}
