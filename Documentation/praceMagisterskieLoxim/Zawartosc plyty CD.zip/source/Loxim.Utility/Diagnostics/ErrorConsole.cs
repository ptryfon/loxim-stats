using System;
using System.Configuration;
using System.IO;
using System.Runtime.ConstrainedExecution;
using System.Threading;
using Loxim.Configuration;

namespace Loxim.Diagnostics
{
	public sealed class ErrorConsole : CriticalFinalizerObject
	{
		private static DiagnosticsSection config = null;

		private static object streamLock = new object();
		private static StreamWriter stream = null;
		private static int streamWriters = 0;

		///////////////////////////////////////////////////////////////////////

		private string module;

		public ErrorConsole(string module)
		{
			if (config == null)
				config = (DiagnosticsSection) ConfigurationManager.GetSection("diagnostics");

			if (string.IsNullOrEmpty(module))
				throw new ArgumentException();

			this.module = module;

			lock (streamLock)
			{
				if (stream == null && config.FileName != null)
				{
					FileStream fs = new FileStream(config.FileName, FileMode.Append, FileAccess.Write, FileShare.Read, config.BufferSize);
					StreamWriter sw = new StreamWriter(fs);

					GC.SuppressFinalize(fs);

					try
					{
						GC.SuppressFinalize(fs.SafeFileHandle);
					}
					catch
					{
					}

					stream = sw;
				}

				streamWriters++;
			}
		}

		~ErrorConsole()
		{
			lock (streamLock)
			{
				streamWriters--;

				if (stream != null && streamWriters == 0)
				{
					stream.Close();

					stream = null;
				}
			}
		}

		public static void ForceManualClose()
		{
			lock (streamLock)
			{
				streamWriters = 0;

				stream.Close();

				stream = null;
			}
		}

		///////////////////////////////////////////////////////////////////////

		public void WriteLine(LogLevel level, string format, params object[] args)
		{
			if (level >= config.Level)
			{
				string message = string.Format("{0} {1} {2} [{3}] {4}", DateTime.Now, Thread.CurrentThread.ManagedThreadId, level, module, string.Format(format, args));

				if (config.ConsoleOutput)
					Console.WriteLine(message);

				if (stream != null)
					lock (streamLock)
					{
						stream.WriteLine(message);
					}
			}
		}

		///////////////////////////////////////////////////////////////////////
	}
}
