using System;
using System.IO;
using System.Threading;
using System.Xml;
using Loxim.Diagnostics;
using Loxim.Transactions;
using Loxim.Store;

namespace Loxim
{
	public class Tests
	{
		private static Random random = new Random();

		#region public static void TransactionRun(Transaction transaction, TransactionFunction function, object state)
		public static void TransactionRun(Transaction transaction, TransactionFunction function, object state)
		{
			Thread thread = new Thread(new ParameterizedThreadStart(Tests.TransactionThread));
			thread.Name = string.Format("Transaction({0}, {1})", transaction.TransactionID, function.Method.Name);
			thread.IsBackground = true;
			thread.Start(new Tests.TransactionData(transaction, new Tests.TransactionFunction(function), state));
		}

		public delegate void TransactionFunction(Transaction transaction, object state);

		private class TransactionData
		{
			private Transaction transaction;
			private TransactionFunction function;
			private object state;

			public TransactionData(Transaction transaction, TransactionFunction function, object state)
			{
				this.transaction = transaction;
				this.function = function;
				this.state = state;
			}

			public Transaction Transaction { get { return transaction; } }
			public TransactionFunction Function { get { return function; } }
			public object State { get { return state; } }
		}

		private static void TransactionThread(object state)
		{
			TransactionData data = (TransactionData) state;
			int sleep = 100;

			Transaction transaction = data.Transaction;

			while (true)
			{
				try
				{
					data.Function(transaction, data.State);

					transaction.Commit();
					break;
				}
				catch (DeadlockException)
				{
					Thread.Sleep(sleep);
					sleep = (int) (sleep * (1 + random.NextDouble() / 2));
					transaction.Restart();
				}
				catch (TransactionInactiveException)
				{
					break;
				}
			}
		}
		#endregion

		///////////////////////////////////////////////////////////////////////

		public static void Basic(Transaction t, object state)
		{
			ObjectPointer a, b, c, d;

			int firstID = t["first"];
			int secondID = t["second"];

			for (int i = 0; i < 260; i++)
			{
				a = t.CreateObject(t["a"]);
				// Console.WriteLine(a.Binder);
				a.Remove();
			}

			try
			{
				a = t.CreateObject(t["a"]);
					b = a.CreateObject(t["b"]);
						c = b.CreateObject(t["c"]);
				d = t.CreateObject(t["d"], a.Binder);
				a.Parent = c.Binder; // Will throw nesting exception!
			}
			catch (NestingException)
			{
				// Console.WriteLine("*** Nesting detected! ***");
			}

			a = t.CreateObject(t["a"]);
				b = a.CreateObject(t["b"]);
					c = b.CreateObject(t["c"]);
			d = t.CreateObject(t["d"], a.Binder);
			b.Parent = Binder.Empty;
			c.Parent = a.Binder;

			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			sb.Append('.', 2500);
			t.CreateObject(t["dots"], sb.ToString());
		}

		///////////////////////////////////////////////////////////////////////

		public static void Other(Transaction t, object state)
		{
			ObjectPointer o;

			o = t.CreateObject(t["something"]);
				o.CreateObject(t["other"]);

			t.Abort();
		}

		///////////////////////////////////////////////////////////////////////

		public static void CreatePerson(Transaction t, object state)
		{
			for (int i = 0; i < (int) state; i++)
			{
				ObjectPointer o, a, r;

				o = t.CreateObject(t["person"]);
					o.CreateObject(t["fireName"], "Maksymilian");
					o.CreateObject(t["lastName"], "Ochudzki");
					o.CreateObject(t["birthDate"], DateTime.Parse("1977-03-21"));
					o.CreateObject(t["height"], 178);
					o.CreateObject(t["telephone"], "555-247-725");
					o.CreateObject(t["telephone"], "555-015-381");
					a = o.CreateObject(t["address"]);
						a.CreateObject(t["street"], "Bracka");
						a.CreateObject(t["number"], 7);
						a.CreateObject(t["postalCode"], "05-635");

				r = t.CreateObject(t["student"]);
					r.CreateObject(t["indexNumber"], 199287);

				r.RoleOf = o.Binder;

				if (i == 0)
					o.Remove();
				else if (i == 1)
					r.Remove();

				Thread.Sleep(10);
			}
		}

		///////////////////////////////////////////////////////////////////////

		public static void XmlDump(Transaction t, object state)
		{
			XmlWriterSettings s = new XmlWriterSettings();
			s.Indent = true;
			s.IndentChars = "\t";

			StreamWriter w = File.CreateText((string) state);
			XmlWriter x = XmlWriter.Create(w, s);

			try
			{
				x.WriteStartDocument();
				x.WriteStartElement("root");

				foreach (Binder b in t.GetRoots())
					XmlDumpRecursion(t, x, t.GetObject(b));

				x.WriteEndElement();
				x.WriteEndDocument();
			}
			finally
			{
				x.Close();
				w.Close();
			}
		}

		private static void XmlDumpRecursion(Transaction t, XmlWriter x, ObjectPointer o)
		{
			x.WriteStartElement(o.Name);
			x.WriteAttributeString("type", o.Type.ToString());
			// w.WriteAttributeString("binder", o.Binder.ToString());

			if (o.Type == ObjectType.Complex)
			{
				foreach (Binder b in o.Children)
					XmlDumpRecursion(t, x, t.GetObject(b));

				foreach (Binder b in o.Roles)
				{
					x.WriteStartElement("role");
					XmlDumpRecursion(t, x, t.GetObject(b));
					x.WriteEndElement();
				}
			}
			else if (o.Type == ObjectType.Pointer)
				XmlDumpRecursion(t, x, t.GetObject(o.PointerValue));
			else
				x.WriteValue(o.Value);

			x.WriteEndElement();
		}

		///////////////////////////////////////////////////////////////////////
	}
}
