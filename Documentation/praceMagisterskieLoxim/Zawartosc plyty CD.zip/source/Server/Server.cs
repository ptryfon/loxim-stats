using System;
using System.Threading;
using Loxim.Diagnostics;

namespace Loxim
{
	public class Server
	{
		static void Main(string[] args)
		{
			ErrorConsole console = new ErrorConsole("Server");
			console.WriteLine(LogLevel.Information, System.Reflection.Assembly.GetExecutingAssembly().FullName);

			DataLayer dataLayer = new DataLayer();
			dataLayer.Start();

			////////////////////////////////////////////////////////////////////////////

			Tests.TransactionRun(dataLayer.BeginTransaction(), new Tests.TransactionFunction(Tests.XmlDump), "DumpBegin.xml");
			Console.ReadLine();

			Tests.TransactionRun(dataLayer.BeginTransaction(), new Tests.TransactionFunction(Tests.Basic), null);
			Tests.TransactionRun(dataLayer.BeginTransaction(), new Tests.TransactionFunction(Tests.Other), null);
			Console.ReadLine();

			if (args.Length > 0 && args[1].ToLower() == "die")
				System.Diagnostics.Process.GetCurrentProcess().Kill();

			for (int i = 0; i < 3; i++)
				Tests.TransactionRun(dataLayer.BeginTransaction(), new Tests.TransactionFunction(Tests.CreatePerson), 3);
			Console.ReadLine();

			Tests.TransactionRun(dataLayer.BeginTransaction(), new Tests.TransactionFunction(Tests.XmlDump), "DumpEnd.xml");
			Console.ReadLine();

			////////////////////////////////////////////////////////////////////////////

			Console.WriteLine("Press ENTER to exit.");
			Console.ReadLine();

			dataLayer.Stop();
			dataLayer = null;

			// Mono fix
			if (Type.GetType("System.MonoType", false) != null)
				ErrorConsole.ForceManualClose();
 		}
	}
}
