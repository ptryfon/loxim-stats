package pl.edu.mimuw.loxim.jdbc;

final class DBTestInfo {
	public static final String DB_URL = "jdbc:loxim:students.mimuw.edu.pl/db";
	public static final String DB_URL_WITH_PORT = "jdbc:loxim:students.mimuw.edu.pl:1234/db";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD = "";
}
