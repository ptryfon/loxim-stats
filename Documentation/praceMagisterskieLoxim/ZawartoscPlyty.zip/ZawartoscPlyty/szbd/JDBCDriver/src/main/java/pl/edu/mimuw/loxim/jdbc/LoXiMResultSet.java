package pl.edu.mimuw.loxim.jdbc;

import java.sql.ResultSet;

public interface LoXiMResultSet extends ResultSet {

}
