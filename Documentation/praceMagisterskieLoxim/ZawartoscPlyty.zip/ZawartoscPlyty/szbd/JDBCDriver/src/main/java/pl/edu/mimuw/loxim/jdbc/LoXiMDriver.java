package pl.edu.mimuw.loxim.jdbc;
 
import java.sql.Driver;

public interface LoXiMDriver extends Driver {

}
