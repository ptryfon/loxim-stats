package pl.edu.mimuw.loxim.jdbc;

import java.sql.PreparedStatement;

public interface LoXiMPreparedStatement extends PreparedStatement {

}
