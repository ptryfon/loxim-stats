package pl.edu.mimuw.loxim.jdbc;

public class LoximException extends Exception {

	public LoximException() {
		// TODO Auto-generated constructor stub
	}

	public LoximException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LoximException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public LoximException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
