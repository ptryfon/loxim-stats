package pl.edu.mimuw.loxim.jdbc;

import javax.sql.DataSource;

public interface LoXiMDataSource extends DataSource {

}
