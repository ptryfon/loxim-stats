package pl.edu.mimuw.loxim.jdbc;

import java.sql.DatabaseMetaData;

public interface LoXiMDatabaseMetaData extends DatabaseMetaData {

}
