package pl.edu.mimuw.loxim.jdbc;

import java.sql.Connection;

public interface LoXiMConnection extends Connection {

}
