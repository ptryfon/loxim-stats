package pl.edu.mimuw.loxim.jdbc;

import java.sql.Statement;

public interface LoXiMStatement extends Statement {

}
