package pl.tzr.transparent.proxy.handler.registry;

public interface AccessorRegistryFactory {
	AccessorRegistry getHandlerRegistry();
}
