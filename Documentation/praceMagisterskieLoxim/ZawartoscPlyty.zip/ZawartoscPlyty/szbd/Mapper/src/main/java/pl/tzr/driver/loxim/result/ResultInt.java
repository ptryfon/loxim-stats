package pl.tzr.driver.loxim.result;


public class ResultInt extends ResultSimple {
	int val;
	public ResultInt(int _val) {
		val = _val;
	}
	
	public int getValue() {
		return val;
	}
	
	@Override
    public String toString() {
		return "" + val;
	}
	
	@Override
    public int getType() {
		return ResultType.RES_INT;
	}	
}
