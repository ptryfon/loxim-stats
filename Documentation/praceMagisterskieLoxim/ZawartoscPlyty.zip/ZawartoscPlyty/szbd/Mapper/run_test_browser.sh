java -cp mapper.jar:lib/bsh-2.0b4.jar:lib/commons-logging-1.1.jar:lib/commons-logging-adapters-1.1.jar:lib/commons-logging-api-1.1.jar  pl.tzr.test.BrowserTest
