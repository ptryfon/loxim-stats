ant -cp lib/junit-4.3.1.jar $1 $2 $3 $4
