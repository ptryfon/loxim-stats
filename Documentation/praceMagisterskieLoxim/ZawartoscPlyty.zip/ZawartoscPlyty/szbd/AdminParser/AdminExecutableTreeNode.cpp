#include "AdminExecutableTreeNode.h"

namespace AdminParser{
    bool AdminExecutableTreeNode::is_executable()
    {
	return true;
    }
}

