#include "AdminTreeNode.h"

namespace AdminParser{
    AdminTreeNode::~AdminTreeNode()
    {
    }
}

