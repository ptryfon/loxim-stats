#!/bin/bash
./LoximClient/Lsbql
