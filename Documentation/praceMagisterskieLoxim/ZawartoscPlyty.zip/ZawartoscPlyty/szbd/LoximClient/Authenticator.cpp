#include "Authenticator.h"

#include <iostream>

using namespace std;

namespace LoximClient{

        LoximClient::Authenticator::Authenticator()
	{
        }

	LoximClient::Authenticator::~Authenticator()
	{
	}
}
