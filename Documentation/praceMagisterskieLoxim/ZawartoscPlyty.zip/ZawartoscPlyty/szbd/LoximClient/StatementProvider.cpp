#include "StatementProvider.h"
#include <iostream>

using namespace std;

LoximClient::StatementProvider::StatementProvider()
{
}

LoximClient::StatementProvider::~StatementProvider()
{
}
