#ifndef _CONNECTION_H_
#define _CONNECTION_H_

#include "Result.h"
#include "Errors/Errors.h"
#include "../TCPProto/Package.h"

namespace Driver {

using namespace std;
using namespace Errors;
using namespace TCPProto;

	
class ConnectionException {
 protected:
	string msg;
 public: 
	ConnectionException() {}
	ConnectionException(string msg) : msg(msg) {}
	virtual void toStream(ostream& os) const { os << msg; }
	friend ostream& operator<<(ostream&, ConnectionException&);
	virtual ~ConnectionException() {}
};


class ConnectionErrnoException : public ConnectionException {
 protected:
	int error;
 public:
	ConnectionErrnoException(int err): ConnectionException(), error(err) 
	  { 
	    char cherr[256];
	    string *s;
	    s = SBQLstrerror(err);
	    snprintf(cherr, 255, "Error: %s", s->c_str());
	    msg = string(cherr);
	    delete s;
	  }
	virtual int getError() { return error; }
	virtual ~ConnectionErrnoException() {}
};

class ConnectionIOException : public ConnectionErrnoException {
 public:
	ConnectionIOException(int err): ConnectionErrnoException(err){}
};

class ConnectionMemoryException : public ConnectionErrnoException {
 public:
	ConnectionMemoryException(int err): ConnectionErrnoException(err){}

};

class ConnectionServerException : public ConnectionErrnoException {
 public:
	ConnectionServerException(int err): ConnectionErrnoException(err)
	  { 
	    char cherr[256];
	    string *s;
	    s = SBQLstrerror(err);
	    snprintf(cherr, 255, "Error: %s", s->c_str());
	    msg = string(cherr);
	  }
	
};


class ConnectionClosedException : public ConnectionException {
 public:
	virtual void toStream(ostream& os) const 
		{ os << "Closed connection Exception "; }
};


class ConnectionProtocolException : public ConnectionException {
 public:
	virtual void toStream(ostream& os) const 
		{ os << "Protocol Corrupt  Exception "; }
};


class ConnectionDriverException : public ConnectionException {
 public:
	ConnectionDriverException() {}
	ConnectionDriverException(string msg) : 
		ConnectionException(msg) {}
};



#if 0
class ConnectionException //Czarek
{
protected:
	string msg;
	int error;
public:
	ConnectionException(int err, string msg) : msg(msg), error(err) {};
	ConnectionException() : error(-1) { msg = " Undefined exception "; }
	ConnectionException(string msg) : msg(msg), error(-1) {}
	ConnectionException(int err) : msg(""), error(err) {}
	virtual void toStream(ostream& os) const { os << msg << " error code: " << error;  }
	friend ostream& operator<<(ostream&, ConnectionException&);
	virtual int getError() { return error; }
	virtual ~ConnectionException() {}
};

//TODO transmission i to co jest w drivermanager jako ConnectionIOException

class ClosedConnectionException : public ConnectionException
{
public:
	ClosedConnectionException() : ConnectionException("server was closed") {};
};

class ProtocolCorruptException : public ConnectionException
{
public:
	ProtocolCorruptException() : ConnectionException("protocol corrupt") {};
};

class TransmissionException : public ConnectionException
{
public:
	TransmissionException(int err) : ConnectionException(err, "transmission exception") {};
};

class ServerException : public ConnectionException
{
public:
	ServerException(int err) : ConnectionException(err, "server error") {};
};

class MemoryException : public ConnectionException
{
public:
	MemoryException(int err) : ConnectionException(err, "memory exception") {};
};


#endif

class Statement {
public:
	Statement(unsigned long stmtNr) : stmtNr(stmtNr) { }
	void addParam(string name, Result* result)
		{ params[name] = result; }
	~Statement() { }
private:
	unsigned long               stmtNr;
	map<string, Result*> params; 
	friend class Connection;
};

class Connection
{
public:
	Connection(int socket);
	int disconnect();
	virtual ~Connection();
	Result* execute(const char* query)         throw (ConnectionException);
	Result* newExecute(const char* query)      throw (ConnectionException);
	Result* execute(Statement* stmt)           throw (ConnectionException);
	Statement* parse(const char* query)        throw (ConnectionException);
	
	/* whether to print message to cerr */
	void set_print_err(bool _print_err);
private:
	int sock;
	char* bufferBegin;
	char* bufferEnd;
	
	bool print_err;
	
	unsigned long getULong(unsigned long &val);
	int stringCopy(char* &newBuffer);
	Result* grabElements(ResultCollection* col);
	Result* deserialize();
	
	Result* oldExecute(const char* query) throw (ConnectionException);
	Result* oldReceive() throw (ConnectionException);
};

class BufferHandler
{
	public:
		char* buf;
		BufferHandler(char* buffer): buf(buffer) {};
		~BufferHandler() {free (buf);};
};

} // namespace

#endif //_CONNECTION_H_
