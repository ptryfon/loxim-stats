#Skrypcik pomocniczy - zamienie wszyskie ma�e litery pojawiaj�ce si� na stdin na wielkie. 

#!/bin/bash

tr abcdefghijklmnoprstuwvxyzq ABCDEFGHIJKLMNOPRSTUWVXYZQ
