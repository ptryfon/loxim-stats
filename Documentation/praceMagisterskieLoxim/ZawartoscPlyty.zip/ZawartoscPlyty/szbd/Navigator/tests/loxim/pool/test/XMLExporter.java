package loxim.pool.test;


public class XMLExporter {
	public void export() {
	}
}
