package loxim.pool;

public class LoximQuery {
	private String value;
	
	public LoximQuery(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
}
