package objectBrowser.editors;

import org.eclipse.core.runtime.IPath;
import org.eclipse.ui.IEditorLauncher;

public class QueryEditorLauncher implements IEditorLauncher {

	public void open(IPath file) {
		// TODO Auto-generated method stub

	}

}
