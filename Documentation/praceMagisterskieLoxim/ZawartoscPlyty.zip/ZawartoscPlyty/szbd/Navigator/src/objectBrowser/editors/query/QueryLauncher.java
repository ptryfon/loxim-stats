package objectBrowser.editors.query;

import org.eclipse.core.runtime.IPath;
import org.eclipse.ui.IEditorLauncher;

public class QueryLauncher implements IEditorLauncher {

	public void open(IPath file) {
		// TODO Auto-generated method stub

	}

}
