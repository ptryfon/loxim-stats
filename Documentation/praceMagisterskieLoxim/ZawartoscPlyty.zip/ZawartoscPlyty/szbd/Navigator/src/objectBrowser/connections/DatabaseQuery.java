package objectBrowser.connections;

public class DatabaseQuery {
	public String query;
	
}
