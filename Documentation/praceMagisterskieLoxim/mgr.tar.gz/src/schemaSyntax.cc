/*
the module contains some (simple) functions related to the schema AST.
*/

#include "include/schemaSyntax.h"
#include "include/err.h"
#include <string>
#include <iostream>
#include <sstream>
#include <typeinfo>

using namespace std;

Type::Type() {}
Type::Type(typeNo id) {
	this->id = id;
}

string* Type::typeName() { 
    switch (id) {
	case T_INT: 	return new string("int"); break;
	case T_DOUBLE:	return new string("double"); break;
	case T_STRING:	return new string("string"); break;
	case T_BOOL:	return new string("bool"); break;
	case T_LINK:	return new string("linkto " + className); break;
	default: return new string ("PANIC - UNKNOWN TYPE"); break;
    }
}
    
Type::operator string() {
    ostringstream o;
    o << *(typeName());
    return o.str();
}

FieldDesc::operator string() {
    ostringstream o;
    o << "{ name = " << name << ",\ttype = " << (string)type;
    o << ",\tmultiple = " << multiple << " } "; 
    return o.str();
}

RoleDesc::operator string() {
    ostringstream o;
    o << "ROLE { className = " << className << ",\tmultiple = " << multiple << " }";
    return o.str();
}

DbClass::operator string() {
    ostringstream o;
    o << "{\n  class = " << name << " [clsId = " << id << "]" << endl;
    if (rolePlayed==NULL) { o << "  no roles played" << endl; }
    	else { o << "  rolePlayed = " << (string)(*rolePlayed) << endl; 
	}

    o << "  rolesOwned = " << endl;
    for (rolesMap::iterator rolesIt = rolesOwned.begin(); rolesIt != rolesOwned.end(); rolesIt++) {
	// o << "  " << (*rolesIt).first << " : ";
	o << "    " << (string)*((*rolesIt).second) << endl;
    }
    // used to iterate the Map (sorts alphabetically)
	// now iterate by Vec -- showing the physical data order!
    o << "  FIELDS = " << endl;
    for (FieldsVec::iterator fieldsIt = fieldsVec.begin();fieldsIt != fieldsVec.end(); fieldsIt++) {
	// o << "  " << (*fieldsIt).first << " : ";
	o << "    " << (string)(*(*fieldsIt)) << endl;
    } 

    o << "}" << endl; 
    return o.str();
}

Database::operator string() {
    ostringstream o;
    o << "DATABASE = " << dbName << endl;
    o << "CLASSES = " << endl;
    for (classesMap::iterator classesMapIt = allClasses.begin(); classesMapIt != allClasses.end(); classesMapIt++) {
	// o << (*classesMapIt).first << " : ";
	DbClass* c = (*classesMapIt).second;
	if (c==NULL) panic ("Null class in map?!");
	o << (string)*((*classesMapIt).second) << endl;
    } 
    
/*    o << "ROOTCLASSES = " << endl;
    for (classesMap::iterator rootClassesMapIt = rootClasses.begin(); rootClassesMapIt != rootClasses.end(); rootClassesMapIt++) {
        o << (*rootClassesMapIt).first << " : ";
        o << (string)*((*rootClassesMapIt).second) << endl;
    }  */
    return o.str();
}

ostream& operator<<(ostream& s,Database& d) {
            return s << (string)d;
}

Database::~Database() {
    // dynamic objects: classes. deleting: all classes.
    for (classesMap::iterator classesMapIt = allClasses.begin(); classesMapIt != allClasses.end(); classesMapIt++) {
	delete (*classesMapIt).second;
    }

}

DbClass::~DbClass() {
    /* dynamic objects: 
       	- rolePlayed, 
	- map: rolesOwned, 
	- map: fields [delete at once] */

    for (fieldsMap::iterator fieldsIt = fields.begin();fieldsIt != fields.end(); fieldsIt++) {
        delete (*fieldsIt).second;
    }
    for (rolesMap::iterator rolesIt = rolesOwned.begin(); rolesIt != rolesOwned.end(); rolesIt++) {
        delete (*rolesIt).second;
    }
    delete rolePlayed;


}

/*
Type - only static vars
FieldDesc - only static vars
*/


/*  The function performs one-time after-parse jobs.
	It involves:
		[1]. simple semantic analysis: (correct field names (tables exist))
		[2]. fixes to AST 
			- 2.1. populate rolesOwned
			- 2.2. generate other needed data structs
*/
int Database::schemaParserProstProc() {
  int currentId = 1;
  Database* db = this;	// ugly and caused by copy&paste, but should work ;)
  for (classesMap::iterator classesMapIt = db->allClasses.begin(); classesMapIt != db->allClasses.end(); classesMapIt++) {
	DbClass* c = (*classesMapIt).second;
	myassert (c, "null class acquired from dictionary");
	// 2.2.
		c->id = currentId;
		db->clsIdMap[currentId++]=c;
	/* [2.1]
	if this class plays a role, copy this role info to the "master" class
	c->rolePlayed->className = superclass name; c->name = this class name
	*/
	if (c->rolePlayed!=NULL) {
	    RoleDesc* rd = new RoleDesc();
	    rd->className = c->name;
	    rd->multiple = c->rolePlayed->multiple;
	    myassert ((db->allClasses[c->rolePlayed->className])!=NULL, "nonexistant class in rolePlayed.className");
	    (db->allClasses[c->rolePlayed->className])->rolesOwned[c->name]=rd;
	}

	/* [1]  */
	for (fieldsMap::iterator fieldsIt = c->fields.begin();fieldsIt != c->fields.end(); fieldsIt++) {
	    // now check if types LinkTo are OK 
	    FieldDesc* f = (*fieldsIt).second;
	    myassert (f!=NULL, "null field acquired from dictionary");
	    if (f->type.id == T_LINK) {
			if ((db->allClasses[f->type.className])==NULL) {
		    	cout << "Class " << c->name << ": field " << f->name << " links to nonexistent class " << f->type.className << endl;
		    	return 0; // watch out, it's not a shell, this means failure
			}
	    }
	    
	} // fields iterator
  } // class iterator
  return 1; // OK
}
