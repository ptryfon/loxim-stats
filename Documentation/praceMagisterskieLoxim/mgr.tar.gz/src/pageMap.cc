/*
this module provides the paging manager ("block manager").
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "include/schemaSyntax.h"
#include "include/err.h"
#include "include/pageMap.h"
#include <string>
using namespace std;

/* version 1 assumptions: 
   1. all our ops are written to disk immediately. NOTE: we don't use fsync().
   every operation done on the page should mark it dirty ... algorithms...
   version 1: dirty bit not needed at all
   -> the page cache is useful for reads only

   pages are independent -- no mandatory pointers to pages in pages
   2. no memory locks at all
   3. new objects will be added:
   	- to last page
	- if no space on last page -> reuse a page from freeList
		- if no pages on freeList  -> make a new page
	--> last 2 steps: masked by newPage()
*/

/* store information from Pager to FirstPage on disk */
void Pager::syncFirstPage() {
    myassert (lseek(fd, 0, SEEK_SET) != -1, "lseek to 0 failed");
    FirstPage fp;
    memset ((void*)&fp, 0, sizeof(FirstPage));
    fp.firstFree = firstFree;
    fp.nFree = nFree;
    mywrite (fd, (void*)&fp, PAGE_SIZE, this->fileName, 0);
}

/* when called, if memory cache >= MAX_PAGES, then free some memory
   version1: free all caches
*/
void Pager::swapd() {
	if (nPage >= MAX_PAGES) {
		debug2 ("SWAPD: flush cache of class: ", this->fileName);
		for (PageMap::iterator pgMapIt = pageMap.begin(); pgMapIt != pageMap.end(); pgMapIt++) {
			MemPage* p = (*pgMapIt).second;
			myassert (p, "null page acquired from dictionary");
			delete p;
		}
		pageMap.clear();
		nPage = 0;		
	}	
}

/* returns a new, EMPTY DATA memory page and a corresponding disk block;  
   	- if new: pgno <- dbSize; insert into pagTable; nPage++; sync;
	- if recovered freePage: nothing
	- MEMORY IS INITIALIZED TO: (normal page, 0 cells).
	- CALLER FILLS ALL OTHER DATA.
 */
MemPage* Pager::newPage() { 
    if (nFree>0) {
	MemPage* page = getPage(firstFree);
	// update freeList
	debug2 ("reusing free page: ", page->pgno);
	int nextFree = *((int*)(page->data + 2)); // first 2B = pageType // CHECK
	firstFree = nextFree;
	nFree--;
	// future optimization: take freePage from end of list and dont sync?
	syncFirstPage();
    PageHdr* pageHdr = (PageHdr*) page->data;
	pageHdr->pageType = PG_NORMAL;
	pageHdr->nCells = 0;	
	return page;
	// the page has pgno and Pager SET already(this was done during first mmap)
    }
    // freelist was empty -- create a new page; it is also mmap'ed.
	swapd();
    MemPage* page = new MemPage();
    memset ((void*)page->data, 0, PAGE_SIZE);	
    page->pPager = this;
    page->pgno = dbSize++;
    // page->nRef = page->dirty = 0;
    nPage++;
    pageMap[page->pgno] = page;
    PageHdr* pageHdr = (PageHdr*) page->data;
    pageHdr->pageType = PG_NORMAL;
	pageHdr->nCells = 0;

    writePage(page->pgno);
    return page;
}

/* gets a disk block N [from the page table or disk]; err->returns NULL */
MemPage* Pager::getPage(u32 pgno) {
    myassert (pgno>0, "invalid page number (remember: 0 is reserved)");
	myassert (pgno < dbSize, 
		"too big page number " << pgno << " requested; dbSize only = " << dbSize);
    if (MemPage* page = pageMap[pgno]) { 
	return page; 
    } else {	
		swapd();
		// alloc a page by hand... read the page from disk...
		page = new MemPage();
		page->pPager = this;
		page->pgno = pgno;
		pageMap[page->pgno] = page;
		nPage++;
		myassert (lseek(fd, (pgno)*(off_t)PAGE_SIZE, SEEK_SET) != -1, "lseek failed");
		myread (fd, page->data, PAGE_SIZE, this->fileName, pgno);
		return page;
    }
}

void Pager::stats() {
    cout << "Pager for " << fileName << endl;
    cout << "dbSize = " << dbSize << " (blocks)" << endl;
    cout << "nPage = " << nPage << " (frames in memory)" << endl;
    cout << "pageMap struct size = " << pageMap.size() << endl;
    cout << "nFree = " << nFree << " (free blocks)" << endl;
    cout << "firstFree = " << firstFree << endl << endl;

}

/* writes changes on the memPage to disk */
void Pager::writePage(u32 pgno) { 
    myassert (lseek(fd, (pgno)*(off_t)PAGE_SIZE, SEEK_SET) != -1, "lseek failed");
    MemPage *page = pageMap[pgno];
    myassert (page, "attempt to sync a page not in memory");
    mywrite (fd, (void*)page->data, PAGE_SIZE, this->fileName, pgno);
}

/* calculate no of free bytes on the page 
   NOTE: this is the free space BEFORE VACUUM, not fragmented, 
   single free fragment after the header.
   -- and yes, for this function cells marked dead are NOT free space.
*/
u16 MemPage::countFreeSpace() {
	PageHdr* h = (PageHdr*) this->data;
	if (h->nCells) {
		debug2("freeSpace: current nCells = ", h->nCells);
		u16 lastCellOff = cellOff(h, (h->nCells-1));
		debug2("freeSpace: lastCellOff = ", lastCellOff);
		return lastCellOff - (PG_HDR_SIZE + 4*h->nCells);
	} else {
		return PG_DATA_SIZE;
	}
}
