#ifndef _IPARSER_H_
#define _IPARSER_H_

#include "include/schemaSyntax.h"

using namespace std;

#define SLEN	30						// fixed strings len if in setof(string)

// gets an INSERT STRING, returns: record size and its data
// arguments: insert-query, db, className, pp_ret (filled by the function)
int insertParse (string, Database*, string, void**);

// eats whitespace from string start
void eatSpace(string*);

#endif
