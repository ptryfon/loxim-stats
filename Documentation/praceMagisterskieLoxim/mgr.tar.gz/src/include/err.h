#ifndef _ERR_H_
#define _ERR_H_
                  
#include <iostream>
#include <string>

using namespace std;

// notice: this can be used also like this:
// debug (x << "hello world" << y);
#ifdef DEBUG
#define debug(x) \
  cout << x << endl; cout.flush();
#else
#define debug(x)
#endif

// so debug2 below is only for convenience.
#ifdef DEBUG
#define debug2(x,y) \
  cout << x << y << endl; cout.flush();
#else
#define debug2(x,y)
#endif

#define panic(s) \
  { cout << "[FATAL ERROR]: " << s << endl; exit (1); }

// redefinition of assert() from glibc, this is hand-written, simple 
// and does exactly what you'd expect
#define myassert(expr, msg) \
  { if (!(expr)) panic (msg); }

// version with 2 arguments (again, only for convenience)
#define myassert2(expr, msg1, msg2) \
  { if (!(expr)) { cout << "[FATAL ERROR]: " << msg1 << " " << msg2 << endl; \
		   exit (1); } }

// version using perror()
#define myassert2p(expr, msg1, msg2) \
  { if (!(expr)) { cout << "[FATAL ERROR]: " << msg1 << endl; \
		   perror (msg2); \
		   exit (1); } }

#endif
