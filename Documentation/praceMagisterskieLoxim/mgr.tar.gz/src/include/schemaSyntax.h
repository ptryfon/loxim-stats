/*
 * Database schema classes
 */
#ifndef _SCHEMASYNTAX_H_
#define _SCHEMASYNTAX_H_
                                                                                
#include <iostream>
#include <string>
#include <map>
#include <vector>
#include "include/pageMap.h"

using namespace std;

/* Simple hierarchy of types; 
	T_SET -- symbol for "{" token in parse-inserts 
	T_NOTHING -- placeholder for special-meaning zero (=ANY TYPE).
*/

enum typeNo { T_NOTHING, T_INT, T_DOUBLE, T_STRING, T_BOOL, T_LINK, T_SET_BEGIN, T_SET_END };

class Type { 
    public: 
	Type();
	Type(typeNo);
	typeNo id;
	// useful only if type is a T_LINK to sth
	string className;
	string* typeName();
	operator string(); 
};

/* We have cross-reference */
class DbClass;

/* Roles are essence of this model */
class RoleDesc {
    public:
	string className;
	// DbClass* roleClass; 	// by�: string className
	bool multiple;
	operator string();
};

/* Type defined for conveniece */
typedef map<string,RoleDesc*,less<string> > rolesMap;

/* describes a class attribute */
class FieldDesc {
    public:
	string name;
	Type type;
	bool multiple;
	operator string();
};

/* Another type defined for conveniece */
typedef map<string,FieldDesc*,less<string> > fieldsMap;
typedef vector<FieldDesc*> FieldsVec;

/* And finally DbClass */
class DbClass {
    public:
	~DbClass();
	string name;
	int id;					// 2B classID used on disk and in maps
	RoleDesc* rolePlayed; 	// superrole
	rolesMap rolesOwned; 	// subroles
	fieldsMap fields;		// optimized for speed using fields[fieldName]
	FieldsVec fieldsVec;	// order of fields is held here, needed for storage.
	operator string();
};

/* And yet another type defined only for conveniece */
typedef map<string,DbClass*,less<string> > classesMap;

/* dictionary (clsId->class struct); objects have 2B-classType field = clsId) */
typedef map<int,DbClass*> ClsIdMap;

/* Database as a container of all classes */
class Database {
    public:
	~Database();
	string dbName;
	classesMap allClasses;
	classesMap rootClasses;
	ClsIdMap clsIdMap;
	// container of all Pagers (page cache controllers)
	PagersMap pagers;		
	operator string();
    friend ostream& operator<<(ostream&,Database&);
	// simple semantic analysis after schema parsing
	int schemaParserProstProc(); 
};

#endif
