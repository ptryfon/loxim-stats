#ifndef schemaParser_H
#define schemaParser_H

#include <string>
#include "schemaSyntax.h"

using std::string;

Database* schemaParse(string userInput);

#endif
