#ifndef schemaLexer_H
#define schemaLexer_H

#include <string>

using std::string;

void schemaScannerInit(string userInput);
void schemaScannerFinish();

#endif
