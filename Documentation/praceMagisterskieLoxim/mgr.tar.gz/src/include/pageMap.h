#ifndef _PAGEMAP_H_
#define _PAGEMAP_H_

#include <stdint.h>
#include <iostream>
#include <string>
#include <list>
#include <map>
using namespace std;

class Pager;
class MemPage;
typedef struct FirstPage FirstPage;
typedef struct PageHdr PageHdr;

// max memory cache size
#define MAX_PAGES   	   	5		// for testing; should be: 1000 or such

#define PAGE_SIZE          	1024	// suggested: 4096

#define MAX_CELL_SIZE   	250 	// suggested: around (PG_DATA_SIZE/4)
#define MIN_CELL_SIZE		(sizeof (CellInfo) + 4)

#define PG_NORMAL			0		// for internal usage; page types
#define PG_FREE				1
#define PG_OVERFLOW			2

// aliaseses for convenience
#define u32	uint32_t
#define u16	uint16_t
#define u8	uint8_t

// preamble in each data file
struct FirstPage {
    u32 firstFree;
    u32 nFree;
    char data[PAGE_SIZE-2*sizeof(u32)]; // PAGE_SIZE-8
} __attribute__((__packed__));
     
// raw disk page struct
struct PageHdr {
	u16 pageType;
	u16 nCells;
    char data[PAGE_SIZE-2*sizeof(u16)];
} __attribute__((__packed__));

#define PG_HDR_SIZE	4
#define PG_DATA_SIZE	(PAGE_SIZE - PG_HDR_SIZE)

// page mapped into memory; disk-page content is stored in data[] array
class MemPage {
 public:
  Pager *pPager;                 	/* The pager to which this page belongs */
  int pgno;                     	/* The page number for this page */
  //int nRef;                      	/* Number of users of this page */
  //int dirty;                      /* TRUE if we need to write back changes */
  char data[PAGE_SIZE];
  u16 MemPage::countFreeSpace();
};

// the pagemap struct -- enables efficient lookups by page blockIds
typedef map<int,MemPage*> PageMap;

/*
** A open page cache is an instance of the following structure.
** remember: pageMap maps physAddr -> memAddr; reverse map: just MemPage->pgno.
*/
class Pager {
 public:
  string fileName;            /* Name of the database file */
  int fd;                     /* File descriptor for the database file*/
  u32 dbSize;                 /* Number of pages in the file */
  u32 nPage;                  /* Total number of in-memory pages */
//  int nRef;                 /* Number of in-memory pages with PgHdr.nRef>0 */
//  int nHit, nMiss, nOvfl;   /* Cache hits, missing, and LRU overflows */
  PageMap pageMap;
  int firstFree;			  /* info copied from FirstPage */
  int nFree;
  
  MemPage* newPage();
  MemPage* getPage(u32 pgno);
  void writePage(u32 pgno);
  void swapd();					// when called, decides/tries to free some pages
  void syncFirstPage();
  void stats();					// prints memory usage stat
};

/* Every Database has a map of PageTables for each stored class */
typedef map<string, Pager*>     PagersMap;

// for internal usage

// where will we locate real offset of cell x?
#define cellOffOff(x)		(4 + 4*x)
// and cell x's size
#define cellSizeOff(x)		(6 + 4*x)
// the real cell offset extraction
#define cellOff(h,n)	*((u16*)((char*)h + cellOffOff(n)))
// and size extraction, similiarly
#define cellSize(h,n)	*((u16*)((char*)h + cellSizeOff(n)))

// raw disk page - cell descriptor struct
struct cellInfo {
	u16 off;
	u16 size;
} __attribute__((__packed__));
typedef struct cellInfo CellInfo;

// wrappers for IO ops
#define myread(fd, ptr, size, classname, pgno) \
  { debug ( "READ BLOCK: class " << classname << ", page " << pgno); \
    myassert (read (fd, ptr, size) != -1, "read page failed"); }

#define mywrite(fd,ptr,size, classname, pgno) \
  { debug ("WRITE BLOCK: class " << classname << ", page " << pgno); \
    myassert (write (fd,ptr,size) != -1, "write page failed"); }

#endif
