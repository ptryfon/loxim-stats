#ifndef _DBOPS_H_
#define _DBOPS_H_

#include "include/schemaSyntax.h"

using namespace std;

// the basic oid struct; 8 bytes
// offset field means logical offset in block - "structured addressing"
typedef struct DbPointer {
    uint16_t clsId;
    uint16_t offset;	
    uint32_t blockNo;
} DbPointer;
typedef DbPointer Oid;	// alias for convenience

// these are for internal usage only	

#define fillDbPointer(s,x,y,z) { s.clsId=x; s.offset=z; s.blockNo=y; }
#define showDbPointer(s) { if ((s.clsId==0)&&(s.blockNo==0)&&(s.offset==0)) printf ("NULL\n"); \
	else printf("(%d,%d,%d)\n", s.clsId, s.blockNo, s.offset); }

#define shift(ptr,nbytes) ((char*)ptr + nbytes)

bool linkIsNull (Oid s);
bool checkLink (Database* db, Oid destOid);
bool checkLink (Database* db, Oid destOid, string checkedName);	
bool checkLinkInRoleSet (Database* db, Oid destOid, string ourClassName);	
	
// and here are the public functions, main DB API

void openDb(Database*);
void closeDb(Database*);	
	
// fills space with a dead object
DbPointer _newCell (Database *db, string className, uint16_t size);
// creates a real object
DbPointer newCell (Database *db, string className, string query);

// returns the objects as a void*
void* getCell (Database *db, DbPointer oid, int* size);
	
// prints the object data in a human-readable format
void printCell (Database *db, DbPointer oid);
	
// deletes an object (marks as deleted - makes a tombstone, actually).
void deleteCell (Database* db, Oid oid);


/* public iterator on a className
   algorithm as presented in "Database systems implementation"

   usage: for (iterator i = open(); !i.end(); i.plusPlus()) { 
	    x = i.getCurrent(); ...   }
   
   NOTE: currently returns also dead cells
*/
class CellIterator {
  private:
	Database* db;
    string s;
    bool found;
  	u16 clsId;
	u32 blockNo;
	u16 offset;
	MemPage* p;
  	PageHdr* h;
    string className;
	bool nextDataBlock();
  
  public:
	  void open();
      void close();
      void plusPlus();
      bool end();
      Oid getCurrent();
      CellIterator();
      CellIterator(Database* d, string s);
      virtual ~CellIterator();
};  	

// CellIterator demonstration - prints all oids for a given class.
void getAllCells (Database* db, string className);

#endif
