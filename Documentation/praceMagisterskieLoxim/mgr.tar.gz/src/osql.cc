// run with: /home/jfiok/mgr/_src/test1

/* 
this is the main executable. 
holds the program loop, executes the commands. 
*/

#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <stdlib.h>
#include <errno.h>
#include "include/err.h"
#include "include/schemaSyntax.h"
#include "include/schemaParser.h"
#include "include/pageMap.h"
#include "include/dbOps.h"
#include "include/insertParser.h"

using namespace std;

Database *db;

void endSession() {
    closeDb (db);
	debug ("DB files closed OK");
    delete db;
	debug ("Memory freed OK");
    cout << "Goodbye." << endl;
    exit(0);
}

/* command classes
   every interpreter command has a corresponding class
   every class has appropriate constructor and an execute() method.
   execute() needs the command line string.
*/

// base abstract class
class AbstractCommand { public: virtual void execute() = 0; };

class QuitCommand: public AbstractCommand {
    public: void execute() { endSession(); }
};

class HelpCommand: public AbstractCommand {
    public: 
	void execute() {
	    cout << "internal commands start with '\\'. Rest are queries.\n\n";
	    cout << "\\h\t\t\t-- this help page\n";
	    cout << "\\q or crtl+d\t\t-- quit\n";
	    cout << "\\dt\t\t\t-- describe the schema classes\n";
	    cout << "\\d classname\t\t-- describe class classname\n";
	    cout << "\\s\t\t\t-- show paging memory statistics\n";
		
		cout << "\\insert\t\t\t-- insert classname <isRoleOf> <hasRolesSet> fields...\n";
		cout << "\\newcell size\t\t-- insert a \"dead\" object eating <size> bytes\n";
		cout << "\\getcell clsId blockNo log_offset\t\t-- get and show an oid\n";
		cout << "\\deletecell clsId blockNo log_offset\t\t-- delete an object\n";
		cout << "\\getallcells className\t\t\t\t-- get all oids for a class\n";
	    cout << endl;
	}
};

class UnknownCommand: public AbstractCommand {
    public: void execute() {
	cout << "Unknown command." << endl;
    }
};

class ShowTablesCommand : public AbstractCommand {
    public: void execute() { cout << *(db) << endl; }
};

class ShowMemStatCommand : public AbstractCommand {
    public:
	void execute() { 
	    for (PagersMap::iterator pagersMapIt = db->pagers.begin(); pagersMapIt != db->pagers.end(); pagersMapIt++) {
		Pager* p = (*pagersMapIt).second;
		myassert (p, "null pager acquired from dictionary");
		p->stats();
	    }
	}
};

class DescTableCommand: public AbstractCommand {
    public: 
	string tableName;
	DescTableCommand() {}
	DescTableCommand(string s) { 
	    myassert (s!="", "empty string as table name passed");
	    tableName = s; 
	}
	void execute() {
	    if ((db->allClasses[tableName])==NULL)
			cout << "no such class: " << tableName << endl;
	    else 
			cout << (string) *(db->allClasses[tableName]);	    
	};
	virtual ~DescTableCommand() {}	// for the compiler to shut up...
};

/* src = command line; returns: here the next arg will be put
   src will be truncated to what is left
   returns: popped first arg as string
*/
string nextArg (string* src) {
	myassert (src, "NextArg: null src string passed");
	myassert (src->size(), "NextArg: src with length 0");
	unsigned space_pos = src->find (" ", 0);
	string ret;
	if (space_pos == string::npos) { ret = *src; *src = ""; return ret; }
	ret = src->substr (0, space_pos);
	*src = src->substr (space_pos+1, src->size()-space_pos-1);
	return ret;
}

// newcell className cellLength
class NewCellCommand: public AbstractCommand {
    public: 
	string cmdline;
	string tableName;
	int size;
	NewCellCommand() {}
	NewCellCommand(string s) { 
	    myassert (s!="", "empty string as cmdline passed");
		cmdline = s;
	}
	void execute() {
		tableName = nextArg (&cmdline);
		string s_tmp = nextArg (&cmdline);
		size = 0;
		size = atoi(s_tmp.c_str());
		myassert (size, "size conversion failed");
		cout << "newcell " << tableName << ", size = " << size << endl;	
		cout.flush();
		DbPointer ptr = _newCell (db, tableName, size);
		showDbPointer(ptr);
	};
	virtual ~NewCellCommand() {}	// for the compiler to shut up...
};

class InsertCommand: public AbstractCommand {
    public: 
	string cmdline;
	string tableName;
	InsertCommand() {}
	InsertCommand(string s) { 
	    myassert (s!="", "empty string as cmdline passed");
		cmdline = s;
	}
	void execute() {
		tableName = nextArg (&cmdline);
		cout << "INSERT " << tableName << ": " << cmdline << endl;	
		cout.flush();
		// size = insertParse (cmdline, db, tableName, &ret);
		DbPointer ptr = newCell (db, tableName, cmdline);
		showDbPointer(ptr);		
	};
	virtual ~InsertCommand() {}	// for the compiler to shut up...
};

// getCell oid
class GetCellCommand: public AbstractCommand {
    public: 
	string cmdline;
	GetCellCommand() {}
	GetCellCommand(string s) { 
	    myassert (s!="", "empty string as cmdline passed");
		cmdline = s;
	}
	void execute() {
		Oid oid;
		errno = 0;
		
		string ret = nextArg (&cmdline);
		oid.clsId = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		ret = nextArg (&cmdline);
		oid.blockNo = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		ret = nextArg (&cmdline);
		oid.offset = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		cout << "getcell: (" << oid.clsId << "," << oid.blockNo << "," << oid.offset << ")" << endl;
		printCell (db, oid);		
	};
	virtual ~GetCellCommand() {}	// for the compiler to shut up...
};

// deleteCell oid
class DeleteCellCommand: public AbstractCommand {
    public: 
	string cmdline;
	DeleteCellCommand() {}
	DeleteCellCommand(string s) { 
	    myassert (s!="", "empty string as cmdline passed");
		cmdline = s;
	}
	void execute() {
		Oid oid;
		errno = 0;
		
		string ret = nextArg (&cmdline);
		oid.clsId = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		ret = nextArg (&cmdline);
		oid.blockNo = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		ret = nextArg (&cmdline);
		oid.offset = strtol((char*) ret.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
		
		cout << "deleteCell: (" << oid.clsId << "," << oid.blockNo << "," << oid.offset << ")" << endl;
		deleteCell (db, oid);		
	};
	virtual ~DeleteCellCommand() {}	// for the compiler to shut up...
};

//getAllCells (Database* db, string className)
class GetAllCellsCommand: public AbstractCommand {
    public: 
	string tableName;
	GetAllCellsCommand() {}
	GetAllCellsCommand(string s) { 
	    myassert (s!="", "empty string as table name passed");
	    tableName = s; 
	}
	void execute() {
	    if ((db->allClasses[tableName])==NULL)
			cout << "no such class: " << tableName << endl;
	    else 
			getAllCells (db, tableName);	    
	};
	virtual ~GetAllCellsCommand() {}	// for the compiler to shut up...
};

void executeQuery (string query) {
	// to be implemented:
    // 		className
    // 		getOid
    // 		oid.argName
    cout << "execute query not yet implemented" << endl;
}	

void executeCmd (string line) {
  string s_cmd = "";
  string s_arg = "";
  AbstractCommand *cmd = NULL;
  if (line[0]=='\\') { 		// it's a command
	line.erase(0,1); 		    // delete at 0, 1 char
	unsigned int space_pos = line.find (" ", 0);
	if (space_pos == string::npos) {
	    s_cmd = line;
	    s_arg = "";
	} else { 					// space is found - there is 1+ argument
	    s_cmd = line.substr (0, space_pos);
	    s_arg = line.substr (space_pos+1, line.size()-space_pos-1);
	}
	if ((s_cmd=="quit")||(s_cmd=="q")) { 
	    cmd = new QuitCommand(); 
	} else if (s_cmd=="h") {
	    cmd = new HelpCommand();  
	} else if (s_cmd=="dt") {
	    cmd = new ShowTablesCommand();
	} else if (s_cmd == "d") {
	    cmd = new DescTableCommand(s_arg);
	} else if (s_cmd == "s") {
	    cmd = new ShowMemStatCommand();
	} else if (s_cmd == "newcell") {	
		cmd = new NewCellCommand(s_arg);
	} else if (s_cmd == "getcell") {	
		cmd = new GetCellCommand(s_arg);	
	} else if (s_cmd == "deletecell") {	
		cmd = new DeleteCellCommand(s_arg);			
	} else if (s_cmd == "getallcells") {
	    cmd = new GetAllCellsCommand(s_arg);		
	} else if ((s_cmd == "insert")||(s_cmd=="INSERT")) {	
		cmd = new InsertCommand(s_arg);			
	} else { // unknown command;
	    cmd = new UnknownCommand ();
	}
	myassert (cmd!=NULL, "Null Command");
	cmd->execute();
	delete cmd; 
	cmd = NULL;
  } else {				// line[0] != '\' -- it's a query
	executeQuery (line);
  }

}

int main(int argc,char** argv) {
	string userInput = "";

	myassert (argc==2, "Please supply a database name.");
	// strip "schema" ...
	string dbname = argv[1];
	unsigned pos = dbname.find (".schema", 0);
	if (pos != string::npos) dbname.erase (pos, 7);
	string schemaName = dbname + ".schema";
	// read the schema
	ifstream plik (schemaName.c_str());
	while (plik.good()) userInput += (char) plik.get();
	myassert (plik.eof(), "Problems reading inputfile"); 
	plik.close();

	cout << "Using database " << dbname << endl;
	db = schemaParse (userInput);
	myassert (db, "Parser: syntax error.");
	myassert (db->schemaParserProstProc(), "Semantic postprocessing failed.");
	cout << "Parsed&analyzed OK." << endl;
	openDb (db);
	cout << "Opened DB files OK." << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\\h for help" << endl;

	char *cline;
	string line; 							// string version of cline
	while (1) { 							// main loop
	    cline = readline ("> ");
	    if (cline==NULL) break;
	    if (*cline) add_history (cline); 	// pointer content != \0
	    line = cline;
	    cout << "[command]: " << line << endl;
		
	    executeCmd (line);

	    free(cline);
	} 
	endSession();
	return 0;
}
