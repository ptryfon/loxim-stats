/*
most operations on the database is coded here.
*/

#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "include/schemaSyntax.h"
#include "include/err.h"
#include "include/pageMap.h" 				
#include "include/dbOps.h"
#include "include/insertParser.h"
#include <time.h>
#include <string>
                                                                                
using namespace std;

/* start work session
   make sure files exist on disk; if not - create; initialize files+pagers */
void openDb (Database* db) {
    struct stat buf;
    if (stat (db->dbName.c_str(), &buf)) { 	// -1 == true; means: doesn't exist 
		myassert (!mkdir (db->dbName.c_str(), 0777), "cannot create db directory");
    } else {
		myassert (S_ISDIR(buf.st_mode), "dbname already exists but not a directory");
    }
    myassert (!chdir (db->dbName.c_str()), "cannot chdir to db directory");
    for (classesMap::iterator classesMapIt = db->allClasses.begin(); 
		classesMapIt != db->allClasses.end(); classesMapIt++) {
        DbClass* c = (*classesMapIt).second;
        myassert (c, "null class acquired from dictionary");
        int fd;
		myassert2 ((fd = open (c->name.c_str(), O_CREAT|O_RDWR, 0664))!=-1, "cannot open db file", c->name.c_str());
        // prepare the pager (set its vars)
        Pager *ppager = new Pager();
        db->pagers[c->name] = ppager;
        ppager->fileName = c->name;
        ppager->fd = fd;																						 
        /* now: if file is new -> construct FirstPage
		   else: read first page from disk.																			 											 
		*/																				 
        myassert (!(fstat(fd,&buf)), "stat on db file");
		FirstPage fp;
        if (!buf.st_size) { // file has size 0
            debug2 ("creating pagefile: ", c->name);             			
            memset ((void*)&fp, 0, sizeof(FirstPage));
            fp.firstFree = 0;
            fp.nFree = 0;
			mywrite (fd, (void*)&fp, PAGE_SIZE, c->name, 0);
        	ppager->dbSize = 1; 								// size includes first page
        	ppager->nPage = ppager->nFree = ppager-> firstFree = 0;			
        } else {
			myread (fd, &fp, PAGE_SIZE, c->name, 0);
			// dbsize, npage, firstfree, nfree
			ppager->nPage = 0;
			ppager->firstFree = fp.firstFree;
			ppager->nFree = fp.nFree;
			ppager->dbSize = buf.st_size / PAGE_SIZE;
		}                                                                
    } // classes iterator
}

/* end the session
   close files; free memory for pagers and their map in Database */
void closeDb (Database* db) {
    for (classesMap::iterator classesMapIt = db->allClasses.begin(); classesMapIt != db->allClasses.end(); classesMapIt++) {
        DbClass* c = (*classesMapIt).second;         
		myassert (c, "null class acquired from dictionary");
        Pager* ppager;
        myassert(ppager = db->pagers[c->name], "got null pager for a class");
        ppager->syncFirstPage();
        myassert(!close(ppager->fd), "problem closing file");         
		delete ppager;
    }
}


/*  creates a new object 

- dbSize = 1 -> newPage; end
- check freespace>size in last pgno
        - found -> sit there
        - not found -> newPage;
- remember to update all counters etc.
- write -> sync: writePage(n)!

real_flag: do we actually write the cell data, or only allocate space?
(real_flag=0 makes sense with proposed_size)
*/ 	
static DbPointer doNewCell (Database *db, string className, uint16_t proposed_size, string query, int real_flag) {
    Pager *pager = db->pagers[className];
    myassert (pager, "no pager found; is className correct?");
	void* payload;
	u16 size = proposed_size;
	if (real_flag) { 
		size = insertParse (query, db, className, &payload);
	}
	myassert (size < MAX_CELL_SIZE, "won't create this large cell");
	myassert (size > MIN_CELL_SIZE, "won't create this small cell");
	u32 lastBlock = pager->dbSize - 1;
	u16 freeSpace = 0;
	// check free space in last block on disk (if any block exists).
	if (lastBlock > 0) {
		MemPage* p = db->pagers[className]->getPage(lastBlock);
		freeSpace = p->countFreeSpace();
		debug2("lastblock: ", lastBlock);
		debug2("freespace: ", freeSpace);
	}
	
	if (freeSpace >= size) { 
		// success! put the new cell in this block.
		MemPage* p = db->pagers[className]->getPage(lastBlock);
		PageHdr* h = (PageHdr*) p->data;
		//how many are already: h->nCells
		//lastCellNo = (h->nCells -1)		
		u16 lastCellOff = cellOff(h, (h->nCells-1));
		u16 newOff = lastCellOff - size;
		CellInfo* ci = (CellInfo*) ( (char*)h + PG_HDR_SIZE + 4*h->nCells );
		ci->off = newOff;
		ci->size = size;
		if (real_flag) {
			memcpy ((void*)((char*)h + newOff), payload, size);
		} else {
			// only eat space: set expiry time = 1970 + 1 second ;)
			*((int*)((char*)h + newOff)) = 1;	
		}
		debug2 ("new cell: offset = ", ci->off);
		h->nCells++;	
		debug2 ("after add: nCells = ", h->nCells);
		pager->writePage(p->pgno);		
        DbPointer oid;
        fillDbPointer (oid, db->allClasses[className]->id, p->pgno, h->nCells-1);
        return oid;					
	} else { // we have to create a new block.
		MemPage* p = pager->newPage();
        PageHdr* pageHdr = (PageHdr*) p->data;
		pageHdr->nCells = 1;
		CellInfo* ci = (CellInfo*) ( (char*)pageHdr + PG_HDR_SIZE);
		ci->off = PAGE_SIZE - size;
		ci->size = size;
        
		if (real_flag) {
			memcpy ((void*)((char*)pageHdr + PAGE_SIZE - size), payload, size);
		} else {
			*((int*)((char*)pageHdr + PAGE_SIZE - size)) = 1;
		}
        pager->writePage(p->pgno);
        DbPointer oid;
        fillDbPointer (oid, db->allClasses[className]->id, p->pgno, 0);
        return oid;				
	}                                                          
}
    
/*
_newCell is for debugging purposes: just allocates size bytes in storage.
newCell inserts the actual data parsed from string query.
*/
DbPointer _newCell (Database *db, string className, uint16_t size) {
	return doNewCell (db,className,size,"", 0);
}
DbPointer newCell (Database *db, string className, string query) {
	return doNewCell (db,className,0,query,1);
}

bool linkIsNull (Oid s) {
	return ((s.clsId==0)&&(s.blockNo==0)&&(s.offset==0));
}

/* verifies that link destination exists 
   if given className!="" - also checks correctness of class ("link type")
   NOTE: if link is NULL (0,0,0) the test is passed. (NULL is correct link...)
*/
bool checkLink (Database* db, Oid destOid, string checkedName) {
	if (linkIsNull(destOid)) return true;
	if (!db->clsIdMap[destOid.clsId]) {
		cout << "checkLink: class id " << destOid.clsId << " does not exist" << endl;
		return false;
	}
	string className = db->clsIdMap[destOid.clsId]->name;
	if (checkedName!="") {
		if (className!=checkedName) {
			cout << "checkLink: wrong destination class in link" << endl;
			return false;
		}
	}
	MemPage* p = db->pagers[className]->getPage(destOid.blockNo);
	PageHdr* h = (PageHdr*) p->data;
	if (h->pageType!=PG_NORMAL) {
		cout << "checkLink: from not-normal page attempted" << endl;
		return false;
	}
	if (destOid.offset < h->nCells) {
		// ok, cell is found; but still have to check if it's alive
		CellInfo* ci = (CellInfo*) ( (char*)h + PG_HDR_SIZE + 4*destOid.offset);
		u16 size = ci->size;	
		if (size==0) return false; // it's a tombstone
		int expTime = *((int*)((char*)h + ci->off));
		if (expTime==0) return true;
		return (expTime > time(NULL));
	} else 
		return false;
}

// checks if the oid's class is in the classname hasRoles set
bool checkLinkInRoleSet (Database* db, Oid destOid, string ourClassName) {
	if (linkIsNull(destOid)) return false; 	// NULL in hasRoles not allowed
	string linkClassName = db->clsIdMap[destOid.clsId]->name;
	bool found = false;
	for (rolesMap::iterator rmit = db->allClasses[ourClassName]->rolesOwned.begin();
		rmit != db->allClasses[ourClassName]->rolesOwned.end();
		rmit++) {
			RoleDesc* rd = (*rmit).second;
			if ( (rd->className)==linkClassName ) found = true;
	}
	return found;
}

// only checks dest object existence - defined for convenience
bool checkLink (Database* db, Oid destOid) {
	return checkLink (db, destOid, "");
}

// returns an object as a piece of memory; fills u16 size - the object's size.
void* getCell (Database *db, DbPointer oid, u16* size) { 
	/*
	Oid =     	uint16_t clsId;    uint16_t offset;    uint32_t blockNo;
	pageHdr = 	u16 pageType;	u16 nCells; char data[PAGE_SIZE-2*sizeof(u16)];
	*/
	myassert (db->clsIdMap[oid.clsId], "class id " << oid.clsId << " not found");
	string className = db->clsIdMap[oid.clsId]->name;
	MemPage* p = db->pagers[className]->getPage(oid.blockNo);
	PageHdr* h = (PageHdr*) p->data;
	myassert (h->pageType==PG_NORMAL, "getCell from not-normal page attempted");
	myassert2 (oid.offset < h->nCells , "only ncells in this block = ", h->nCells);
	CellInfo* ci = (CellInfo*) ( (char*)h + PG_HDR_SIZE + 4*oid.offset);
	*size = ci->size;	
	if (ci->size==0) {
		debug ("getCell: tombstone access");
		return NULL;
	} else {
		debug2 ("getCell: realOff = ", ci->off);
		return (void*)((char*)h + ci->off);
	}
}

// pretty-prints an object for our beloved user
// also: demonstrates how to get data from fields.
void printCell (Database *db, Oid oid) {
	u16 cellLen, fieldOff, fieldSize;		// (of _current_ field)
	unsigned i;
	int p;									// ptr as we walk through the cell
	char* payload = (char*) getCell (db, oid, &cellLen);
	if (cellLen==0) {
		cout << "The cell is dead by tombstone (used to exist)." << endl;
		return;
	}
	debug2 ("cellLen : ", cellLen);
	debug2 ("expiry time : ", *((int*)payload));
	if ((*((int*)payload) != 0)&&(*((int*)payload) <= time(NULL))) {
		cout << "The cell is dead by its expTime." << endl;
		return;
	}
	p = sizeof(int);
	Oid isRoleOf = *((Oid*)(payload+p));
	p += sizeof(Oid);
	printf ("isRoleOf : ");
	showDbPointer (isRoleOf);
	// hasRoles
	fieldOff = *((u16*)(payload+p));
	fieldSize = *((u16*)(payload+p+2));
	debug ("hasRoles: fieldOff = " << fieldOff << ", fieldSize = " << fieldSize);
	p += 4;
	for (i=0;i<fieldSize;i++) {
		Oid role = *((Oid*)(payload+fieldOff+sizeof(Oid)*i));
		printf ("hasRole : ");
		showDbPointer (role);
	}
	
	for (i=0; i < db->clsIdMap[oid.clsId]->fieldsVec.size(); i++) {	
		// print REAL field i
		FieldDesc* fd = db->clsIdMap[oid.clsId]->fieldsVec[i];
		if (!fd->multiple) {
			fieldOff = *((u16*)(payload+p));
			debug ("field " << i << ": fieldOff = " << fieldOff);
			p += 2;
			if (fd->type.id == T_LINK) {
					Oid role = *((Oid*)(payload+fieldOff));
					printf ("%s : ", fd->name.c_str());
					showDbPointer (role);
			} else if (fd->type.id == T_INT) {
					int tmp = *((int*)(payload+fieldOff));
					cout << fd->name << " : " << tmp << endl;
			} else if (fd->type.id == T_DOUBLE) {
					double tmp = *((double*)(payload+fieldOff));
					cout << fd->name << " : " << tmp << endl;
			} else if (fd->type.id == T_STRING) {
					// int nextOff = *((int*)(payload+p+2));
					// int ssize = nextOff - fieldOff; - unnecessary
					char* tmp = payload+fieldOff;
					cout << fd->name << " : " << tmp << endl;
			} else {
					panic ("printCell: unknown type");
			}
		} else {										// multiple field
			fieldOff = *((u16*)(payload+p));
			fieldSize = *((u16*)(payload+p+2));			// (means: fieldCount)
			debug ("field " << i << ": fieldOff = " << fieldOff << ", fieldSize = " << fieldSize);
			p += 4;
			u16 shift = 0;
			for (unsigned j=0;j<fieldSize;j++) {
				if (fd->type.id == T_LINK) {
					Oid role = *((Oid*)(payload+fieldOff+sizeof(Oid)*j));
					printf ("%s : ", fd->name.c_str());
					showDbPointer (role);
				} else if (fd->type.id == T_INT) {
					int tmp = *((int*)(payload+fieldOff+sizeof(int)*j));
					cout << fd->name << " : " << tmp << endl;
				} else if (fd->type.id == T_DOUBLE) {
					double tmp = *((double*)(payload+fieldOff+sizeof(double)*j));
					cout << fd->name << " : " << tmp << endl;
				} else if (fd->type.id == T_STRING) {
					u16 thisElemLen = *((u16*)(payload+p));	
					p+= 2;
					char* tmp = payload+fieldOff + shift;
					shift += thisElemLen;
					cout << fd->name << " : " << tmp << endl;
				} else {
					panic ("printCell: unknown type");
				}
				
			}		

			
		} // is multiple
	} // field i
} // printCell

// deletes an object by making a tombstone, no more comment needed
void deleteCell (Database* db, Oid oid) { 
	myassert (db->clsIdMap[oid.clsId], "class id " << oid.clsId << " not found");
	myassert (checkLink(db,oid), "tried to delete nonexisting oid");
	string className = db->clsIdMap[oid.clsId]->name;
	MemPage* p = db->pagers[className]->getPage(oid.blockNo);
	PageHdr* h = (PageHdr*) p->data;
	CellInfo* ci = (CellInfo*) ( (char*)h + PG_HDR_SIZE + 4*oid.offset);
	char* payload = ((char*)h + ci->off);
	if ((*((int*)payload) != 0)&&(*((int*)payload) <= time(NULL))) {
		cout << "cell ALREADY DEAD by its expTime." << endl;
		return;
	}
	ci->size = 0;
	// sync
	db->pagers[className]->writePage(oid.blockNo);
	cout << "Cell deleted." << endl;
}

// tries to find nearest block with some cells; returns true if found;
// stores the found block number in global blockNo
bool CellIterator::nextDataBlock() {
		bool ok;
		while (1) {
			blockNo++;
			if (blockNo >= db->pagers[className]->dbSize) { ok = false; break; }
			p = db->pagers[className]->getPage(blockNo);
			h = (PageHdr*) p->data;
			if ((h->pageType==PG_NORMAL)&&(h->nCells)) { ok = true; break; }
		}
		return ok;		
}
                                                                             
/* b:= first block R; t:= firstCell(b); found=1 or found=0 */
void CellIterator::open() {
		   found = false;
		   blockNo = 0;
		   if (nextDataBlock()) { 
			   found = true; 
			   offset = 0;
		   }
       }
                                                                                
bool CellIterator::end() { return (!found); }
        
Oid CellIterator::getCurrent() {
		   Oid ret; 
		   ret.clsId = clsId; ret.blockNo = blockNo; ret.offset = offset;
		   return ret;
}		   
		   
void CellIterator::plusPlus() {
		   if (offset == (h->nCells-1)) { // last offset in block
			   if (!nextDataBlock()) {
				   found = false; return;
			   } else {
				   found = true; offset = 0; return;
			   }   
		   }
           offset++;                                                                                                                      
}
                                                                                
// no locks -> do nothing
void CellIterator::close() {}
		   
CellIterator::CellIterator() {}
CellIterator::CellIterator(Database* d, string s) {
     	   className = s; db = d; clsId = db->allClasses[className]->id;
}
CellIterator::~CellIterator() {}

// CellIterator demonstration - prints all oids for a given class.
void getAllCells (Database* db, string className) {
	CellIterator ci (db, className);
	int howmany = 0;
	for (ci.open(); !ci.end(); ci.plusPlus()) {
		howmany++;
		showDbPointer (ci.getCurrent());	
	}
	ci.close();
	cout << "getAllCells: " << howmany << " objects found." << endl;
}
