#!/bin/sh
./osql test1.schema
