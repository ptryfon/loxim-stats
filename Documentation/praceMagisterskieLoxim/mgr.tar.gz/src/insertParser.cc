#include "include/schemaSyntax.h"
#include "include/err.h"    
#include "include/insertParser.h"
#include "include/dbOps.h"
#include "errno.h"

/* this simple library parses DDL inserts and converts them into raw data. 
   having no real AST tree and inter-operability with higher layers
   - simple static analysis is done while/right after parsing.
*/

using namespace std;

// enum typeNo { T_NOTHING, T_INT, T_DOUBLE, T_STRING, T_BOOL, T_LINK, T_SET_{BEGIN,END} };

// these globals are used for building the object
// note: header and data parts are stored separately, merged at the very end
static char cellHdr[MAX_CELL_SIZE];
static u16 p_hdr = 0;
static char cellData[MAX_CELL_SIZE];
static u16 p_data = 0;

// this is the current field byte representation
static void* content;
static int len = 0;

// counter used when in multiple fields
static u16 howmany = 0;
// counter when walking through the object
static int currentField = 0;

// removes starting whitespace from string
void eatSpace(string* src) {
	while ((*src)[0] == ' ') {
		src->erase(0,1);
	}
}

/* recognize (one) current token
   src = command line; 
   src will be truncated to what is left after eating the token [including space]
   returns: typeNo and sets globals: void* content and int len 
*/
typeNo nextSimpleToken (string* src, Database* db) {
	myassert (src, "NextArg: null src string passed");
	myassert (src->size(), "NextArg: src with length 0");
	eatSpace(src);
	myassert (src->size(), "NextArg: src with length 0 AFTER eating whitespace");
	string ret;
	// free mem if content not empty
	if (content) { free(content); content = NULL; }
	char c = (*src)[0];
	if (c=='"') { // string
		src->erase(0,1);
		unsigned space_pos = src->find ("\"", 0);
		myassert (space_pos != string::npos, "incomplete string");
		ret = src->substr (0, space_pos);
		*src = src->substr (space_pos+1, src->size()-space_pos-1);
		myassert2 ((*src)[0] == ' ', "no space after string. cmdline=", *src);
		src->erase(0,1);

		content = malloc (space_pos + 1);   		 // string_len + 1 --> \0
		char* tmpContent = (char*) ret.c_str();		 // this mem will be auto destroyed
		memcpy (content, tmpContent, space_pos + 1); // memcpy to ensure heap alloc
		len = space_pos+1;
		return T_STRING;		
	} else if (c=='{') { // begin set
		src->erase(0,1);
		eatSpace(src);
		content = NULL; len = 0; return T_SET_BEGIN;
	} else if (c=='}') { // end set
		src->erase(0,1);
		eatSpace(src);
		content = NULL; len = 0; return T_SET_END;
	} else if (c=='(') { // oid - ptr
		int i1 =0; int i2 = 0; int i3 = 0;
		string ret1, ret2, ret3;
		src->erase(0,1);
		unsigned space_pos = src->find (",", 0);
		myassert (space_pos != string::npos, "incomplete oid");
		ret1 = src->substr (0, space_pos);
		*src = src->substr (space_pos+1, src->size()-space_pos-1);
		eatSpace(src);
		space_pos = src->find (",", 0);
		myassert (space_pos != string::npos, "incomplete oid");
		ret2 = src->substr (0, space_pos);
		*src = src->substr (space_pos+1, src->size()-space_pos-1);
		eatSpace(src);
		space_pos = src->find (")", 0);
		myassert (space_pos != string::npos, "incomplete oid - missing )");
		ret3 = src->substr (0, space_pos);
		*src = src->substr (space_pos+1, src->size()-space_pos-1);

		errno = 0;	
		i1 = strtol((char*) ret1.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret1.c_str());	
		i2 = strtol((char*) ret2.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret2.c_str());	
		i3 = strtol((char*) ret3.c_str(), (char **)NULL, 10);
		myassert2 (errno==0, "int size conversion failed: ", ret3.c_str());		
		
		Oid oid;
		fillDbPointer(oid, i1,i2,i3);
		content = malloc (sizeof(Oid));
		memcpy (content, &oid, sizeof(Oid));
		len = sizeof(Oid);
		return T_LINK;
	} else if (c=='N') { // NULL?
		string tmp = src->substr(0, 5);
		if (tmp=="NULL ") {
			*src = src->substr (5, src->size()-5);
			// NULL oid -- (0,0,0) = 8B
			content = malloc (8); 
			memset (content, 0, 8);
			len = 8;
			return T_LINK;
		} else {
			debug (tmp);
			panic ("unknown token starting with N");
		}
	} else { // number => search for whitespace & try to convert
		unsigned space_pos = src->find (" ", 0);
		if (space_pos == string::npos) { 
			ret = *src; *src = ""; 
		} else {
			ret = src->substr (0, space_pos);
			*src = src->substr (space_pos+1, src->size()-space_pos-1);
		}
		// now check if it's an INT or DOUBLE
		unsigned dot_pos = ret.find (".", 0);
		if (dot_pos == string::npos) {  // parse as INT
			int i;
			errno = 0;
			i = strtol((char*) ret.c_str(), (char **)NULL, 10);
			myassert2 (errno==0, "int size conversion failed: ", ret.c_str());
			content = malloc (sizeof(int));
			memcpy (content, &i, sizeof(int));
			len = sizeof (int);
			return T_INT;
		} else {						// parse as DOUBLE
			double d;
			errno = 0;
			d = strtod((char*) ret.c_str(), (char **)NULL);
			myassert2 (errno==0, "double size conversion failed: ", ret.c_str());
			content = malloc (sizeof(double));
			memcpy (content, &d, sizeof(double));
			len = sizeof (double);
			return T_DOUBLE;			
		}
	}
}

// shift an object pointer, checking bounds
void safe_shift (u16* x, u16 n) {
	myassert (*x + n <= MAX_CELL_SIZE, "safe_shift: too big record");	
	*x = *x + n;
}

// parse the whole field
// works with cellData,cellHdr and their ptrs
void getField (string* src, Database* db, string className, int currentField) {
	typeNo type = nextSimpleToken (src,db);
	myassert (type!=T_SET_END, "not expected set termination"); // also ensures not memcpy'ing
	if (type != T_SET_BEGIN) {
		// proceed with simple field. [1] check the type
		myassert (currentField!=-1, "simple type instead of set hasRoles");
		myassert2 (db->allClasses[className]->fieldsVec[currentField]->type.id == type, 
				"type mismatch in field ", currentField);
		myassert2 (!db->allClasses[className]->fieldsVec[currentField]->multiple, 
				"given a singleton, expecting a set type in field ", currentField);
		// [2] execute: fill data
		myassert (p_data + len <= MAX_CELL_SIZE, "too big record/data");
		myassert (p_hdr + sizeof(u16) <= MAX_CELL_SIZE, "too big record/hdr");
		memcpy ((void*)(cellData + p_data), content, len);
		memcpy ((void*)(cellHdr + p_hdr), &p_data, sizeof(u16));
		p_data += len;
		p_hdr += sizeof(u16);
		// last: check link validity, if appropriate
		if (db->allClasses[className]->fieldsVec[currentField]->type.id==T_LINK) {
			myassert2(checkLink(db,*((Oid*)content),
					db->allClasses[className]->fieldsVec[currentField]->type.className),
					"single ptr: invalid dest ptr; fieldno = ", currentField);
		}
		return;
	}
	/* now we are parsing a multiple field.
	   first, check if it really should be multiple? (if NOT parsing hasRoles set)
	
	   notice: there are 2 types of multiple fields.
		- multiple w/fixed-size elems: header = 2B off + 2B count;
		- multiple w/var-size   elems: header = 2B off + 2B count + count*2B lengths
	
		multiple w/var-size, when:
	(currentField != -1) AND
	(db->allClasses[className]->fieldsVec[currentField]->type.id == T_STRING)
	
	*/
	if (currentField!=-1) {
		myassert2 (db->allClasses[className]->fieldsVec[currentField]->multiple, 
			"given a set, while NOT expecting a set type in field ", currentField);	
	}
	howmany = 0;
	// write to data where we start at
	myassert (p_hdr + sizeof(u16) <= MAX_CELL_SIZE, "too big record/hdr");
	u16* p = (u16*)((char*)cellHdr + p_hdr); *p = p_data;
	p_hdr += sizeof(u16);
	// treat multiple w/var-size field different - will fill its elemCount later
	u16 p_hdr_fieldcount = p_hdr;
	if (currentField!=-1)
		if (db->allClasses[className]->fieldsVec[currentField]->type.id == T_STRING) {
			p_hdr += sizeof(u16); // skip the howMany header part for now
		}
	while ((type = nextSimpleToken (src,db)) != T_SET_END) {
		howmany++;
		// [1] check the type
		if (currentField==-1) { 
			myassert (type==T_LINK, "hasRoles member not link type");
			Oid* tmp_link = (Oid*) content;
			// ... and class correctness
			myassert(checkLink(db, *tmp_link), "hasRoles: invalid role ptr");	
			myassert(checkLinkInRoleSet (db, *tmp_link, className), "ptr in hasRoles points to invalid class");			
		} else {
			myassert2 (db->allClasses[className]->fieldsVec[currentField]->type.id == type, 
				"type mismatch in field ", currentField);
			// check also class correctness, if data is T_LINK
			if (db->allClasses[className]->fieldsVec[currentField]->type.id == T_LINK) {
				Oid* tmp_link = (Oid*) content;
				myassert2 (checkLink(db, *tmp_link, 
				  db->allClasses[className]->fieldsVec[currentField]->type.className),
				  "invalid ptr at field ", currentField);
			}
		}
		// [2] fill data
		if (type==T_STRING) { 
				/* multiple and variable-length field. 
				   version1 was: fix fieldSize to SLEN
				   version2    : store each occurence size in the header.
			    */	
			myassert (p_hdr + sizeof(u16) <= MAX_CELL_SIZE, "too big record/hdr");
			memcpy ((void*)(cellHdr + p_hdr), &len, sizeof(u16));
			p_hdr += sizeof(u16);
		}		
		myassert (p_data + len <= MAX_CELL_SIZE, "too big record/data");
		memcpy ((void*)(cellData + p_data), content, len);
		p_data += len;
	} // while (have next field elem)
	// finish writes: header: how many records.
	if ((currentField!=-1)&&(db->allClasses[className]->fieldsVec[currentField]->type.id == T_STRING)) {
		memcpy ((void*)(cellHdr + p_hdr_fieldcount), &howmany, sizeof(u16));
	} else {
		myassert (p_hdr + sizeof(u16) <= MAX_CELL_SIZE, "too big record/hdr");
		p = (u16*)(cellHdr + p_hdr); *p = howmany;
		p_hdr += sizeof(u16);
	}
	//type = nextSimpleToken (src,db); -- no, T_SET_AND alredy eaten by while().
	myassert2 (type==T_SET_END, "unterminated set type - caught: ", type);
	return;
}


/* the actual object parser.

walk through the input; reading field by field 
fields are constructed by separately building their header and data parts
(assume we don't know the final data offsets - don't know final header size)
so, the offsets are put in the header counting from 0.
after the whole cell is parsed, count the header size and rewrite the offsets.

returns: int -- cell size; void** pret -- the cell payload
*/
int insertParse (string line, Database* db, string className, void** pret) {
	/* first of all, since we require space after every arg so also the last one,
	   we put a guardian space before the EOL. a bit ugly hack, but works. ;-)
	*/
	line += " ";
	typeNo type;
	// expTime = 0 -- never expire ("no tombstone") + varname reuse
	currentField = 0;
	memcpy ((void*)cellHdr, &currentField, sizeof(int));
	p_hdr = 4;
	p_data = 0;
	// this should have read IsRoleOf
	type = nextSimpleToken (&line, db);
	myassert (type==T_LINK, "first field not IsRoleOf");
	memcpy ((void*)(cellHdr + p_hdr), content, len);
	// verify this link; 
	Oid* tmp_link = (Oid*) content;
	RoleDesc* rd = db->allClasses[className]->rolePlayed;
	if (rd) {
		myassert(checkLink(db, *tmp_link, rd->className), "isRoleOf: invalid role ptr");
	} else {
		myassert(linkIsNull(*tmp_link), "isRoleOf ptr passed while not expexted -rolePlayed empty");
	}
	p_hdr += len; 							// should be: 4 + 8
	for (currentField = -1;					// -1: hasRoles -- hidden field
		currentField < (int)db->allClasses[className]->fieldsVec.size();
		currentField++) {
			getField(&line, db, className, currentField);
	}
	// OK. now rewrite offsets in cellHdr.
	// p_hdr = sizeof (whole header).
	debug2 ("new record: header size = ", p_hdr);
	debug2 ("new record: data size   = ", p_data);
	u16 hdrSize = p_hdr;
	p_hdr = 12; // expTime + isRoleOf; recalc offsets of hasRoles by hand:
	u16* p = (u16*)(cellHdr + p_hdr); *p = *p + hdrSize;
	p_hdr += 4;
	/* all normal field offsets in header: += p_hdr. 
	   locate them...: single field: 2B hdr; multiple: 4B hdr. */	
	for (u32 i=0; i<db->allClasses[className]->fieldsVec.size(); i++) {
		if (db->allClasses[className]->fieldsVec[i]->multiple) {
			u16* p = (u16*)(cellHdr + p_hdr); *p = *p + hdrSize;
			if (db->allClasses[className]->fieldsVec[i]->type.id == T_STRING) {
				u16 nElems = *( (u16*)(cellHdr + p_hdr + 2) );
				p_hdr += 4 + 2*nElems;
			} else {			    
				p_hdr += 4;
			}
		} else { 
			u16* p = (u16*)(cellHdr + p_hdr); *p = *p + hdrSize;
			p_hdr += 2;
		}	
	}
	
	myassert (p_hdr == hdrSize, "assert: (p_hdr == hdrSize) check error");
	myassert2 (hdrSize + p_data <= MAX_CELL_SIZE, "too big record: ", hdrSize + p_data);
	void* ret = malloc (hdrSize + p_data);
	memcpy (ret, cellHdr, hdrSize);
	memcpy ( (void*)((char*)ret+hdrSize), cellData, p_data);
	*pret = ret;
	debug2 ("parse successflul. objSize = ", (hdrSize + p_data));
	return (hdrSize + p_data);
}
